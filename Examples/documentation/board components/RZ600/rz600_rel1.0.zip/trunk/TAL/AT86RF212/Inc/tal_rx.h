/**
 * @file tal_rx.h
 *
 * @brief File contains macros and modules used while processing
 * a received frame.
 *
 * $Id: tal_rx.h 11544 2008-10-27 10:32:48Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef TAL_RX_H
#define TAL_RX_H

/* === INCLUDES ============================================================ */


/* === EXTERNALS =========================================================== */


/* === TYPES =============================================================== */

/*
 * Structure to store the received frame length, timestamp and RSSI
 */
BEGIN_PACK
typedef struct rx_frame_info_tag
{
    /** Received frame length */
    uint8_t  frame_length;
    /** Received frame energy level */
    uint8_t  ed_level;
    /** Timestamp of the received frame */
    uint32_t timestamp;
} rx_frame_info_t;
END_PACK

/* === MACROS ============================================================== */


/* === PROTOTYPES ========================================================== */

#ifdef __cplusplus
extern "C" {
#endif


#ifdef SNIFFER
void sniffer_handle_received_frame_irq(void);
#else
void handle_received_frame_irq(void);
#endif

void process_incoming_frame(buffer_t *buf);


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* TAL_RX_H */
