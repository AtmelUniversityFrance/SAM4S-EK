/**
 * @file tal_rx_enable.c
 *
 * @brief File provides functionality supporting RX-Enable feature.
 *
 * $Id: tal_rx_enable.c 12133 2008-11-21 07:07:28Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === INCLUDES ============================================================ */

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "platform_types.h"
#include "return_val.h"
#include "tal_tx.h"
#include "tal.h"
#include "ieee_const.h"
#include "tal_constants.h"
#include "pal.h"
#include "at86rf231.h"
#include "bmm.h"
#include "qmm.h"
#include "tal_rx.h"
#include "tal_internal.h"

/* === TYPES =============================================================== */


/* === MACROS ============================================================== */


/* === GLOBALS ============================================================= */


/* === PROTOTYPES ========================================================== */


/* === IMPLEMENTATION ====================================================== */

/**
 * @brief Turns receiver on or off
 *
 * This function switches the receiver on (PHY_RX_ON) or off (PHY_TRX_OFF).
 *
 */
uint8_t tal_rx_enable(uint8_t state)
{
    /*
     * Trx can only be enabled if TAL is not busy;
     * i.e. if TAL is IDLE.
     */
    if (TAL_IDLE != tal_state)
    {
        return BUSY;
    }

    if (state == PHY_TRX_OFF)
    {
        /*
         * If the rx needs to be switched off, we are not interested in a frame
         * that is currently being received.
         * This must not be a Forced TRX_OFF (CMD_FORCED_TRX_OFF) since this could
         * corrupt an already outoing ACK frame.
         */
         set_trx_state(CMD_TRX_OFF);
         tal_rx_on_required = false;
         return TRX_OFF;
    }
    else
    {
#ifdef SNIFFER
        set_trx_state(CMD_RX_ON);
#else
        if (tal_rx_buffer != NULL)
        {
            set_trx_state(CMD_RX_AACK_ON);
            //set_trx_state(CMD_RX_ON);
        }
        else
        {
            /*
             * If no rx buffer is available, the corresponding
             * information is stored and will be used by tal_task() to
             * switch on the receiver later.
             *
             * Even if a receive buffer is not available,
             * the TAL returns SUCCESS. The TAL will try to allocate a receive
             * buffer as soon as possible and will switch on the receiver.
             */
            tal_rx_on_required = true;
        }
#endif
        return RX_ON;   // MAC layer assumes RX_ON as return value
    }
}

/* EOF */

