/**
 * @file tal_tx.c
 *
 * @brief This file handles the frame transmission within the TAL.
 *
 * $Id: tal_tx.c 12338 2008-11-28 12:02:18Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === INCLUDES ============================================================ */

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "platform_types.h"
#include "return_val.h"
#include "tal.h"
#include "ieee_const.h"
#include "tal_pib.h"
#include "tal_irq_handler.h"
#include "tal_constants.h"
#include "pal.h"
#include "tal_tx.h"
#include "stack_config.h"
#include "bmm.h"
#include "qmm.h"
#include "tal_rx.h"
#include "tal_internal.h"
#include "at86rf231.h"
#ifndef NOBEACON
#include "tal_slotted_csma.h"
#endif

/* === TYPES =============================================================== */


/* === MACROS ============================================================== */

/*
 * Command Frame Identifier for Association Request
 */
#define ASSOCIATION_REQUEST             (0x01)

/*
 * Mask used to check if the frame control has a Source address
 */
#define SRC_ADDR_MASK                   (0x0800)

/*
 * Mask used to check if the frame control has a Destination address
 */
#define DEST_ADDR_MASK                  (0x8000)


/* === GLOBALS ============================================================= */

static trx_trac_status_t trx_trac_status;

#if ((!defined RFD) && (!defined NOBEACON))
/**
 * Pointer to 15.4 frame structure for beacon frames.
 */
static uint8_t *beacon_frame;
#endif

/* === PROTOTYPES ========================================================== */

static uint8_t * frame_create(frame_info_t *frame_info);


/* === IMPLEMENTATION ====================================================== */

/**
 * @brief Requests to TAL to transmit frame
 *
 * This function is called by the MAC to deliver a frame to the TAL
 * to be transmitted by the transceiver.
 *
 * @param mac_frame_info Pointer to the frame_info_t structure updated by
 *                       the MAC layer
 * @param perform_csma_ca Indicates whether csma_ca is to be performed for
 *                        this frame
 * @param frame_retry Indicates whether to retries are to be performed for
 *                    this frame
 *
 * @return SUCCESS if the TAL has accepted the data from the MAC for frame
 *                 transmission
 *         BUSY if the TAL is busy servicing the previous MAC request
 */
retval_t tal_tx_frame(frame_info_t *mac_frame_info,
                      bool perform_csma_ca,
                      bool perform_frame_retry)
{
    if (tal_state != TAL_IDLE)
    {
        return BUSY;
    }

    /*
     * Store the pointer to the provided frame structure.
     * This is needed for the callback function.
     */
    mac_frame_ptr = mac_frame_info;

#ifdef SPECIAL_PEER
    if (1 == tal_pib_PrivateCCAFailure)
    {
        /*
         * Pretend CCA failure for CCA test purposes.
         * Setting the corresponding TAL states will initiate a
         * tal_tx_frame_done_cb() callback with CCA failure.
         */

        tal_state = TAL_TX_DONE;
        trx_trac_status = TRAC_CHANNEL_ACCESS_FAILURE;
        return SUCCESS;
    }
#endif

    /* Create the frame to be downloaded to the transceiver. */
    tal_frame_to_tx = frame_create(mac_frame_info);

#ifndef NOBEACON
    /*
     * Association is done using unslotted CSMA
     * @TODO If sync before associate is implemented, update the following lines
     */
    if (tal_pib_PrivatePanCoordinator)
    {
        // check if beacon mode is used
        if (tal_pib_BeaconOrder < NON_BEACON_NWK)
        {
            if (perform_csma_ca)
            {
                slotted_csma_start(perform_frame_retry);
            }
            else
            {
                /* The frame is to be sent directly without performing csma_ca. */
                send_frame(tal_frame_to_tx, perform_csma_ca, perform_frame_retry);
            }
        }
        else
        {
            // send out the frame using unslotted CSMA
            send_frame(tal_frame_to_tx, perform_csma_ca, perform_frame_retry);
        }
    }
    else    // the node is not the coordinator
    {
        if (tal_pib_PrivateAssociated)
        {
            // check if beacon mode is used
            if (tal_pib_BeaconOrder < NON_BEACON_NWK)
            {
                if (perform_csma_ca)
                {
                    slotted_csma_start(perform_frame_retry);
                }
                else
                {
                    /* The frame is to be sent directly without performing csma_ca. */
                    send_frame(tal_frame_to_tx, perform_csma_ca, perform_frame_retry);
                }
            }
            else
            {
                // send out the frame using unslotted CSMA
                send_frame(tal_frame_to_tx, perform_csma_ca, perform_frame_retry);
            }
        }
        else
        {
            // send out the frame using unslotted CSMA
            send_frame(tal_frame_to_tx, perform_csma_ca, perform_frame_retry);
        }
    }
#else
    send_frame(tal_frame_to_tx, perform_csma_ca, perform_frame_retry);
#endif  /* ifndef NOBEACON */

    return SUCCESS;
}


/**
 * @brief Implements the handling of the transmission end.
 *
 * This function handles the callback for the transmission end.
 */
void tx_done_handling(void)
{
    tal_state = TAL_IDLE;

    switch (trx_trac_status)
    {
        case TRAC_SUCCESS:
            tal_tx_frame_done_cb(SUCCESS, mac_frame_ptr);
            break;

        case TRAC_SUCCESS_DATA_PENDING:
            tal_tx_frame_done_cb(TAL_FRAME_PENDING, mac_frame_ptr);
            break;

        case TRAC_CHANNEL_ACCESS_FAILURE:
            tal_tx_frame_done_cb(CHANNEL_ACCESS_FAILURE, mac_frame_ptr);
            break;

        case TRAC_NO_ACK:
            tal_tx_frame_done_cb(NO_ACK, mac_frame_ptr);
            break;

        default:
            ASSERT("Unexpected tal_tx_state" == 0);
            tal_tx_frame_done_cb(FAILURE, mac_frame_ptr);
            break;
    }
} /* tx_done_handling() */


/**
 * @brief Creates MAC frame
 *
 * This function is called to create a MAC frame using the information
 * passed to tal_tx_frame().
 *
 * @param tal_frame_info Pointer to the frame_info_t structure updated by
 *                       the MAC layer
 *
 * @return Pointer to the created frame header
 */
static uint8_t *frame_create(frame_info_t *tal_frame_info)
{
    uint8_t frame_length;
    uint16_t frame_format_mask;
    uint8_t *frame_header;

    /*
     * Start creating the frame header backwards starting from the payload.
     * Note: This approach does not require copying the payload again
     * into the frame buffer.
     */
    frame_header = tal_frame_info->payload;

    /* Start with the frame length set to the payload length. */
    frame_length = tal_frame_info->payload_length;

    /* Get the source addressing information. */
    frame_format_mask = tal_frame_info->frame_ctrl & SRC_ADDR_MODE_MASK;

    /*
     * As the frame creation is done backwards, the source address field
     * of the frame header is updated with the source address
     */
    if (SRC_EXT_ADDR_MODE == frame_format_mask)
    {
        frame_header -= EXT_ADDR_LEN;

        convert_64_bit_to_byte_array(tal_frame_info->src_address,
                                     frame_header);

        frame_length += EXT_ADDR_LEN;
    }
    else if (SRC_SHORT_ADDR_MODE == frame_format_mask)
    {
        frame_header -= SHORT_ADDR_LEN;

        convert_16_bit_to_byte_array(tal_frame_info->src_address,
                                     frame_header);

        frame_length += SHORT_ADDR_LEN;
    }

    /* Check if the frame to be created is a data frame. */
    if (DATA_FRAME == (tal_frame_info->frame_ctrl & FRAME_TYPE_MASK))
    {
        if (tal_frame_info->frame_ctrl & INTRA_PAN_SUBFIELD)
        {
            /*
             * Check for source address and destination address. If the
             * intrapan bit is set to 1 and both the destination and
             * source addresses are present, then do not include the
             * source PAN ID.
             */
            if ((tal_frame_info->frame_ctrl & SRC_ADDR_MASK) &&
                (tal_frame_info->frame_ctrl & DEST_ADDR_MASK))
            {
              /* Do not add source PAN ID */
            }
            else
            {
                /* Add the source PAN ID */
                frame_header -= PAN_ID_LEN;

                convert_16_bit_to_byte_array(tal_frame_info->src_panid,
                                             frame_header);

                frame_length += PAN_ID_LEN;
            }
        }
        else
        {   /*
             * The source PAN ID shall be included in the MAC frame only if the
             * source addressing mode and Intra-PAN subfield of the frame
             * control field are nonzero and equal to zero, respectively.
             */
            if (tal_frame_info->frame_ctrl & SRC_ADDR_MODE_MASK)
            {
                frame_header -= PAN_ID_LEN;

                convert_16_bit_to_byte_array(tal_frame_info->src_panid,
                                             frame_header);

                frame_length += PAN_ID_LEN;
            }
            else
            {
                /* Do not add source PAN ID */
            }
        }
    }
    else
    {
        /*
         * The frame to be created is a Beacon frame or a MAC command frame,
         * so include the  source PAN ID only if the source adress is present.
         */
        if (tal_frame_info->frame_ctrl & SRC_ADDR_MODE_MASK)
        {
            frame_header -= PAN_ID_LEN;

            convert_16_bit_to_byte_array(tal_frame_info->src_panid,
                                         frame_header);

            frame_length += PAN_ID_LEN;
        }
    }

    frame_format_mask = tal_frame_info->frame_ctrl & DEST_ADDR_MODE_MASK;

    /*
     * The destination address shall be included in the MAC frame only, if the
     * destination addressing mode subfield of the frame control field is
     * nonzero.
     */
    if (DEST_EXT_ADDR_MODE == frame_format_mask)
    {
        frame_header -= EXT_ADDR_LEN;

        convert_64_bit_to_byte_array(tal_frame_info->dest_address,
                                     frame_header);

        frame_length += EXT_ADDR_LEN;
    }
    else if (DEST_SHORT_ADDR_MODE == frame_format_mask)
    {
        frame_header -= SHORT_ADDR_LEN;

        convert_16_bit_to_byte_array(tal_frame_info->dest_address,
                                     frame_header);

        frame_length += SHORT_ADDR_LEN;
    }

    if (BEACON_FRAME != (tal_frame_info->frame_ctrl & FRAME_TYPE_MASK))
    {
        /*
         * The destination PAN ID shall be included in the MAC frame only,
         * if the destination addressing mode subfield of the frame control
         * field is nonzero.
         */
        if (tal_frame_info->frame_ctrl & DEST_ADDR_MODE_MASK)
        {
            frame_header -= PAN_ID_LEN;

            convert_16_bit_to_byte_array(tal_frame_info->dest_panid,
                                         frame_header);

            frame_length += PAN_ID_LEN;
        }
    }

    /*
     * As the frame header creation is backwards and the next field to be
     * updated is the sequence number, update the sequence number into the
     * frame header by decrementing frame_header by one.
     */
    frame_header--;

    *frame_header = tal_frame_info->seq_num;

    /*
     * The frame length is incremented to includ the length of the
     * sequence number.
     */
    frame_length++;

    /*
     * The next field to be updated is the frame control field of the
     * frame header.
     */
    frame_header -= FCF_LEN;

    convert_16_bit_to_byte_array(tal_frame_info->frame_ctrl,
                                 frame_header);

    /* Include space for FCS and FCF field. */
    frame_length += FCF_LEN + FCS_LEN;

    /*
     * The PHY header contains the length of the frame to be transmitted.
     * This is appended to the created frame.
     */
    frame_header--;

    *frame_header = frame_length;

    return (frame_header);
}  /* frame_create() */


/**
 * @brief Sends frame
 *
 * @param frame_tx Pointer to prepared frame
 * @param use_csma Flag indicating if CSMA is requested
 * @param tx_retries Flag indicating if transmission retries are requested
 *                   by the MAC layer
 */
void send_frame(uint8_t *frame_tx, bool use_csma, bool tx_retries)
{
    tal_trx_status_t trx_status;

    // configure tx according to tx_retries
    if (tx_retries)
    {
        pal_trx_bit_write(SR_MAX_FRAME_RETRIES, aMaxFrameRetries);
    }
    else
    {
        pal_trx_bit_write(SR_MAX_FRAME_RETRIES, 0);
    }

    // configure tx according to csma usage
    if (use_csma)
    {
        pal_trx_bit_write(SR_MAX_CSMA_RETRIES, tal_pib_MaxCSMABackoffs);
    }
    else    // no csma is required
    {
        pal_trx_bit_write(SR_MAX_CSMA_RETRIES, 7);
    }

    do
    {
        trx_status = set_trx_state(CMD_TX_ARET_ON);
    } while (trx_status != TX_ARET_ON);

    ENTER_CRITICAL_REGION();    // prevent from buffer underrun

    /* Toggle the SLP_TR pin triggering transmission. */
    pal_gpio_set(SLP_TR_PIN, HIGH);
    pal_gpio_set(SLP_TR_PIN, LOW);

    /*
     * Send the frame to the transceiver.
     * Note: The PhyHeader is the first byte of the frame to
     * be sent to the transceiver and this contains the frame
     * length.
     */
    pal_trx_frame_write(frame_tx, frame_tx[0]);

    tal_state = TAL_TX_AUTO;

    LEAVE_CRITICAL_REGION();
}


/**
 * @brief Handles interrupts issued due to end of transmission
 */
void handle_tx_end_irq(void)
{
#if ((!defined RFD) && (!defined NOBEACON))
    if (tal_beacon_transmission)
    {
        tal_beacon_transmission = false;

        if (tal_csma_state == BACKOFF_WAITING_FOR_BEACON)
        {
			// Slotted CSMA has been waiting for a beacon, now it can continue.
            tal_csma_state = CSMA_HANDLE_BEACON;
        }
    }
	else
#endif
	{
	    /* Read trac status before enabling RX_AACK_ON. */
	    trx_trac_status = (trx_trac_status_t)pal_trx_bit_read(SR_TRAC_STATUS);

#ifndef NOBEACON
	    if (tal_csma_state == FRAME_SENDING)    // Transmission was issued by slotted CSMA
	    {
	        tal_state = TAL_SLOTTED_CSMA;

	        /* Map status message of transceiver to TAL constants. */
	        switch (trx_trac_status)
	        {
	            case TRAC_SUCCESS_DATA_PENDING:
	                tal_csma_state = TX_DONE_FRAME_PENDING;
	                 break;

	            case TRAC_SUCCESS:
	                tal_csma_state = TX_DONE_SUCCESS;
	                break;

	            case TRAC_CHANNEL_ACCESS_FAILURE:
	                tal_csma_state = CSMA_ACCESS_FAILURE;
	                break;

	            case TRAC_NO_ACK:
	                tal_csma_state = TX_DONE_NO_ACK;
	                break;

	            case TRAC_INVALID:  /* Handle this in the same way as default. */
	            default:
	                ASSERT("not handled trac status" == 0);
	                tal_csma_state = CSMA_ACCESS_FAILURE;
	                break;
	        }
	    }
	    else
#endif
	    // Trx has handled the entire transmission incl. CSMA
	    {
	        tal_state = TAL_TX_DONE;    // Further handling is done by tx_done_handling()
	    }
	}

    /*
     * After transmission has finished, switch receiver on again.
     * Check if receive buffer is available.
     */
    if (NULL == tal_rx_buffer)
    {
        /* Use a fast state change instead of set_trx_state(). */
        pal_trx_reg_write(RG_TRX_STATE, CMD_PLL_ON);
        tal_rx_on_required = true;
    }
    else
    {
        pal_trx_reg_write(RG_TRX_STATE, CMD_RX_AACK_ON);
    }
}


/**
 * @brief Prepares the beacon frame to be sent at the start of superframe
 *
 * This function prepares the beacon frame to be sent at the start of
 * the superframe
 *
 * @param mac_frame_info Pointer to the frame_info_t structure
 */
#if ((!defined RFD) && (!defined NOBEACON))
void tal_prepare_beacon(frame_info_t *mac_frame_info)
{
    /*
     * Create the beacon frame and buffer the beacon frame to be sent later
     * when tal_tx_beacon() is called.
     */
    beacon_frame = frame_create(mac_frame_info);
}
#endif


/**
 * @brief Beacon frame transmission
 */
#if ((!defined RFD) && (!defined NOBEACON))
void tal_tx_beacon(void)
{
    tal_trx_status_t trx_status;

    /*
     * Avoid that the beacon is transmitted while transmitting
     * a frame using slotted CSMA.
     */
    if (tal_state == TAL_TX_AUTO)
    {
        ASSERT("trying to transmit while slotted CSMA transmits or wait for an ACK" == 0);
        return;
    }

    /* Send the pre-created beacon frame to the transceiver. */
    do
    {
        trx_status = set_trx_state(CMD_FORCE_PLL_ON);
#if (DEBUG > 1)
        if (trx_status != PLL_ON)
        {
            ASSERT("Force PLL_ON failed for beacon transmission" == 0);
        }
#endif
    } while (trx_status != PLL_ON);

    // @TODO wait for talbeaconTxTime

    ENTER_CRITICAL_REGION();    // prevent from buffer underrun

    /* Toggle the SLP_TR pin triggering transmission. */
    pal_gpio_set(SLP_TR_PIN, HIGH);
    pal_gpio_set(SLP_TR_PIN, LOW);

    /*
     * Send the frame to the transceiver.
     * Note: The PhyHeader is the first byte of the frame to
     * be sent to the transceiver and this contains the frame
     * length.
     */
    pal_trx_frame_write(beacon_frame, beacon_frame[0]);

    tal_beacon_transmission = true;

    LEAVE_CRITICAL_REGION();
}
#endif



/* EOF */

