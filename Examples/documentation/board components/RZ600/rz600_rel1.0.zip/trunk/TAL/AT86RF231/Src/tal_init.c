/**
 * @file tal_init.c
 *
 * @brief This file implements functions for initializing TAL.
 *
 * $Id: tal_init.c 12240 2008-11-26 07:11:22Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === INCLUDES ============================================================ */

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include "platform_types.h"
#include "return_val.h"
#include "tal.h"
#include "ieee_const.h"
#include "tal_pib.h"
#include "pal.h"
#include "tal_irq_handler.h"
#include "stack_config.h"
#include "bmm.h"
#include "qmm.h"
#include "pal.h"
#include "tal.h"
#include "tal_internal.h"
#include "tal_constants.h"
#include "at86rf231.h"
#include "tal_config.h"
#ifndef RFD
#include "ffd_data_structures.h"
#endif  /* FFD */
#ifndef NOBEACON
#include "tal_slotted_csma.h"
#endif
#ifdef ENABLE_TFA
#include "tfa.h"
#endif

/* === GLOBALS ============================================================= */


/* === PROTOTYPES ========================================================== */

static void trx_config(void);
static retval_t trx_reset(void);

/* === IMPLEMENTATION ====================================================== */

/**
 * @brief Initializes the TAL
 *
 * This function is called to initialize the TAL. The transceiver is
 * initialized, the TAL PIBs are set to their default values, and the TAL state
 * machine is set to TAL_IDLE state.
 *
 * @return SUCCESS if the transceiver state is changed to TRX_OFF and the
 *                 current device part number and version number are correct;
 *         FAILURE otherwise
 */
retval_t tal_init(void)
{
    /* Init the PAL and by this means also the transceiver interface */
    if (pal_init() != SUCCESS)
    {
        return FAILURE;
    }

    if (trx_init() != SUCCESS)
    {
        return FAILURE;
    }

#ifdef EXTERN_EEPROM_AVAILABLE
    pal_ps_get(EXTERN_EEPROM, PS_IEEE_ADDR, &tal_pib_IeeeAddress);
#else
    pal_ps_get(INTERN_EEPROM, PS_IEEE_ADDR, &tal_pib_IeeeAddress);
#endif

#ifndef SNIFFER
    // Check if a valid IEEE address is available.
    if ((tal_pib_IeeeAddress == 0x0000000000000000) ||
        (tal_pib_IeeeAddress == 0xFFFFFFFFFFFFFFFF))
    {
        return FAILURE;
    }
#endif

    if (trx_reset() != SUCCESS)
    {
        return FAILURE;
    }
    trx_config();

    pal_trx_reg_read(RG_IRQ_STATUS);    /* clear pending irqs, dummy read */

    /*
     * Configure interrupt handling.
     * Install a handler for the transceiver interrupt.
     */
    pal_trx_irq_init(TRX_MAIN_IRQ_HDLR_IDX, (void *)trx_irq_handler_cb);
    pal_trx_irq_enable(TRX_MAIN_IRQ_HDLR_IDX);     /* Enable transceiver interrupts. */

    /* Initialize the buffer management module and get a buffer to store reveived frames. */
    bmm_buffer_init();
    tal_rx_buffer = bmm_buffer_alloc(LARGE_BUFFER_SIZE);

    /* Init incoming frame queue */
    qmm_queue_init(&tal_incoming_frame_queue, TAL_INCOMING_FRAME_QUEUE_CAPACITY);

    /* Handle TAL's PIB values */
    init_tal_pib(); /* implementation can be found in 'tal_pib.c' */
    write_all_tal_pib_to_trx();  /* implementation can be found in 'tal_pib.c' */

#ifdef ENABLE_TFA
    tfa_init();
#endif

    tal_state = TAL_IDLE;   /* reset TAL state machine */
#ifndef NOBEACON
    tal_csma_state = CSMA_IDLE;
#endif
    /* The receiver is not requested to be switched on after tal_init. */
    tal_rx_on_required = false;

    return SUCCESS;
} /* tal_init() */


/**
 * @brief Initializes the transceiver
 *
 * This function is called to initialize the transceiver.
 *
 * @return SUCCESS if the transceiver state is changed to TRX_OFF and the
 *                 current device part number and version number are correct;
 *         FAILURE otherwise
 */
retval_t trx_init(void)
{
    tal_trx_status_t trx_status;
    uint8_t poll_counter = 0;

    pal_gpio_set(RST_PIN, HIGH);
    pal_gpio_set(SLP_TR_PIN, LOW);

    pal_timer_delay(P_ON_TO_CLKM_AVAILABLE);   // wait until TRX_OFF can be written
    pal_trx_reg_write(RG_TRX_STATE, CMD_TRX_OFF);
    
    /* verify that trx has reached TRX_OFF */
    do
    {
        trx_status = (tal_trx_status_t)pal_trx_bit_read(SR_TRX_STATUS);
        poll_counter++;
        if (poll_counter == 0xFF)
        {
#if (DEBUG > 0)
            pal_alert();
#endif
            return FAILURE;
        }
    } while (trx_status != TRX_OFF);

    tal_trx_status = TRX_OFF;

    /* Check if AT86RF231 is connected; omit manufacturer id check */
    if ((AT86RF231_PART_NUM != pal_trx_reg_read(RG_PART_NUM)) ||
        (AT86RF231_VERSION_NUM != pal_trx_reg_read(RG_VERSION_NUM)))
    {
        return FAILURE;
    }


    return SUCCESS;
}


/**
 * @brief Configures the transceiver
 *
 * This function is called to configure the transceiver after reset.
 */
static void trx_config(void)
{
    uint16_t rand_value;

    /* Set pin driver strength */
    pal_trx_bit_write(SR_PAD_IO_CLKM, PAD_CLKM_2_MA);
    pal_trx_bit_write(SR_CLKM_SHA_SEL, CLKM_SHA_DISABLE);
    pal_trx_bit_write(SR_CLKM_CTRL, CLKM_1MHZ);

    /*
     * Init the SEED value of the CSMA backoff algorithm.
     * The rand algorithm gets some random seed initialization during timer initialization.
     */
    rand_value = (uint16_t)rand();
    pal_trx_reg_write(RG_CSMA_SEED_0, (uint8_t)rand_value);
    pal_trx_bit_write(SR_CSMA_SEED_1, (uint8_t)(rand_value >> 8));

    /*
     * Since the TAL currently supports MAC-2003 only, frames with version number
     * indicating MAC-2006 are not acknowledged.
     */
    pal_trx_bit_write(SR_AACK_FVN_MODE, FRAME_VERSION_0);
    pal_trx_bit_write(SR_AACK_SET_PD, PD_ACK_BIT_SET_ENABLE); /* ACKs for data requests, indicate pending data */
    pal_trx_bit_write(SR_RX_SAFE_MODE, RX_SAFE_MODE_ENABLE);    /* Enable buffer protection mode */
    pal_trx_bit_write(SR_IRQ_MASK_MODE, IRQ_MASK_MODE_ON); /* Enable poll mode */
    pal_trx_reg_write(RG_IRQ_MASK, TRX_IRQ_DEFAULT);    /* The TRX_END interrupt of the transceiver is enabled. */
    pal_trx_bit_write(SR_TX_AUTO_CRC_ON, TX_AUTO_CRC_ENABLE); /* Enable auto CRC calculation */

#ifdef ANTENNA_DIVERSITY
    // Use antenna diversity
    pal_trx_bit_write(SR_ANT_CTRL, ANTENNA_DEFAULT);
    pal_trx_bit_write(SR_PDT_THRES, THRES_ANT_DIV_ENABLE);
    pal_trx_bit_write(SR_ANT_DIV_EN, ANT_DIV_ENABLE);
    pal_trx_bit_write(SR_ANT_EXT_SW_EN, ANT_EXT_SW_SWITCH_ENABLE);
#else
    // Use timestamping
    //pal_trx_bit_write(SR_IRQ_2_EXT_EN, TIMESTAMPING_ENABLE);
#endif
#ifdef ENABLE_TFA
#ifdef SPECIAL_PEER
    tfa_pib_set(TFA_PIB_RX_SENS, (uint8_t *)0x08);   // 0x08 = - 70 dBm; 0x0B = -61 dBm
#endif
#endif

}


/**
 * @brief Reset transceiver
 *
 * @return SUCCESS if the transceiver state is changed to TRX_OFF
 *         FAILURE otherwise
 */
static retval_t trx_reset(void)
{
    tal_trx_status_t trx_status;
    uint8_t poll_counter = 0;
#ifdef EXTERN_EEPROM_AVAILABLE
    uint8_t xtal_trim_value;
#endif

    /* Get trim value for 16 MHz xtal; needs to be done before reset */
#ifdef EXTERN_EEPROM_AVAILABLE
    pal_ps_get(EXTERN_EEPROM, PS_XTAL_TRIM, &xtal_trim_value);
#endif

    /* trx might sleep, so wake it up */
    pal_gpio_set(SLP_TR_PIN, LOW);
    pal_timer_delay(SLEEP_TO_TRX_OFF_US);

    /* Apply reset pulse */
    pal_gpio_set(RST_PIN, LOW);
    pal_timer_delay(RST_PULSE_WIDTH_US);
    pal_gpio_set(RST_PIN, HIGH);

    /* verify that trx has reached TRX_OFF */
    do
    {
        trx_status = (tal_trx_status_t)pal_trx_bit_read(SR_TRX_STATUS);
        poll_counter++;
        if (poll_counter > 10)
        {
#if (DEBUG > 0)
            pal_alert();
#endif
            return FAILURE;
        }
    } while (trx_status != TRX_OFF);

    tal_trx_status = TRX_OFF;

    // Write 16MHz xtal trim value to trx.
    // It's only necessary if it differs from the reset value.
#ifdef EXTERN_EEPROM_AVAILABLE
    if (xtal_trim_value != 0x00)
    {
        pal_trx_bit_write(SR_XTAL_TRIM, xtal_trim_value);
    }
#endif

    return SUCCESS;
}


/**
 * @brief Resets TAL state machine and forces transceiver off
 *
 * This function resets the TAL state machine. The transceiver is turned off
 * using FORCE_TRX_OFF and tal_state is initialized to TAL_IDLE.
 * It aborts any ongoing transaction. Used for debugging purposes only.
 */
#if (DEBUG > 0)
void tal_trx_state_reset(void)
{
    set_trx_state(CMD_FORCE_TRX_OFF);
    tal_state = TAL_IDLE;
}
#endif


/**
 * @brief Resets TAL state machine and sets the default PIB values if requested
 *
 * @param set_default_pib Defines whether PIB values need to be set
 *                        to its default values
 *
 * @return SUCCESS if the transceiver state is changed to TRX_OFF
 *         FAILURE otherwise
 */
retval_t tal_reset(bool set_default_pib)
{
    ENTER_CRITICAL_REGION();

    if (set_default_pib)
    {
        /* Set the default PIB values */
        init_tal_pib(); /* implementation can be found in 'tal_pib.c' */
    }
    else
    {
        /* nothing to do - the current TAL PIB attribute values are used */
    }

    if (trx_reset() != SUCCESS)
    {
        return FAILURE;
    }
    trx_config();

    /* Clear all running TAL timers. */
    {
        uint8_t timer_id;

        for (timer_id = TAL_FIRST_TIMER_ID; timer_id <= TAL_LAST_TIMER_ID;
             timer_id++)
        {
            pal_timer_stop(timer_id);
        }
    }

    /* Clear TAL Incoming Frame queue and free used buffers. */
    if (tal_incoming_frame_queue.size > 0)
    {
        buffer_t *frame;

        while (tal_incoming_frame_queue.size > 0)
        {
            frame = qmm_queue_remove(&tal_incoming_frame_queue, NULL);
            if (NULL != frame)
            {
                bmm_buffer_free(frame);
            }
        }
    }

    /*
     * Write all PIB values to the transceiver
     * that are needed by the transceiver itself.
     */
    write_all_tal_pib_to_trx(); /* implementation can be found in 'tal_pib.c' */

#ifdef ENABLE_TFA
    tfa_reset(set_default_pib);
#endif

    tal_state = TAL_IDLE;

#ifndef NOBEACON
    tal_csma_state = CSMA_IDLE;
#endif
#if ((!defined RFD) && (!defined NOBEACON))
    tal_beacon_transmission = false;
#endif

    tal_rx_on_required = false;

    /*
     * Configure interrupt handling.
     * Install a handler for the transceiver interrupt.
     */
    pal_trx_irq_init(TRX_MAIN_IRQ_HDLR_IDX, (void *)trx_irq_handler_cb);
    pal_trx_irq_enable(TRX_MAIN_IRQ_HDLR_IDX);     /* Enable transceiver interrupts. */

    /* The pending transceiver interrupts on the microcontroller are cleared. */
    pal_trx_irq_flag_clr(TRX_MAIN_IRQ_HDLR_IDX);

    LEAVE_CRITICAL_REGION();

    return SUCCESS;
}



/* EOF */

