/**
 * @file tal_pib.c
 *
 * @brief This file handles the TAL PIB attributes, set/get and initialization
 *
 * $Id: tal_pib.c 12252 2008-11-26 12:06:43Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === INCLUDES ============================================================ */

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "platform_types.h"
#include "return_val.h"
#include "tal.h"
#include "ieee_const.h"
#include "tal_constants.h"
#include "tal_pib.h"
#include "at86rf231.h"
#include "pal.h"
#include "tal_internal.h"
#ifdef SPECIAL_PEER
#include "private_const.h"
#endif /* SPECIAL_PEER */

/* === TYPES =============================================================== */


/* === MACROS ============================================================== */

/*
 * Translation table converting register values to power levels (dBm).
 */
FLASH_DECLARE(static int8_t tx_pwr_table[16]) =
{
    3, /* 3.2 */
    2, /* 2.8 */
    2, /* 2.3 */
    1, /* 1.8 */
    1, /* 1.3 */
    0, /* 0.7 */
    0, /* 0.0 */
    -1,
    -2,
    -3,
    -4,
    -5,
    -7,
    -9,
    -12,
    -17,
};

/* === GLOBALS ============================================================= */


/* === PROTOTYPES ========================================================== */

static uint8_t limit_tx_pwr(uint8_t tal_pib_TransmitPower);
static uint8_t convert_phyTransmitPower_to_reg_value(uint8_t phyTransmitPower_value);

/* === IMPLEMENTATION ====================================================== */

/**
 * @brief Initialize the TAL PIB
 *
 * This function initializes the TAL information base attributes
 * to their default values.
 */
void init_tal_pib(void)
{
    tal_pib_MaxCSMABackoffs = TAL_MAX_CSMA_BACKOFFS_DEFAULT;
    tal_pib_MinBE = TAL_MINBE_DEFAULT;
    tal_pib_PANId = TAL_PANID_BC_DEFAULT;
    tal_pib_ShortAddress = TAL_SHORT_ADDRESS_DEFAULT;
    tal_pib_CurrentChannel = TAL_CURRENT_CHANNEL_DEFAULT;
    tal_pib_SupportedChannels = TRX_SUPPORTED_CHANNELS;
    tal_pib_TransmitPower = limit_tx_pwr(TAL_TRANSMIT_POWER_DEFAULT);
    tal_pib_CCAMode = TAL_CCA_MODE_DEFAULT;
    tal_pib_BattLifeExt = TAL_BATTERY_LIFE_EXTENSION_DEFAULT;
    tal_pib_PrivatePanCoordinator = TAL_PAN_COORDINATOR_DEFAULT;
    tal_pib_PrivateAssociated = TAL_PRIVATE_ASSOCIATED_DEFAULT;
    tal_pib_BeaconOrder = TAL_BEACON_ORDER_DEFAULT;
    tal_pib_SuperFrameOrder = TAL_SUPERFRAME_ORDER_DEFAULT;
    tal_pib_BeaconTxTime = TAL_BEACON_TX_TIME_DEFAULT;
    tal_pib_ACKWaitDuration = macAckWaitDuration_def;

    tal_pib_PrivateAssociated = false;

#ifdef SPECIAL_PEER
    tal_pib_PrivateCCAFailure = TAL_PRIVATE_CCA_FAILURE_DEFAULT;
    tal_pib_PrivateDisableACK = TAL_PRIVATE_DISABLE_ACK_DEFAULT;
#endif /* SPECIAL_PEER */
}


/**
 * @brief Write all shadow PIB variables to the transceiver
 *
 * This function writes all shadow PIB variables to the transceiver.
 * It is assumed that the radio does not sleep.
 */
void write_all_tal_pib_to_trx(void)
{
#if (PAL_GENERIC_TYPE==AVR32)
    pal_trx_reg_write(RG_PAN_ID_1, (uint8_t)tal_pib_PANId);
    pal_trx_reg_write(RG_PAN_ID_0, (uint8_t)(tal_pib_PANId >> 8));
    pal_trx_reg_write(RG_IEEE_ADDR_7, (uint8_t)tal_pib_IeeeAddress);
    pal_trx_reg_write(RG_IEEE_ADDR_6, (uint8_t)(tal_pib_IeeeAddress >> 8));
    pal_trx_reg_write(RG_IEEE_ADDR_5, (uint8_t)(tal_pib_IeeeAddress >> 16));
    pal_trx_reg_write(RG_IEEE_ADDR_4, (uint8_t)(tal_pib_IeeeAddress >> 24));
    pal_trx_reg_write(RG_IEEE_ADDR_3, (uint8_t)(tal_pib_IeeeAddress >> 32));
    pal_trx_reg_write(RG_IEEE_ADDR_2, (uint8_t)(tal_pib_IeeeAddress >> 40));
    pal_trx_reg_write(RG_IEEE_ADDR_1, (uint8_t)(tal_pib_IeeeAddress >> 48));
    pal_trx_reg_write(RG_IEEE_ADDR_0, (uint8_t)(tal_pib_IeeeAddress >> 56));
    pal_trx_reg_write(RG_SHORT_ADDR_1, (uint8_t)tal_pib_ShortAddress);
    pal_trx_reg_write(RG_SHORT_ADDR_0, (uint8_t)(tal_pib_ShortAddress >> 8));
#else
    pal_trx_reg_write(RG_PAN_ID_0, (uint8_t)tal_pib_PANId);
    pal_trx_reg_write(RG_PAN_ID_1, (uint8_t)(tal_pib_PANId >> 8));
    pal_trx_reg_write(RG_IEEE_ADDR_0, (uint8_t)tal_pib_IeeeAddress);
    pal_trx_reg_write(RG_IEEE_ADDR_1, (uint8_t)(tal_pib_IeeeAddress >> 8));
    pal_trx_reg_write(RG_IEEE_ADDR_2, (uint8_t)(tal_pib_IeeeAddress >> 16));
    pal_trx_reg_write(RG_IEEE_ADDR_3, (uint8_t)(tal_pib_IeeeAddress >> 24));
    pal_trx_reg_write(RG_IEEE_ADDR_4, (uint8_t)(tal_pib_IeeeAddress >> 32));
    pal_trx_reg_write(RG_IEEE_ADDR_5, (uint8_t)(tal_pib_IeeeAddress >> 40));
    pal_trx_reg_write(RG_IEEE_ADDR_6, (uint8_t)(tal_pib_IeeeAddress >> 48));
    pal_trx_reg_write(RG_IEEE_ADDR_7, (uint8_t)(tal_pib_IeeeAddress >> 56));
    pal_trx_reg_write(RG_SHORT_ADDR_0, (uint8_t)tal_pib_ShortAddress);
    pal_trx_reg_write(RG_SHORT_ADDR_1, (uint8_t)(tal_pib_ShortAddress >> 8));
#endif

    /* configure TX_ARET; CSMA and CCA */
    pal_trx_bit_write(SR_CCA_MODE, tal_pib_CCAMode);
    pal_trx_bit_write(SR_MIN_BE, tal_pib_MinBE);

    pal_trx_bit_write(SR_AACK_I_AM_COORD, tal_pib_PrivatePanCoordinator);

    /* set phy parameter */
    pal_trx_bit_write(SR_CHANNEL, tal_pib_CurrentChannel);
    {
        uint8_t reg_value;

        reg_value = convert_phyTransmitPower_to_reg_value(tal_pib_TransmitPower);
        pal_trx_bit_write(SR_TX_PWR, reg_value);
    }

#ifdef SPECIAL_PEER
    pal_trx_bit_write(SR_AACK_DIS_ACK, tal_pib_PrivateDisableACK);
#endif
}


/**
 * @brief Gets a TAL PIB attribute
 *
 * This function is called to retrieve the transceiver information base
 * attributes.
 *
 * @param[in] attribute TAL infobase attribute ID
 * @param[out] value TAL infobase attribute value
 *
 * @return UNSUPPORTED_ATTRIBUTE if the TAL infobase attribute is not found
 *         SUCCESS otherwise
 */
#if (HIGHEST_STACK_LAYER != MAC)
retval_t tal_pib_get(uint8_t attribute, void *value)
{
    switch (attribute)
    {
        case macMaxCSMABackoffs:
            *(uint8_t *)value = tal_pib_MaxCSMABackoffs;
            break;

        case macMinBE:
            *(uint8_t *)value = tal_pib_MinBE;
            break;

        case macPANId:
            *(uint16_t *)value = tal_pib_PANId;
            break;

        case macShortAddress:
            *(uint16_t *)value = tal_pib_ShortAddress;
            break;

        case phyCurrentChannel:
            *(uint8_t *)value = tal_pib_CurrentChannel;
            break;

        case phyChannelsSupported:
            *(uint32_t *)value = tal_pib_SupportedChannels;
            break;
#ifdef TAL_2006
        case phyCurrentPage:
            *(uint8_t *)value = tal_pib_CurrentPage;
            break;
#endif
        case phyTransmitPower:
            *(uint8_t *)value = tal_pib_TransmitPower;
            break;

        case phyCCAMode:
            *(uint8_t *)value = tal_pib_CCAMode;
            break;

        case macIeeeAddress:
            *(uint64_t *)value = tal_pib_IeeeAddress;
            break;
#ifdef SPECIAL_PEER
        case macPrivateCCAFailure:
            *(uint8_t *)value = tal_pib_PrivateCCAFailure;
            break;

        case macPrivateDisableACK:
            *(uint8_t *)value = tal_pib_PrivateDisableACK;
            break;
#endif
        case macBattLifeExt:
            *(bool *)value = tal_pib_BattLifeExt;
            break;

        case macBeaconOrder:
            *(uint8_t *)value = tal_pib_BeaconOrder;
            break;

        case macSuperframeOrder:
            *(uint8_t *)value = tal_pib_SuperFrameOrder;
            break;

        case macBeaconTxTime:
            *(uint32_t *)value = tal_pib_BeaconTxTime;
            break;

        case mac_i_pan_coordinator:
            *(bool *)value = tal_pib_PrivatePanCoordinator;
            break;

        case macPrivateAssociated:
            *(bool *)value = tal_pib_PrivateAssociated;
            break;

        case macAckWaitDuration:
            /*
             * AT86RF231 does not support changing this value w.r.t.
             * compliance operation.
             * The ACK timing can be reduced to 2 symbols using TFA function.
             */
            return UNSUPPORTED_ATTRIBUTE;

        default:
            /* Invalid attribute id */
            return UNSUPPORTED_ATTRIBUTE;
    }

    return SUCCESS;
} /* tal_pib_get() */
#endif  /* (HIGHEST_STACK_LAYER != MAC) */


/**
 * @brief Sets a TAL PIB attribute
 *
 * This function is called to set the transceiver information base
 * attributes.
 *
 * @param attribute TAL infobase attribute ID
 * @param value TAL infobase attribute value to be set
 *
 * @return UNSUPPORTED_ATTRIBUTE if the TAL info base attribute is not found
 *         BUSY if the TAL is not in TAL_IDLE state. An exception is
 *         macBeaconTxTime which can be accepted by TAL even if TAL is not
 *         in TAL_IDLE state.
 *         SUCCESS if the attempt to set the PIB attribute was successful
 *         TRX_ASLEEP if trx is in SLEEP mode and access to trx is required
 */
retval_t tal_pib_set(uint8_t attribute, void *value)
{
    /*
     * Do not allow any changes while ED or TX is done.
     * We allow changes during RX, but it's on the user's own risk.
     */
#ifndef RFD
    if (tal_state == TAL_ED_RUNNING)
    {
        ASSERT("TAL is busy" == 0);
        return BUSY;
    }
#endif

    /*
     * Distinguish between PIBs that need to be changed in trx directly
     * and those that are simple variable udpates.
     * Ensure that the transceiver is not in SLEEP.
     * If it is in SLEEP, change it to TRX_OFF.
     */

    switch (attribute)
    {
        case macBattLifeExt:
            tal_pib_BattLifeExt = *((bool *)value);
            break;

        case macBeaconOrder:
            tal_pib_BeaconOrder = *((uint8_t *)value);
            break;

        case macSuperframeOrder:
            tal_pib_SuperFrameOrder = *((uint8_t *)value);
            break;

        case macBeaconTxTime:
            tal_pib_BeaconTxTime = *((uint32_t *)value);
            break;

#ifdef SPECIAL_PEER
        case macPrivateCCAFailure:
            tal_pib_PrivateCCAFailure = *((uint8_t *)value);
            break;
#endif

        case macPrivateAssociated:
            tal_pib_PrivateAssociated = *((bool *)value);
            break;

        default:
            /*
             * Following PIBs require access to trx.
             * Therefore trx must be at least in TRX_OFF.
             */

            if (tal_trx_status == TRX_SLEEP)
            {
                /* While trx is in SLEEP, register cannot be accessed. */
                return TRX_ASLEEP;
            }

            switch (attribute)
            {
                case macMaxCSMABackoffs:
                    tal_pib_MaxCSMABackoffs = *((uint8_t *)value);
                    pal_trx_bit_write(SR_MAX_CSMA_RETRIES, tal_pib_MaxCSMABackoffs);
                    break;

                case macMinBE:
                    tal_pib_MinBE = *((uint8_t *)value);
                    pal_trx_bit_write(SR_MIN_BE, tal_pib_MinBE);
                    break;

                case macPANId:
                    tal_pib_PANId = *((uint16_t *)value);
#if (PAL_GENERIC_TYPE==AVR32)
                    pal_trx_reg_write(RG_PAN_ID_1, (uint8_t)tal_pib_PANId);
                    pal_trx_reg_write(RG_PAN_ID_0, (uint8_t)(tal_pib_PANId >> 8));
#else
                    pal_trx_reg_write(RG_PAN_ID_0, (uint8_t)tal_pib_PANId);
                    pal_trx_reg_write(RG_PAN_ID_1, (uint8_t)(tal_pib_PANId >> 8));
#endif
                    break;

                case macShortAddress:
                    tal_pib_ShortAddress = *((uint16_t *)value);
#if (PAL_GENERIC_TYPE==AVR32)
                    pal_trx_reg_write(RG_SHORT_ADDR_1, (uint8_t)tal_pib_ShortAddress);
                    pal_trx_reg_write(RG_SHORT_ADDR_0, (uint8_t)(tal_pib_ShortAddress >> 8));
#else
                    pal_trx_reg_write(RG_SHORT_ADDR_0, (uint8_t)tal_pib_ShortAddress);
                    pal_trx_reg_write(RG_SHORT_ADDR_1, (uint8_t)(tal_pib_ShortAddress >> 8));
#endif
                    break;

                case phyCurrentChannel:
                    if (tal_state != TAL_IDLE)
                    {
                        return BUSY;
                    }
                    if ((uint32_t)TRX_SUPPORTED_CHANNELS & ((uint32_t)0x01 << *((uint8_t *)value)))
                    {
                        tal_pib_CurrentChannel = *((uint8_t *)value);
                        pal_trx_bit_write(SR_CHANNEL, tal_pib_CurrentChannel);
                    }
                    else
                    {
                        return INVALID_PARAMETER;
                    }
                    break;
#ifdef TAL_2006
                case phyCurrentPage:
                    if (tal_state != TAL_IDLE)
                    {
                        return BUSY;
                    }
                    else
                    {
                        tal_trx_status_t trx_state;
                        // Changing the channel, channel page or modulation requires that TRX is in TRX_OFF.
                        do
                        {
                            trx_state = set_trx_state(CMD_TRX_OFF);
                        } while (trx_state != TRX_OFF);
                    }

                    {
                        uint8_t page;

                        page = *((uint8_t *)value);

                        switch (page)
                        {
                            case 0: /* compliant O-QPSK */
                                pal_trx_bit_write(SR_OQPSK_DATA_RATE, ALTRATE_250KBPS);
                                // Apply compliant ACK timing
                                pal_trx_bit_write(SR_AACK_ACK_TIME, AACK_ACK_TIME_12_SYMBOLS);
                                break;
#ifdef HIGH_DATA_RATE_SUPPORT
                            case 2: /* non-compliant OQPSK mode 1 */
                                pal_trx_bit_write(SR_OQPSK_DATA_RATE, ALTRATE_500KBPS);
                                // Apply reduced ACK timing
                                pal_trx_bit_write(SR_AACK_ACK_TIME, AACK_ACK_TIME_2_SYMBOLS);
                                break;

                            case 16:    /* non-compliant OQPSK mode 2 */
                                pal_trx_bit_write(SR_OQPSK_DATA_RATE, ALTRATE_1MBPS);
                                // Apply reduced ACK timing
                                pal_trx_bit_write(SR_AACK_ACK_TIME, AACK_ACK_TIME_2_SYMBOLS);
                                break;

                            case 17:    /* non-compliant OQPSK mode 3 */
                                pal_trx_bit_write(SR_OQPSK_DATA_RATE, ALTRATE_2MBPS);
                                // Apply reduced ACK timing
                                pal_trx_bit_write(SR_AACK_ACK_TIME, AACK_ACK_TIME_2_SYMBOLS);
                                break;
#endif
                            default:
                                return INVALID_PARAMETER;
                        }
                    }

                    tal_pib_CurrentPage = *((uint8_t *)value);
                    break;
#endif
                case phyTransmitPower:
                    {
                        uint8_t reg_value;

                        tal_pib_TransmitPower = *((uint8_t *)value);

                        /* Limit tal_pib_TransmitPower to max/min trx values */
                        tal_pib_TransmitPower = limit_tx_pwr(tal_pib_TransmitPower);
                        reg_value = convert_phyTransmitPower_to_reg_value(tal_pib_TransmitPower);
                        pal_trx_bit_write(SR_TX_PWR, reg_value);
                    }
                    break;

                case phyCCAMode:
                    tal_pib_CCAMode = *((uint8_t *)value);
                    pal_trx_bit_write(SR_CCA_MODE, tal_pib_CCAMode);
                    break;

                case macIeeeAddress:
                    tal_pib_IeeeAddress = *((uint64_t *)value);
#if (PAL_GENERIC_TYPE==AVR32)
                    pal_trx_reg_write(RG_IEEE_ADDR_7, (uint8_t)tal_pib_IeeeAddress);
                    pal_trx_reg_write(RG_IEEE_ADDR_6, (uint8_t)(tal_pib_IeeeAddress >> 8));
                    pal_trx_reg_write(RG_IEEE_ADDR_5, (uint8_t)(tal_pib_IeeeAddress >> 16));
                    pal_trx_reg_write(RG_IEEE_ADDR_4, (uint8_t)(tal_pib_IeeeAddress >> 24));
                    pal_trx_reg_write(RG_IEEE_ADDR_3, (uint8_t)(tal_pib_IeeeAddress >> 32));
                    pal_trx_reg_write(RG_IEEE_ADDR_2, (uint8_t)(tal_pib_IeeeAddress >> 40));
                    pal_trx_reg_write(RG_IEEE_ADDR_1, (uint8_t)(tal_pib_IeeeAddress >> 48));
                    pal_trx_reg_write(RG_IEEE_ADDR_0, (uint8_t)(tal_pib_IeeeAddress >> 56));
#else
                    pal_trx_reg_write(RG_IEEE_ADDR_0, (uint8_t)tal_pib_IeeeAddress);
                    pal_trx_reg_write(RG_IEEE_ADDR_1, (uint8_t)(tal_pib_IeeeAddress >> 8));
                    pal_trx_reg_write(RG_IEEE_ADDR_2, (uint8_t)(tal_pib_IeeeAddress >> 16));
                    pal_trx_reg_write(RG_IEEE_ADDR_3, (uint8_t)(tal_pib_IeeeAddress >> 24));
                    pal_trx_reg_write(RG_IEEE_ADDR_4, (uint8_t)(tal_pib_IeeeAddress >> 32));
                    pal_trx_reg_write(RG_IEEE_ADDR_5, (uint8_t)(tal_pib_IeeeAddress >> 40));
                    pal_trx_reg_write(RG_IEEE_ADDR_6, (uint8_t)(tal_pib_IeeeAddress >> 48));
                    pal_trx_reg_write(RG_IEEE_ADDR_7, (uint8_t)(tal_pib_IeeeAddress >> 56));
#endif
                    break;

#ifdef SPECIAL_PEER
                case macPrivateDisableACK:
                    tal_pib_PrivateDisableACK = *((uint8_t *)value);
                    pal_trx_bit_write(SR_AACK_DIS_ACK, tal_pib_PrivateDisableACK);
                    break;
#endif

                case mac_i_pan_coordinator:
                    tal_pib_PrivatePanCoordinator = *((bool *)value);
                    pal_trx_bit_write(SR_AACK_I_AM_COORD, tal_pib_PrivatePanCoordinator);
                    break;

                case macAckWaitDuration:
                    /*
                     * AT86RF231 does not support changing this value w.r.t.
                     * compliance operation.
                     * The ACK timing can be reduced to 2 symbols using TFA function.
                     */
                    return UNSUPPORTED_ATTRIBUTE;

                default:
                    return UNSUPPORTED_ATTRIBUTE;
            }

            break; /* end of 'default' from 'switch (attribute)' */
    }
    return SUCCESS;
} /* tal_pib_set() */


/**
 * @brief Limit the phyTransmitPower to the trx limits
 *
 * @param phyTransmitPower phyTransmitPower value
 *
 * @return limited tal_pib_TransmitPower
 */
static uint8_t limit_tx_pwr(uint8_t tal_pib_TransmitPower)
{
    uint8_t ret_val = tal_pib_TransmitPower;
    int8_t dbm_value;

    dbm_value = CONV_phyTransmitPower_TO_DBM(tal_pib_TransmitPower);
    if (dbm_value > PGM_READ_BYTE(&tx_pwr_table[0]))
    {
        dbm_value = PGM_READ_BYTE(&tx_pwr_table[0]);
        ret_val = CONV_DBM_TO_phyTransmitPower(dbm_value);

    }
    else if (dbm_value < PGM_READ_BYTE(&tx_pwr_table[sizeof(tx_pwr_table)-1]))
    {
        dbm_value = PGM_READ_BYTE(&tx_pwr_table[sizeof(tx_pwr_table)-1]);
        ret_val = CONV_DBM_TO_phyTransmitPower(dbm_value);
    }

    return (ret_val | TX_PWR_TOLERANCE);
}


/**
 * @brief Converts a phyTransmitPower value to a register value
 *
 * @param phyTransmitPower_value phyTransmitPower value
 *
 * @return register value
 */
static uint8_t convert_phyTransmitPower_to_reg_value(uint8_t phyTransmitPower_value)
{
    int8_t dbm_value;
    uint8_t i;
    int8_t trx_tx_level;

    dbm_value = CONV_phyTransmitPower_TO_DBM(phyTransmitPower_value);

    /* Compare to the register value to identify the value that matches. */
    for (i = 0; i < sizeof(tx_pwr_table); i++)
    {
        trx_tx_level = PGM_READ_BYTE(&tx_pwr_table[i]);
        if (trx_tx_level <= dbm_value)
        {
            if (trx_tx_level < dbm_value)
            {
                return (i - 1);
            }
            return i;
        }
    }

    /* This code should never be reached. */
    return 0;
}


/* EOF */
