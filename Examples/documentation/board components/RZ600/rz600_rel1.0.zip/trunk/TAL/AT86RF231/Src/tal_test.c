#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "tal.h"
#include "tal_internal.h"
#include "ieee_const.h"
#include "pal.h"


static uint8_t tst_frame[127];


void tal_cw_tst_mode(bool pos_offset)
{
    pal_trx_irq_enable(TRX_MAIN_IRQ_HDLR_IDX);
    (tal_trx_status_t)set_trx_state(CMD_PLL_ON);
    pal_trx_bit_write(SR_TX_AUTO_CRC_ON, 0);
    pal_trx_reg_write(0x36, 15);
    pal_trx_bit_write(SR_OQPSK_DATA_RATE, 3);
    pal_trx_reg_write(RG_RX_CTRL, 167);
    if (pos_offset == true) {
        memset(tst_frame, sizeof(tst_frame), 0xFF);
    } else {
        memset(tst_frame, sizeof(tst_frame), 0x00);
    }
    
    pal_trx_frame_write(tst_frame, sizeof(tst_frame));
    pal_trx_reg_write(RG_PART_NUM, 84);
    pal_trx_reg_write(RG_PART_NUM, 70);
    pal_trx_bit_write(SR_TRX_CMD, CMD_TX_START);
}


void tal_pbrs_tst_mode(void)
{
    (tal_trx_status_t)set_trx_state(CMD_PLL_ON);
    pal_trx_bit_write(SR_TX_AUTO_CRC_ON, 0);
    pal_trx_reg_write(0x36, 15);
    
    pal_trx_frame_write(tst_frame, sizeof(tst_frame));
    pal_trx_reg_write(RG_PART_NUM, 84);
    pal_trx_reg_write(RG_PART_NUM, 70);
    pal_trx_bit_write(SR_TRX_CMD, CMD_TX_START);
}


void tal_tst_stop(void)
{
    pal_trx_reg_write(RG_PART_NUM, 0x00);
    tal_tst_reset();
}


void tal_tst_reset(void)
{
    pal_gpio_set(RST_PIN, LOW);
    pal_gpio_set(SLP_TR_PIN, LOW);

    pal_gpio_set(RST_PIN, HIGH);
    
    pal_timer_delay(37);
}


bool tal_tst_init(void)
{
#if 0
    PAL_RST_HIGH();
    PAL_SLP_TR_LOW();

    pal_timer_delay(P_ON_TO_CLKM_AVAILABLE);

    /* Apply reset pulse */
    PAL_RST_LOW();
    pal_timer_delay(RST_PULSE_WIDTH_US);
    PAL_RST_HIGH();

    /* Verify that TRX_OFF can be written */
    do
    {
        if (poll_counter == 0xFF)
        {
            return FAILURE;
        }
        //poll_counter++;
        /* Check if AT86RF231 is connected; omit manufacturer id check */
    } while ((pal_trx_reg_read(RG_VERSION_NUM) != AT86RF231_VERSION_NUM) &&
             (pal_trx_reg_read(RG_PART_NUM) != AT86RF231_PART_NUM));

    pal_trx_reg_write(RG_TRX_STATE, CMD_TRX_OFF);

    /* verify that trx has reached TRX_OFF */
    poll_counter = 0;
    do
    {
        trx_status = (tal_trx_status_t)pal_trx_bit_read(SR_TRX_STATUS);
        if (poll_counter == 0xFF)
        {
#if (DEBUG > 0)
            pal_alert();
#endif
            return FAILURE;
        }
        poll_counter++;
    } while (trx_status != TRX_OFF);

    tal_trx_status = TRX_OFF;
#endif
    return MAC_SUCCESS;
}