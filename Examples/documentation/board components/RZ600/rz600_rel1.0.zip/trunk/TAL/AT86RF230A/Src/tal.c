/**
 * @file tal.c
 *
 * @brief This file implements the TAL main state machine
 *
 * $Id: tal.c 11738 2008-11-03 14:37:25Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================= */

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "platform_types.h"
#include "return_val.h"
#include "bmm.h"
#include "qmm.h"
#include "tal.h"
#include "pal.h"
#include "ieee_const.h"
#ifndef RFD
#include "ffd_data_structures.h"
#endif  /* FFD */
#include "stack_config.h"
#include "tal_internal.h"
#include "tal_rx.h"
#include "tal_tx.h"

/* === Macros =============================================================== */


/* === Globals ============================================================== */

/**
 * Indicates whether the buffer is available to receive the incoming frames.
 */
volatile bool tal_rx_buf_available;

/**
 * Indicates if an acknowledgement frame is expected for the
 * transmitted frame.
 */
volatile bool tal_ack_expected;

/**
 * Indicates if the TRX_END IRQ is received from the transceiver for a sent
 * frame.
 */
volatile bool tal_tx_completed;

/**
 * Indicates the state of the transceiver before switching OFF the receiver due
 * to buffer unavailability.
 */
volatile bool tal_rx_on;

/**
 * Holds the current state of the TAL.
 */
volatile uint8_t tal_state = TAL_IDLE;

/**
 * Holds the state of TAL while performing beacon transmission.
 */
volatile uint8_t tal_previous_state = TAL_IDLE;

/**
 * Holds the sequence number of the received acknowledgement frame.
 */
volatile uint8_t tal_received_ack_dsn;

/**
 * Holds the received acknowledgement frame information.
 * Bit 0 - Set on receiving an acknowledgement frame,
 * Bit 1 - Set if the frame pending bit is set for the received acknowledgement
 * frame.
 */
volatile uint8_t tal_ack_status;

/**
 * Indicates that the frame to be transmitted is an association request
 * frame.
 */
bool tal_unslotted_csma_required;

/**
 * Holds the pointer of the frame created by TAL to be sent to
 * the transceiver.
 */
uint8_t *tal_frame_to_tx;

/**
 * Holds the pointer to buffer allocated by TAL to receive the incoming frame.
 */
buffer_t *tal_rx_buffer = NULL;

/**
 * Holds the incoming frames waiting to be processed by TAL.
 */
queue_t tal_incoming_frame_queue;


/* PIB values that are stored by the TAL */

/**
 * Holds the Current PHY channel.
 */
uint8_t tal_pib_CurrentChannel;

/**
 * Supported channels
 */
uint32_t tal_pib_SupportedChannels;

/**
 * Current transmit power.
 * Value represents transceiver's register setting with inverse tendency.
 * I.e. highest output power is set with a value of 0x00
 * and lowest output power is set with a value of 0x0A.
 * Check transceiver's datasheet (see TX_PWR) for further information.
 */
uint8_t tal_pib_TransmitPower;

/**
 * Holds the current CCA Mode.
 */
uint8_t tal_pib_CCAMode;

/**
 * macACKWaitDuration.
 */
uint8_t tal_pib_ACKWaitDuration;

/**
 * Indicates if the current device is a PAN coordinator or not.
 */
bool tal_pib_PrivatePanCoordinator;

/**
 * Holds the 64 bit (IEEE) unique address of the current device.
 */
uint64_t tal_pib_IeeeAddress;

/**
 * Holds the maximum number of back-off that the CSMA-CA algorithm will attempt
 * before declaring CHANNEL_ACCESS_FAILURE.
 */
uint8_t tal_pib_MaxCSMABackoffs;

/**
 * Holds the minimum value of the back-off exponent BE, used in the CSMA-CA
 * algorithm.
 */
uint8_t tal_pib_MinBE;

/**
 * Holds the 16-bit PAN ID of the current device.
 */
uint16_t tal_pib_PANId;

/**
 * Holds the 16-bit short address assigned to the current device.
 */
uint16_t tal_pib_ShortAddress;

/**
 * Indicates if the battery life extension is enabled for the current device.
 */
bool tal_pib_BattLifeExt;

/**
 * Holds the Specification of how often the coordinator transmits a beacon.
 */
uint8_t tal_pib_BeaconOrder;

/**
 * Holds the duration of the active portion of the superframe.
 */
uint8_t tal_pib_SuperFrameOrder;

/**
 * Holds the time at which last beacon was transmitted or received.
 */
uint32_t tal_pib_BeaconTxTime;

#ifdef SPECIAL_PEER
/**
 * Private TAL PIB attribute to disable ACK sending.
 * Value 0 implements normal ACK sending. Value 255 disables ACK
 * sending completely. Any other value will arrange for the
 * respective number of ACKs from being sent.
 */
uint8_t tal_pib_PrivateDisableACK;

/**
 * Private TAL PIB attribute to generate a CCA Channel Access Failure.
 * Value 0 implements normal CCA behaviour.
 * Value 1 leads to CCA Channel Access Failure.
 * Any other value will also implement normal CCA behaviour.
 */
uint8_t tal_pib_PrivateCCAFailure;

#endif /* SPECIAL_PEER */

/* === Prototypes =========================================================== */

static void alloc_buf_rx_on(void);

/* === Implementation ======================================================= */

/**
 * @brief TAL main state machine
 *
 * This function
 * 1) Checks and allocates the receive buffer.
 * 2) Processes the TAL incoming frame queue.
 * 3) Implements the TAL state machine.
 */
void tal_task(void)
{
    if (!tal_rx_buf_available)
    {
        /*
         * The receive buffer is not available, allocate a buffer for
         * frame reception.
         */
        alloc_buf_rx_on();
    }

    /* The incoming_frame_queue is checked for any pending frames. */
    if (tal_incoming_frame_queue.size > 0)
    {
        buffer_t *frame;

        /* The pending frame is removed from the queue. */
        frame = qmm_queue_remove(&tal_incoming_frame_queue, NULL);
#if (DEBUG > 0)
        ASSERT(NULL != frame);
#endif
        if (NULL != frame)
        {
            process_incoming_frame(frame);
        }
    }

    switch (tal_state)
    {
        case TAL_IDLE:
#ifndef RFD
        case TAL_ED:
#endif
        case TAL_SLEEP:
            /* Do nothing. */
            break;

        case TAL_TX_FRAME:
            /* Called to transmit a frame. */
            tx_state_handling();
            break;

#ifndef RFD
#ifndef NOBEACON
        case TAL_TX_BEACON:
            /*
             * The state will be TAL_TX_BEACON until the beacon frame is
             * completely sent by the transceiver.
             */
            if (beacon_tx_handling())
            {
                /*
                 * The beacon frame transmission complete, restore the
                 * TAL state.
                 */
                tal_state = tal_previous_state;
            }
            break;
#endif
#endif

        default:
#if (DEBUG > 0)
            ASSERT("Unexpected TAL state" == 0);
#endif
            break;
    }
} /* tal_task() */


/*
 * @brief Allocate buffer to receive the incoming frames.
 *
 * This function checks for the availability of buffers for receiving the
 * incoming frames. If the buffer is allocated successfully, then the receiver
 * is switched ON.
 */
static void alloc_buf_rx_on(void)
{
    tal_rx_buffer = bmm_buffer_alloc(LARGE_BUFFER_SIZE);

    /* Check if receive buffer is available */
    if (NULL != tal_rx_buffer)
    {
        /*
         * The receive buffer is allocated, set the flag tal_rx_buf_available
         * to true.
         */
        tal_rx_buf_available = true;

        /*
         * The receiver is switched ON only if the state prior to switching OFF
         * the transceiver was RX ON.
         */
        if (tal_rx_on)
        {
            while (PHY_RX_ON != set_trx_state(PHY_RX_ON));
        }
    }
}

/* EOF */
