/**
 * @file tal_ed.c
 *
 * @brief This module implements ED Scan on a specified channel
 *
 * $Id: tal_ed.c 11791 2008-11-04 17:49:11Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================= */

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include "platform_types.h"
#include "return_val.h"
#include "bmm.h"
#include "tal.h"
#include "ieee_const.h"
#include "tal_internal.h"
#include "tal_constants.h"
#include "pal.h"
#include "tal_rf230a.h"
#include "phy230_registermap.h"

/* ED scan is only relevant for FFD devices */
#ifndef RFD

/* === Macros =============================================================== */

/**
 * Scan duration formula: \f$aBaseSuperframeDuration (2^SD + 1)\f$
 * where \f$0 <= SD <= 14\f$
 */
#define CALCULATE_SYMBOL_TIME_SCAN_DURATION(SD) \
    (aBaseSuperframeDuration * ((1UL << (SD)) + 1))

/* === Globals ============================================================== */

/*
 * The peak_ed_level is the maximum ED value received from the transceiver for
 * the specified Scan Duration.
 */
static volatile uint8_t peak_ed_level;

/* === Prototypes =========================================================== */

static void initiate_ed_sampling(void);
static void read_ed_level_cb(void *parameter);
static void scan_duration_timer_expired_cb(void *callback_parameter);

/* === Implementation ======================================================= */

/**
 * @brief Starts ED Scan
 *
 * This function starts an ED Scan for the scan duration specified by the
 * MAC layer.
 *
 * @param scan_duration Given as BO.
 *
 * @return SUCCESS if the ED scan duration timer started successfully,  BUSY if
 * the TAL is busy servicing the previous request from MAC, TRX_SLEEP if the
 * transceiver is currently sleeping and FAILURE if the ED scan duration timer
 * failed to start.
 */
retval_t tal_ed_start(uint8_t scan_duration)
{
    uint32_t duration_time;
    retval_t timer_status;

    /*
     * The TAL can accept ED request from  MAC only in TAL_IDLE state, hence
     * check for the TAL state.
     */
    if (TAL_IDLE != tal_state)
    {
        if (TAL_SLEEP == tal_state)
        {
            return (TRX_ASLEEP);
        }
        else
        {
#if (DEBUG > 1)
            ASSERT("TAL is BUSY" == 0);
#endif
            return (BUSY);
        }
    }
    tal_state = TAL_ED;

    /* The peak_ed_value is Initialized. */
    peak_ed_level = 0;

    /*
     * The transceiver interrupt is disabled to prevent frame reception
     * while performing ED scan.
     */
    pal_trx_irq_disable(TRX_MAIN_IRQ_HDLR_IDX);

    /* The receiver is switched on to measure the ED Level. */
    while (PHY_RX_ON != set_trx_state(PHY_RX_ON));

    duration_time = TAL_CONVERT_SYMBOLS_TO_US( \
                        CALCULATE_SYMBOL_TIME_SCAN_DURATION(scan_duration));

    /* The ED Scan Duration timer is started. */
    timer_status = pal_timer_start(ED_SCAN_DURATION_TIMER,
                                    duration_time, \
                                    TIMEOUT_RELATIVE, \
                                    (void *)scan_duration_timer_expired_cb, \
                                    NULL);

    if (SUCCESS == timer_status)
    {
        /*
         * The Scan duration timer started successfully, ED sampling is
         * initiated until the ED scan duration time expires.
         */
        initiate_ed_sampling();
        return (SUCCESS);
    }
    else
    {
        tal_state = TAL_IDLE;
#if (DEBUG > 0)
        ASSERT("ED Scan Duration tmr Failed" == 0);
#endif
        return (FAILURE);
    }
} /* tal_ed_start() */


/*
 * @brief Scan duration timer expiry handler.
 *
 * This function updates the peak_ed_level and invokes the callback function
 * tal_ed_end_cb().
 *
 * @param callback_parameter Callback parameter.
 */
static void scan_duration_timer_expired_cb(void *callback_parameter)
{
    /*
     * The TAL should be protected from uploading a frame received during the
     * ED scan.
     */
    ENTER_CRITICAL_REGION();

    pal_trx_reg_read(RG_IRQ_STATUS);
    pal_trx_irq_flag_clr(TRX_MAIN_IRQ_HDLR_IDX);
    pal_trx_irq_enable(TRX_MAIN_IRQ_HDLR_IDX);
#ifdef ENABLE_HIGH_PRIO_TMR
    pal_stop_high_priority_timer(ED_SAMPLE_TIMER);
#else
    pal_timer_stop(ED_SAMPLE_TIMER);
#endif
    tal_state = TAL_IDLE;

    LEAVE_CRITICAL_REGION();

#if (DEBUG > 1)
    if (pal_is_timer_running(ED_SAMPLE_TIMER))
    {
        ASSERT("ED tmr running after ED scan" == 0);
    }

    if (pal_is_timer_running(ED_SCAN_DURATION_TIMER))
    {
        ASSERT("ED Scan Duration tmr running" == 0);
    }
#endif
    tal_ed_end_cb(peak_ed_level);

    callback_parameter = callback_parameter;  /* Keep compiler happy. */
}


/*
 * @brief Reads ED value from the transceiver register.
 *
 * This function is called upon ED request timer expiry. It reads the
 * transceiver register to get ED value.
 *
 * @param parameter Unused Callback parameter as per the timer callback
 * function interface.
 */
static void read_ed_level_cb(void *parameter)
{
    uint8_t ed_value;

    /* The ED Value is read from the transceiver register. */
    ed_value = pal_trx_reg_read(RG_PHY_ED_LEVEL);

    /*
     * The peak ED value is updated, if greater than the previously
     * read ED value.
     */
    if (ed_value > peak_ed_level)
    {
        peak_ed_level = ed_value;
    }

    /*
     * The ED Scan duration timer has not expired, hence continue to take
     * samples of the ED value from the transceiver.
     */
    initiate_ed_sampling();

    parameter = parameter;  /* Keep compiler happy. */
}


/*
 * @brief Starts the ED sampling process.
 *
 * This function is called to initiate reading the ED value.
 */
static void initiate_ed_sampling(void)
{
#ifndef ENABLE_HIGH_PRIO_TMR
    retval_t timer_status;
#endif

    /*
     * The ED operation is Initiated by writing a value into transceiver
     * register RG_PHY_ED_LEVEL.
     */
    pal_trx_reg_write(RG_PHY_ED_LEVEL, CMD_START_ED);

    /*
     * A high priority timer for a duration of 128 microseconds is started for
     * reading ED value from the transceiver. The return value of the high
     * priority timer is not checked since starting the high priority timer
     * will always succeed.
     */
#ifdef ENABLE_HIGH_PRIO_TMR
    pal_start_high_priority_timer(ED_SAMPLE_TIMER, \
                                  ED_SAMPLING_TIME, \
                                  (void *)read_ed_level_cb, \
                                  NULL);
#else
    do
    {
        timer_status = pal_timer_start(ED_SAMPLE_TIMER,
                                       ED_SAMPLING_TIME,
                                       TIMEOUT_RELATIVE,
                                       (void *)read_ed_level_cb, NULL);
    } while (timer_status != SUCCESS);
#endif
}

#endif  /* FFD */

/* EOF */
