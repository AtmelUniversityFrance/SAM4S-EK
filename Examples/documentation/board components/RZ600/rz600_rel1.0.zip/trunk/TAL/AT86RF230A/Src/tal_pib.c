/**
 * @file tal_pib.c
 *
 * @brief This file handles the TAL PIB attributes, set/get and initialization
 *
 * $Id: tal_pib.c 11738 2008-11-03 14:37:25Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================= */

#include <stdint.h>
#include <stdbool.h>
#include "platform_types.h"
#include "return_val.h"
#include "bmm.h"
#include "tal.h"
#include "ieee_const.h"
#include "phy230_registermap.h"
#include "pal.h"
#include "tal_internal.h"
#include "tal_constants.h"
#include "tal_pib.h"
#include "tal_rf230a.h"
#ifdef SPECIAL_PEER
#include "private_const.h"
#endif /* SPECIAL_PEER */

/* === Macros =============================================================== */


/* === Globals ============================================================== */


/* === Prototypes =========================================================== */

static void set_phy_channel_at_trx(uint8_t phy_channel);
static void set_phy_CCAmode_at_trx(uint8_t phy_CCA_mode);
static void set_phy_txpower_at_trx(uint8_t phy_tx_power);

/* === Implementation ======================================================= */

/**
 * @brief Initializes TAL PIB's
 *
 * This function initializes the TAL information base attribute
 * to their default values.
 */
void init_tal_infobase(void)
{
    tal_pib_CurrentChannel = CURRENT_CHANNEL_DEF;
    tal_pib_SupportedChannels = TRX_SUPPORTED_CHANNELS;
    tal_pib_TransmitPower = TRANSMIT_POWER_DEF;
    tal_pib_CCAMode = CCA_MODE_DEF;
    tal_pib_PrivatePanCoordinator = PAN_COORDINATOR_DEF;
    tal_pib_BattLifeExt = BATTERY_LIFE_EXTENSION_DEF;
    tal_pib_MaxCSMABackoffs = MAX_CSMA_BACKOFFS_DEF;
    tal_pib_MinBE = MINBE_DEF;
    tal_pib_PANId = PANID_DEF;
    tal_pib_ShortAddress = SHORT_ADDR_DEF;
    tal_pib_BeaconOrder = BEACON_ORDER_DEF;
    tal_pib_SuperFrameOrder = SUPERFRAME_ORDER_DEF;
    tal_pib_ACKWaitDuration = macAckWaitDuration_def;

#ifndef NOBEACON
    tal_pib_BeaconTxTime = BEACON_TX_TIME_DEF;
#endif

#ifdef SPECIAL_PEER
    tal_pib_PrivateDisableACK = PRIVATE_DISABLE_ACK_DEF;
    tal_pib_PrivateCCAFailure = PRIVATE_CCA_FAILURE_DEF;
#endif /* SPECIAL_PEER */
}


/**
 * @brief Gets TAL PIB attributes.
 *
 * This function is called to get the transceiver information base
 * attributes.
 *
 * @param[in] attribute TAL infobase attribute ID.
 * @param[out] value TAL infobase attribute value.
 *
 * @return UNSUPPORTED_ATTRIBUTE if the transceiver information base attribute
 * is not found, SUCCESS otherwise.
 */
#if (HIGHEST_STACK_LAYER != MAC)
retval_t tal_pib_get(uint8_t attribute, void *value)
{
    switch (attribute)
    {
        case phyCurrentChannel:
            /*
             * Note: The transceiver is not accessed,
             * but the copy maintained at TAL is accessed.
             */
            *(uint8_t *)value = tal_pib_CurrentChannel;
            break;

        case phyChannelsSupported:
            /*
             * Note: The transceiver is not accessed,
             * but the copy maintained at TAL is accessed.
             */
            *(uint32_t *)value = tal_pib_SupportedChannels;
            break;

        case phyTransmitPower:
            /*
             * Note: The transceiver is not accessed,
             * but the copy maintained at TAL is accessed.
             */
            *(uint8_t *)value = tal_pib_TransmitPower;
            break;

        case phyCCAMode:
            /*
             * Note: The transceiver is not accessed,
             * but the copy maintained at TAL is accessed.
             */
            *(uint8_t *)value = tal_pib_CCAMode;
            break;

        case mac_i_pan_coordinator:
            *(bool *)value = tal_pib_PrivatePanCoordinator;
            break;

        case macIeeeAddress:
            *(uint64_t *)value = tal_pib_IeeeAddress;
            break;

        case macBattLifeExt:
            *(bool *)value = tal_pib_BattLifeExt;
            break;

        case macBeaconOrder:
            *(uint8_t *)value = tal_pib_BeaconOrder;
            break;

#ifndef NOBEACON
        case macBeaconTxTime:
            *(uint32_t *)value = tal_pib_BeaconTxTime;
            break;
#endif
        case macMaxCSMABackoffs:
            *(uint8_t *)value = tal_pib_MaxCSMABackoffs;
            break;

        case macMinBE:
            *(uint8_t *)value = tal_pib_MinBE;
            break;

        case macPANId:
            *(uint16_t *)value = tal_pib_PANId;
            break;

        case macShortAddress:
            *(uint16_t *)value = tal_pib_ShortAddress;
            break;

        case macSuperframeOrder:
            *(uint8_t *)value = tal_pib_SuperFrameOrder;
            break;

#ifdef SPECIAL_PEER
        case macPrivateDisableACK:
            *(uint8_t *)value = tal_pib_PrivateDisableACK;
            break;

        case macPrivateCCAFailure:
            *(uint8_t *)value = tal_pib_PrivateCCAFailure;
            break;
#endif /* SPECIAL_PEER */

        case macPrivateAssociated:
            //*(bool *)value = tal_pib_PrivateAssociated;
            // RevA does not use this TAL PIB.
            return UNSUPPORTED_ATTRIBUTE;

        case macAckWaitDuration:
            // *(uint8_t *)value = tal_pib_AckWaitDuration;
            // The value ACK_WAIT_DURATION_DEF is used as fixed value.
            return UNSUPPORTED_ATTRIBUTE;

        default:
#if (DEBUG > 1)
            /* Invalid attribute id */
            ASSERT("UNSUPPORTED_ATTRIBUTE" == 0);
#endif
            return (UNSUPPORTED_ATTRIBUTE);
    }
    return (SUCCESS);
} /* tal_pib_get() */
#endif


/**
 * @brief Sets the TAL PIB attributes.
 *
 * This function is called to set the transceiver information base
 * attributes.
 *
 * @param attribute TAL infobase attribute ID.
 * @param value TAL infobase attribute value to be set.
 *
 * @return UNSUPPORTED_ATTRIBUTE if the transceiver info base attribute
 * is not found, INVALID_PARAMETER if the channel to be set is not supported
 * by the transceiver, BUSY if TAL is not in TAL_IDLE state only for
 * attributes set directly onto the transceiver (ie:phyCurrentChannel,
 * phyTransmitPower, phyCCAMode) and SUCCESS if set is successful.
 */
retval_t tal_pib_set(uint8_t attribute, void *value)
{
    switch (attribute)
    {
        case phyCurrentChannel:
            /* Note: Transceiver should be awake, before setting the channel. */
            {
                uint8_t channel_value = *((uint8_t *)value);

                if (TAL_IDLE != tal_state)
                {
#if (DEBUG > 1)
                    /*
                     * Accessing the transceiver is not allowed when TAL is
                     * BUSY
                     */
                    ASSERT(TAL_IDLE == tal_state);
#endif
                    return (BUSY);
                }

                if ((uint32_t)RF230_SUPPORTED_CHANNELS & \
                   (((uint32_t) 0x00000001) << channel_value))
                {
                    set_phy_channel_at_trx(channel_value);

                    /* Copy of the attribute is maintained at TAL. */
                    tal_pib_CurrentChannel = channel_value;
                }
                else
                {
#if (DEBUG > 1)
                    ASSERT("UNSUPPORTED CHANNEL" == 0);
#endif
                    return (INVALID_PARAMETER);
                }
            }
            break;

        case phyTransmitPower:
            if (TAL_IDLE != tal_state)
            {
#if (DEBUG > 1)
                /* Accessing the transceiver is not allowed when TAL is BUSY */
                ASSERT(TAL_IDLE == tal_state);
#endif
                return (BUSY);
            }

            /* Copy of the attribute is maintained at TAL. */
            tal_pib_TransmitPower = *((uint8_t *)value);

            /*
             * Note: Transceiver should be awake, before
             * phyTransmitPower is set on transceiver.
             */
            set_phy_txpower_at_trx(tal_pib_TransmitPower);
            break;

        case phyCCAMode:
            if (TAL_IDLE != tal_state)
            {
#if (DEBUG > 1)
                /* Accessing the transceiver is not allowed when TAL is BUSY */
                ASSERT(TAL_IDLE == tal_state);
#endif
                return (BUSY);
            }

            /* Copy of the attribute is maintained at TAL. */
            tal_pib_CCAMode = *((uint8_t *)value);

            /*
             * Note: Transceiver should be awake, before
             * CCA mode is set on transceiver.
             */
            set_phy_CCAmode_at_trx(tal_pib_CCAMode);
            break;

        case mac_i_pan_coordinator:
            tal_pib_PrivatePanCoordinator = *((bool *)value);
            break;

        case macIeeeAddress:
            tal_pib_IeeeAddress = *((uint64_t *)value);
            break;

        case macBattLifeExt:
            tal_pib_BattLifeExt = *((bool *)value);
            break;

        case macBeaconOrder:
            tal_pib_BeaconOrder = *((uint8_t *)value);
            break;

#ifndef NOBEACON
        case macBeaconTxTime:
            tal_pib_BeaconTxTime = *((uint32_t *)value);
            break;
#endif
        case macMaxCSMABackoffs:
            tal_pib_MaxCSMABackoffs = *((uint8_t *)value);
            break;

        case macMinBE:
            tal_pib_MinBE = *((uint8_t *)value);
            break;

        case macPANId:
            tal_pib_PANId = *((uint16_t *)value);
            break;

        case macShortAddress:
            tal_pib_ShortAddress = *((uint16_t *)value);
            break;

        case macSuperframeOrder:
            tal_pib_SuperFrameOrder = *((uint8_t *)value);
            break;

#ifdef SPECIAL_PEER
        case macPrivateDisableACK:
            tal_pib_PrivateDisableACK = *((uint8_t *)value);
            break;

        case macPrivateCCAFailure:
            tal_pib_PrivateCCAFailure = *((uint8_t *)value);
            break;
#endif /* SPECIAL_PEER */

        case macPrivateAssociated:
            // RevA does not use this TAL PIB.
            return UNSUPPORTED_ATTRIBUTE;

        case macAckWaitDuration:
            /* Rev.A does not support changing this value */
            return UNSUPPORTED_ATTRIBUTE;

        default:
#if (DEBUG > 0)
            ASSERT("UNSUPPORTED_ATTRIBUTE" == 0);
#endif
            return (UNSUPPORTED_ATTRIBUTE);
    }
    return (SUCCESS);
} /* tal_pib_set() */


/**
 * @brief Synchronizes the transceiver registers
 *
 * This function updates the transceiver registers with their corresponding
 * software values to ensure consistency between the copy and the transceiver
 * registers.
 */
void sync_trx_registers(void)
{
    set_phy_channel_at_trx(tal_pib_CurrentChannel);
    set_phy_txpower_at_trx(tal_pib_TransmitPower);
    set_phy_CCAmode_at_trx(tal_pib_CCAMode);
}


/*
 * @brief Sets the channel in the transceiver.
 *
 * This function is called to set the channel into the RG_PHY_CC_CCA
 * register of the transceiver.
 *
 * @param phy_channel channel value to be set.
 */
static void set_phy_channel_at_trx(uint8_t phy_channel)
{
    uint8_t reg_value;

    reg_value = pal_trx_reg_read(RG_PHY_CC_CCA);
    reg_value &= CHANNEL_MASK;
    reg_value |= phy_channel;
    pal_trx_reg_write(RG_PHY_CC_CCA, reg_value);
}


/*
 * @brief Sets the CCA mode in the transceiver.
 *
 * This function is called to set the CCA Mode into the RG_PHY_CC_CCA
 * register of the transceiver.
 *
 * @param phy_CCA_mode Value to be set.
 */
static void set_phy_CCAmode_at_trx(uint8_t phy_CCA_mode)
{
    uint8_t reg_value;

    reg_value = pal_trx_reg_read(RG_PHY_CC_CCA);
    reg_value &= CCA_MASK;
    /*
     * Shift CCA mode as defined by 802.15.4 in correct position in transceiver.
     */
    reg_value |= (phy_CCA_mode << 5);
    pal_trx_reg_write(RG_PHY_CC_CCA, reg_value);
}


/*
 * @brief Sets the transmit power in the transceiver.
 *
 * This function is called to set the transmit power into the RG_PHY_TX_PWR
 * register of the transceiver.
 *
 * @param Transmit power value to be set.
 */
static void set_phy_txpower_at_trx(uint8_t phy_tx_power)
{
    uint8_t reg_value;

    reg_value = pal_trx_reg_read(RG_PHY_TX_PWR);
    reg_value &= TX_POWER_MASK;
    reg_value |= phy_tx_power;
    pal_trx_reg_write(RG_PHY_TX_PWR, reg_value);
}

/* EOF */
