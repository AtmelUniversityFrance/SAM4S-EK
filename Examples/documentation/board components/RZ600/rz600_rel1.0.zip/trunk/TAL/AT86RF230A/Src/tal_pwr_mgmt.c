/**
 * @file tal_pwr_mgmt.c
 *
 * @brief This module implements power management of transceiver.
 *
 * $Id: tal_pwr_mgmt.c 11738 2008-11-03 14:37:25Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================= */

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "platform_types.h"
#include "return_val.h"
#include "bmm.h"
#include "tal.h"
#include "ieee_const.h"
#include "tal_pib.h"
#include "pal.h"
#include "tal_internal.h"
#include "tal_constants.h"
#include "tal_rf230a.h"
#include "phy230_registermap.h"

/* === Macros =============================================================== */


/* === Globals ============================================================== */


/* === Prototypes =========================================================== */


/* === Implementation ======================================================= */

/**
 * @brief Sets the transceiver to sleep.
 *
 * This function sets the transceiver to sleep state.
 *
 * @param mode is set to SLEEP_MODE_1.
 *
 * @return BUSY - The transceiver is busy in TX or RX /
 *         SUCCESS - The transceiver is put to sleep
 *         TRX_ASLEEP - The transceiver is already asleep.
 *         INVALID_PARAMETER - The specified sleep mode is not supported.
 */
retval_t tal_trx_sleep(sleep_mode_t mode)
{
    /* Current transceiver only supports SLEEP mode */
    if (SLEEP_MODE_1 != mode)
    {
#if (DEBUG > 1)
        ASSERT("INVALID_PARAMETER" == 0);
#endif
        return (INVALID_PARAMETER);
    }

    /* Check if the TAL is already sleeping */
    if (TAL_SLEEP == tal_state)
    {
        return (TRX_ASLEEP);
    }

    /* Device can be put to sleep only when the TAL is in IDLE state */
    if (TAL_IDLE != tal_state)
    {
#if (DEBUG > 1)
        ASSERT("TAL is busy" == 0);
#endif
        return (BUSY);
    }

    /* Make sure that transceiver is switched off */
    while (PHY_TRX_OFF != set_trx_state(PHY_TRX_OFF));

    /* Set the SLP_TR pin to put the transceiver to sleep mode */
    pal_gpio_set(SLP_TR_PIN, HIGH);

    /* Radio specific delay for putting the transceiver to sleep */
    pal_timer_delay(TRX_SLEEP_DELAY);

    /* Set the TAL state to SLEEP state */
    tal_state = TAL_SLEEP;

    return (SUCCESS);
}


/**
 * @brief Wakes up the transceiver from sleep.
 *
 * This function wakes up the transceiver from sleep state.If the transceiver
 * fails to wake up after the specified transceiver wake up time, short delays
 * are provided until the  transceiver wakes up from sleep.
 *
 * @return TRX_AWAKE if the transceiver is already awake or SUCCESS if the
 * transceiver is successfully woken up from sleep.
 */
retval_t tal_trx_wakeup(void)
{
    if (TAL_SLEEP != tal_state)
    {
#if (DEBUG > 1)
        ASSERT(TAL_SLEEP == tal_state);
#endif
        return (TRX_AWAKE);
    }

    /* Clear the SLP_TR pin to bring the transceiver out of sleep mode */
    pal_gpio_set(SLP_TR_PIN, LOW);

    /* Radio specific delay for waking up the transceiver */
    pal_timer_delay(TRX_AWAKE_DELAY);

    /* The transceiver state should be PHY_TRX_OFF */
    while (PHY_TRX_OFF != pal_trx_reg_read(RG_TRX_STATUS))
    {
        /*
         * The transceiver has still not woken up, hence delay reading the
         * transceiver state for a short time.
         */
        pal_timer_delay(TRX_AWAKE_RETRY_DELAY);
    }
    tal_state = TAL_IDLE;
    return (SUCCESS);
}

/* EOF */
