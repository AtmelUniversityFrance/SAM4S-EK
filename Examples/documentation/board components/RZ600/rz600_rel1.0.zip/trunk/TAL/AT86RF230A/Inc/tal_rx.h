/**
 * @file tal_rx.h
 *
 * @brief This  file contains macros and modules used while processing
 * a received frame.
 *
 * $Id: tal_rx.h 11056 2008-09-15 08:00:34Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef TAL_RX_H
#define TAL_RX_H

/* === Includes ============================================================= */


/* === Macros =============================================================== */

/**
 * Delay table for frame upload
 * int((28.18 * $i)/16) - 3; $x = 0 unless $x > 0;
 *
 * To avoid delay of 0 symbols for frame of length 0 and 1 a finite delay is
 * is given.
 */
#define DELAY_TABLE \
  2,   2,   2,   4,   5,   7,   9,  11,  12,  14,  16,  18,  19,  21,  23,  25, \
 26,  28,  30,  32,  33,  35,  37,  39,  41,  42,  44,  46,  48,  49,  51,  53, \
 55,  56,  58,  60,  62,  63,  65,  67,  69,  70,  72,  74,  76,  78,  79,  81, \
 83,  85,  86,  88,  90,  92,  93,  95,  97,  99, 100, 102, 104, 106, 107, 109, \
111, 113, 115, 116, 118, 120, 122, 123, 125, 127, 129, 130, 132, 134, 136, 137, \
139, 141, 143, 144, 146, 148, 150, 151, 153, 155, 157, 159, 160, 162, 164, 166, \
167, 169, 171, 173, 174, 176, 178, 180, 181, 183, 185, 187, 188, 190, 192, 194, \
196, 197, 199, 201, 203, 204, 206, 208, 210, 211, 213, 215, 217, 218, 220, 222


/**
 * Mask used, to obtain the RSSI value from the PHY RSSI register of
 * transceiver.
 */
#define TRX_RSSI_MASK            (0x1F)

/**
 * Time in symbols to wait to avoid a frame underrun, when a
 * frame is received.
 */
#define UNDERRUN_AVOID_TIME      (0x04)

/**
 * Higher byte of FCF of an ACK frame
 */
#define ACK_FRAME_FCF_HIGH_BYTE  (0x00)

/**
 * Minimum value of 'LQI' for frame acceptance
 */
#define SATISFACTORY_LQI_VAL     (0xC0)

/**
 * Maximum value of 'RSSI' for frame acceptance
 */
#define SATISFACTORY_RSSI_VAL    (0x0F)

/**
 * Size of the length parameter
 */
#define LENGTH_FIELD_LEN         (0x01)

/**
 * Max LQI range
 */
#define LQI_MAX                  (0xFF)

/**
 * Mask to extract link quality.
 */
#define LQI_MASK                 (0x30)

/**
 * Radio rate: Time (in microseconds) taken by the transceiver to receive a
 * byte over the air
 */
#define RADIO_RATE               (0x20)

/**
 * Calculates the time taken by the transceiver to upload the frame of a
 * particular length
 */
#define TIME_FOR_FRAME_UPLOAD(length) (length * RADIO_RATE)

/* === Types ================================================================ */

/**
 * Structure to send the ack frame
 */
typedef struct ack_frame_tag
{
    /** Length of the acknowledgement frame */
    uint8_t ack_length;
    /** Frame control field of the acknowledgement frame */
    uint8_t frame_control[2];
    /** Sequence number of the acknowledgement frame */
    uint8_t seq_num;
    /** Frame check sequence of the acknowledgement frame */
    uint8_t fcs[2];
} ack_frame_t;

/**
 * Structure to store the received frame length, timestamp and RSSI
 */
typedef struct rcvd_frame_info_tag
{
    /** Received frame length */
    uint8_t rcvd_frame_length;
    /** Received frame energy level */
    uint8_t rcvd_frame_ed_level;
    /** Timestamp of the received frame */
    uint32_t rcvd_frame_timestamp;
} rcvd_frame_info_t;

/* === Externals ============================================================ */

extern volatile uint8_t tal_received_ack_dsn;
extern volatile uint8_t tal_ack_status;
extern buffer_t *tal_rx_buffer;
extern queue_t tal_incoming_frame_queue;
extern volatile bool tal_rx_buf_available;
extern volatile bool tal_ack_expected;

/* === Prototypes =========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

void upload_frame_alloc_buf(uint32_t time_stamp);

void process_incoming_frame(buffer_t *incoming_frame);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* TAL_RX_H */
/* EOF */
