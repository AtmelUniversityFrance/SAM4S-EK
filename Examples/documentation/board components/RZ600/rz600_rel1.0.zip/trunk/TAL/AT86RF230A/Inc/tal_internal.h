/**
 * @file tal_internal.h
 *
 * @brief This file declares the TAL states used by the TAL state machine
 * and the macros useful for frame parsing
 *
 * $Id: tal_internal.h 11791 2008-11-04 17:49:11Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef TAL_INTERNAL_H
#define TAL_INTERNAL_H

/* === Includes ============================================================= */


/* === Macros =============================================================== */

/** Mask used to check if frame is beacon frame. */
#define BEACON_FRAME                (0x0000)

/** Mask used to check if the frame contains a MAC Command. */
#define MAC_CMD_FRAME               (0x0003)

/** Mask used to obtain the frame type from the FCF field. */
#define FRAME_TYPE_MASK             (0x0007)

/** Mask used to check if frame has a short source address. */
#define SRC_SHORT_ADDR_MODE         (0x8000)

/** Mask used to check if frame has a long source address. */
#define SRC_EXT_ADDR_MODE           (0xC000)

/** Mask used to check if frame has a short destination address. */
#define DEST_SHORT_ADDR_MODE        (0x0800)

/** Mask used to check if frame has a long destination address. */
#define DEST_EXT_ADDR_MODE          (0x0C00)

/** Mask used to check if the intra-PAN bit is set or not. */
#define INTRA_PAN_SUBFIELD          (0x0040)

/** Mask used to check if acknowledgement is required to be sent. */
#define FCF_ACK_REQ                 (0x0020)

/** Mask used to obtain the destination address mode from the FCF field. */
#define DEST_ADDR_MODE_MASK         (0x0C00)

/** Mask used to obtain the source address mode from the FCF field. */
#define SRC_ADDR_MODE_MASK          (0xC000)

/** Mask used to check if the frame control has ack request bit set. */
#define ACK_MASK                    (0x20)

/** Defines the length of an acknowledgement frame. */
#define ACK_FRAME_LEN               (0x05)

/** Length (in bytes) of extended address. */
#define EXT_ADDR_LEN                (0x08)

/** Length (in bytes) of short address. */
#define SHORT_ADDR_LEN              (0x02)

/** Length (in bytes) of PAN ID. */
#define PAN_ID_LEN                  (0x02)

/** Length (in bytes) of FCF. */
#define FCF_LEN                     (0x02)

/** Length (in bytes) of FCS. */
#define FCS_LEN                     (0x02)

/** FCF field offset in the frame created by TAL. */
#define FCF_OFFSET                  (0x01)

/* === Types ================================================================ */

/**
 * Main states of the TAL
 */
#ifdef __ICCAVR__
#pragma diag_suppress=Pe228
#endif
typedef enum tal_state_tag
{
    /* TAL main states */
    TAL_IDLE,
    TAL_TX_FRAME,
#ifndef RFD
#ifndef NOBEACON
    TAL_TX_BEACON,
#endif  /* FFD */
#endif  /* BEACON */
    TAL_SLEEP,
#ifndef RFD
    TAL_ED
#endif  /* FFD */
} tal_state_t;

/**
 * Status of the received acknowledgement frame
 */
typedef enum tal_rx_frame_info_tag
{
    ACK           = 0x01,
    FRAME_PENDING = 0x02
} tal_rx_frame_info_t;

/* === Externals ============================================================ */

extern uint8_t *tal_frame_to_tx;

extern volatile uint8_t tal_state;

extern volatile uint8_t tal_previous_state;

extern volatile bool tal_rx_on;

extern bool tal_unslotted_csma_required;


/* === Prototypes =========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

uint8_t set_trx_state(uint8_t state);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* TAL_INTERNAL_H */

/* EOF */
