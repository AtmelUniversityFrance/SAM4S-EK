/**
 * @file tal_set_trx_state.c
 *
 * @brief This module is called to change the state of the transceiver
 *
 * $Id: tal_set_trx_state.c 11738 2008-11-03 14:37:25Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================= */

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "platform_types.h"
#include "return_val.h"
#include "tal_tx.h"
#include "bmm.h"
#include "qmm.h"
#include "tal.h"
#include "ieee_const.h"
#include "tal_internal.h"
#include "tal_constants.h"
#include "pal.h"
#include "tal_rf230a.h"
#include "phy230_registermap.h"
#include "tal_rx.h"

/* === Macros =============================================================== */


/* === Globals ============================================================== */


/* === Prototypes =========================================================== */


/* === Implementation ======================================================= */

/**
 * @brief Sets transceiver state
 *
 * This function sets the state of the transceiver.
 *
 * @param new_state Specifies the state to be set on the transceiver
 *
 * @return New state of transceiver
 */
uint8_t set_trx_state(uint8_t new_state)
{
    uint8_t trx_state;

    trx_state = pal_trx_reg_read(RG_TRX_STATUS);

    if (BUSY_TX == trx_state)
    {
        trx_state = PHY_BUSY_TX;
    }
    else if (BUSY_RX == trx_state)
    {
        trx_state = PHY_BUSY_RX;
    }
    else
    {
        switch (new_state)
        {
            case PHY_RX_ON:
                pal_trx_reg_write(RG_TRX_STATE, RX_ON);

                /*
                 * Check whether the previous state is PHY_TRX_OFF,
                 * if PHY_TRX_OFF then wait until the PLL has locked.
                 */
                if (PHY_TRX_OFF == trx_state)
                {
                    pal_timer_delay(PLL_LOCK_TIMEOUT_VALUE);
                }
                else
                {
                    /* From active state, a 1us delay is required */
                    PAL_WAIT_1_US();
                }

                break;

            case PHY_TX_ON:
                pal_trx_reg_write(RG_TRX_STATE, PLL_ON);

               /*
                * Check whether the previous state is PHY_TRX_OFF,
                * if PHY_TRX_OFF then wait until the PLL has locked.
                */
                if (PHY_TRX_OFF == trx_state)
                {
                    pal_timer_delay(PLL_LOCK_TIMEOUT_VALUE);
                }
                else
                {
                    /* From active state, a 1us delay is required */
                    PAL_WAIT_1_US();
                }

                break;

            case PHY_TRX_OFF:
                pal_trx_reg_write(RG_TRX_STATE, TRX_OFF);

                /* From active state, a 1us delay is required */
                PAL_WAIT_1_US();

                break;

            case CMD_FORCE_TRX_OFF:
                pal_trx_reg_write(RG_TRX_STATE, CMD_FORCE_TRX_OFF);

                /* From active state, a 1us delay is required */
                PAL_WAIT_1_US();

                break;

            case CMD_FORCE_PLL_ON:
                pal_trx_reg_write(RG_TRX_STATE, PLL_ON);
                trx_state = pal_trx_reg_read(RG_TRX_STATUS);

                if (PLL_ON != trx_state)
                {
                    ENTER_CRITICAL_REGION();
                    pal_trx_reg_write(RG_TRX_STATE, CMD_FORCE_TRX_OFF);
                    pal_trx_reg_write(RG_TRX_STATE, PLL_ON);
                    LEAVE_CRITICAL_REGION();
                }

                break;

            default:
               break;
        }
    trx_state = pal_trx_reg_read(RG_TRX_STATUS);
    }
    return (trx_state);
} /* set_trx_state() */


/**
 * @brief Turns receiver on or off
 *
 * This function switches the receiver on (RX_ON) or off (TRX_OFF).
 *
 * @param state New receiver state
 *
 * @return INVALID_PARAMETER if TAL (actually transceiver) is sleeping,
 * TRX_OFF if the receiver could not be switched on due to buffer
 * unavailability Otherwise the current status of the transceiver
 */
uint8_t tal_rx_enable(uint8_t state)
{
    uint8_t trx_state;

   /* Transceiver should not be sleeping if a change of state is required */
    if (TAL_SLEEP == tal_state)
    {
#if (DEBUG > 1)
        ASSERT("tal_state is TAL_SLEEP" == 0);
#endif
        /*
         * Transceiver is sleeping, state cannot be changed unless it is awake
         * (TAL_IDLE state), so do not allow state change and return with
         * invalid parameter.
         */
        return ((uint8_t)INVALID_PARAMETER);
    }

    if (PHY_RX_ON == state)
    {
        /*
         * The receiver will be switched on only if the receive buffer is
         * available.
         */
        if (!tal_rx_buf_available)
        {
            tal_rx_on = false;
            return (PHY_TRX_OFF);
        }
    }

    trx_state = set_trx_state(state);

    if (PHY_TRX_OFF == trx_state)
    {
        tal_rx_on = false;
    }
    else if (PHY_RX_ON == trx_state)
    {
        tal_rx_on = true;
    }

    return (trx_state);
}

/* EOF */
