/**
 * @file tal_init.c
 *
 * @brief This file implements functions for initializing TAL.
 *
 * $Id: tal_init.c 12168 2008-11-24 08:43:34Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================= */

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "platform_types.h"
#include "return_val.h"
#include "bmm.h"
#include "qmm.h"
#include "tal.h"
#include "ieee_const.h"
#include "tal_pib.h"
#include "pal.h"
#include "tal_irq_handler.h"
#include "tal_internal.h"
#include "tal_rf230a.h"
#include "phy230_registermap.h"
#ifndef RFD
#include "ffd_data_structures.h"
#endif  /* FFD */
#include "stack_config.h"
#include "tal_constants.h"
#include "tal_rx.h"
#include "tal_tx.h"
#include "tal_csma_ca.h"

/* === Macros =============================================================== */


/* === Globals ============================================================== */


/* === Prototypes =========================================================== */

static void reset_tal_globals(void);
static retval_t trx_reset(void);

/* === Implementation ======================================================= */

/**
 * @brief Initializes the TAL.
 *
 * This function is called to initialize the TAL. The transceiver is
 * initialized, the TAL PIBs are set to their default values, and the TAL state
 * machine is set to TAL_IDLE state.
 *
 * @return SUCCESS if the transceiver state is changed to TRX_OFF and the
 * current device part number and version number matches AT86_RF230A_PART_NUM
 * and AT86_RF230A_VERSION_NUM respectively or FAILURE otherwise.
 */
retval_t tal_init(void)
{
    uint8_t part_number;
    uint8_t version_number;
    uint8_t trx_state;
#ifdef EXTERN_EEPROM_AVAILABLE
    uint8_t xtal_trim_value;
#endif

    /* Init the PAL and by this means also the transceiver interface */
    if (pal_init() != SUCCESS)
    {
        return FAILURE;
    }

    /* Initialize the buffer management module. */
    bmm_buffer_init();

    pal_timer_delay(TRX_SETTLING_TIME);

    pal_gpio_set(RST_PIN, LOW);

    pal_gpio_set(SLP_TR_PIN, LOW);

    /*
     * Everytime the TAL is initialized, the PIBs present at TAL are also
     * initialized to their default values.
     */
    init_tal_infobase();

#ifdef EXTERN_EEPROM_AVAILABLE
    pal_ps_get(EXTERN_EEPROM, PS_IEEE_ADDR, &tal_pib_IeeeAddress);
#else
    pal_ps_get(INTERN_EEPROM, PS_IEEE_ADDR, &tal_pib_IeeeAddress);
#endif

    // Check if a valid IEEE address is available.
    if ((tal_pib_IeeeAddress == 0x0000000000000000) ||
        (tal_pib_IeeeAddress == 0xFFFFFFFFFFFFFFFF))
    {
        return FAILURE;
    }

    /* Get trim value for 16 MHz xtal; needs to be done before reset */
#ifdef EXTERN_EEPROM_AVAILABLE
    pal_ps_get(EXTERN_EEPROM, PS_XTAL_TRIM, &xtal_trim_value);
#endif

    /* The transceiver reset pulse width is 6 micro seconds. */
    pal_timer_delay(RESET_PIN_SET_TIME);

    pal_gpio_set(RST_PIN, HIGH);

    pal_trx_reg_write(RG_TRX_STATE, TRX_OFF);

    /*
     * Time taken by the transceiver to change from P_ON to PHY_TRX_OFF is
     * 510 micro seconds.
     */
    pal_timer_delay(TRX_SETTLING_TIME);

    /*
     * For validation of the transceiver the part number and the version number
     * of the transnceiver is read.
     */
    part_number = pal_trx_reg_read(RG_PART_NUM);

    version_number = pal_trx_reg_read(RG_VERSION_NUM);

    /*
     * Further initialization is not done if this is an incorrect
     * transceiver.
     */
    if ((AT86_RF230A_PART_NUM != part_number) || \
        (AT86_RF230A_VERSION_NUM != version_number))
    {
        return (FAILURE);
    }

    // Write 16MHz xtal trim value to trx.
    // It's only necessary if it differs from the reset value.
#ifdef EXTERN_EEPROM_AVAILABLE
    if (xtal_trim_value != 0x00)
    {
        pal_trx_bit_write(SR_XTAL_TRIM, xtal_trim_value);
    }
#endif

    /*
     * The transceiver control register is set to give out 1MHz on CLKM pin.
     * This may be used by external modules as the reference clock.
     */
    pal_trx_reg_write(RG_TRX_CTRL_0, CLKM_1MHz);

    /* The transceiver's auto crc generation feature is enabled. */
    pal_trx_reg_write(RG_PHY_TX_PWR, TX_AUTO_CRC_ON);

    /*
     * The transceiver's interrupt mask register is updated to disable the
     * the interrupts.
     */
    pal_trx_reg_write(RG_IRQ_MASK, DISABLE_TRX_IRQ_MASK);

    /*
     * The IRQ status register of the transceiver is read to clear any pending
     * interrupts.
     */
    pal_trx_reg_read(RG_IRQ_STATUS);

    trx_state = pal_trx_reg_read(RG_TRX_STATUS);

    /* The transceiver should be in TRX OFF */
    if (PHY_TRX_OFF == trx_state)
    {
        /*
         * Similar to the TAL PIBs some of the transceiver registers used as
         * TAL PIBs are also set to their default values.
         */
        sync_trx_registers();

        /*
         * All the TAL variables and states are initialized to their default
         * value.
         */
        reset_tal_globals();
        init_csma_ca_state();

        /* A handler is installed to handle the transceiver interrupts. */
        pal_trx_irq_init(TRX_MAIN_IRQ_HDLR_IDX, (void *)trx_irq_handler_cb);

        /* The RX_START and TRX_END interrupt of transceiver are enabled. */
        pal_trx_reg_write(RG_IRQ_MASK, ENABLE_TRX_IRQ_MASK);

        qmm_queue_init(&tal_incoming_frame_queue, \
                       TAL_INCOMING_FRAME_QUEUE_CAPACITY);

        /*
         * Finally the transcevier interrupt is enabled on the cotroller side.
         */
        pal_trx_irq_enable(TRX_MAIN_IRQ_HDLR_IDX);

        return (SUCCESS);
    }
    return (FAILURE);
} /* tal_init() */


/**
 * @brief Resets the TAL.
 *
 * This function is called to reset the TAL. The TAL timers are stopped, The
 * transceiver is reset, depending upon the set_default_pib the TAL PIB are
 * reset to their default values, the transceiver registers are updated
 * accordingly and the tal_incoming_frame_q is cleared.
 *
 * @param set_default_pib Specifies if the TAL PIBs are to be set to
 * their default values
 */
retval_t tal_reset(bool set_default_pib)
{
    uint8_t timer_id;

    ENTER_CRITICAL_REGION();

#ifndef RFD
    /* The high priority ED sample timer is stopped. */
#ifdef ENABLE_HIGH_PRIO_TMR
    pal_stop_high_priority_timer(ED_SAMPLE_TIMER);
#endif
#endif

#if (DEBUG > 1)
#ifndef RFD
    if (pal_is_timer_running(ED_SAMPLE_TIMER))
    {
        ASSERT("ED tmr running after RST" == 0);
    }
#endif
#endif

    /* The TAL regular timer's are stopped. */
    for (timer_id = TAL_FIRST_TIMER_ID; timer_id <= TAL_LAST_TIMER_ID;
         timer_id++)
    {
        pal_timer_stop(timer_id);

#if (DEBUG > 1)
        if (pal_is_timer_running(timer_id))
        {
            ASSERT("Init tmr running" == 0);
        }
#endif
    }

    if (set_default_pib)
    {
        /* The TAL PIB's are set to their default values */
        init_tal_infobase();
    }

    /* The transceiver is reset */
    if (trx_reset() != SUCCESS)
    {
        return FAILURE;
    }

    /* The transceiver's auto crc generation feature is enabled. */
    pal_trx_reg_write(RG_PHY_TX_PWR, TX_AUTO_CRC_ON);

    /*
     * The transceiver was reset, hence some of the transceiver registers that
     * are a part of TAL PIBs are also updated with their corresponding
     * software values.
     */
     sync_trx_registers();

    /*
     * All the TAL variables and states are initialized to their default
     * value.
     */
     reset_tal_globals();
     init_csma_ca_state();

     /* The tal_incoming_frame_queue is cleared */
     if (tal_incoming_frame_queue.size > 0)
     {
         buffer_t *frame;

         while (tal_incoming_frame_queue.size > 0)
         {
             frame = qmm_queue_remove(&tal_incoming_frame_queue, NULL);

             if (NULL != frame)
             {
                 bmm_buffer_free(frame);
             }
             else
             {
#if (DEBUG > 0)
                 ASSERT("Corrupted TAL incoming queue size" == 0);
#endif
                 /* The queue size is corrected */
                 tal_incoming_frame_queue.size = 0;
             }
        }
    }

    /* The pending interrupts on the microcontroller are cleared */
    pal_trx_irq_flag_clr(TRX_MAIN_IRQ_HDLR_IDX);

    /* The RX_START and TRX_END interrupts of transceiver are enabled */
    pal_trx_reg_write(RG_IRQ_MASK, ENABLE_TRX_IRQ_MASK);

    /* Finally the transcevier interrupt is enabled on the cotroller side. */
    pal_trx_irq_enable(TRX_MAIN_IRQ_HDLR_IDX);

    LEAVE_CRITICAL_REGION();

    return SUCCESS;
} /* tal_reset() */


/**
 * @brief Resets TAL state machine and forces transceiver off.
 *
 * This function resets the TAL state machine. The transceiver is turned off
 * using CMD_FORCE_TRX_OFF and tal_state is initialized to TAL_IDLE. This will
 * abort any ongoing transaction.
 */
#if (DEBUG > 1)
void tal_trx_state_reset(void)
{
    pal_gpio_set(SLP_TR_PIN, LOW);

    /*
     * A delay of 6 micro seconds is required before setting the transceiver
     * state to FORCE_TRX_OFF.
     */
    pal_timer_delay(SLEEP_PIN_SET_TIME);

    /* The transceiver is Forced into TRX_OFF state. */
    pal_trx_reg_write(RG_TRX_STATE, CMD_FORCE_TRX_OFF);

    /*
     * A delay of 6 micro seconds is required for the transceiver to make its
     * transition to TRX_OFF state.
     */
    pal_timer_delay(FORCE_TRX_SET_TIME);

    /*
     * The transceiver state is read to ensure that the transceiver has made
     * the transition to TRX_OFF state.
     */
    while (PHY_TRX_OFF != pal_trx_reg_read(RG_TRX_STATUS));

    tal_state = TAL_IDLE;
}
#endif


/*
 * @brief Initialize TAL management variables.
 *
 * This function Initializes all the TAL global varibles to their default
 * values.
 */
static void reset_tal_globals(void)
{
    tal_state = TAL_IDLE;
    tal_tx_completed = false;
    tal_previous_state = TAL_IDLE;
    tal_ack_status = 0;
    tal_ack_expected = false;
    tal_rx_on = false;
}


/*
 * @brief Resets the transceiver.
 *
 * This function resets the transceiver.
 */
static retval_t trx_reset(void)
{
    uint8_t trx_state;
#ifdef EXTERN_EEPROM_AVAILABLE
    uint8_t xtal_trim_value;
#endif

    /* Get trim value for 16 MHz xtal; needs to be done before reset */
#ifdef EXTERN_EEPROM_AVAILABLE
    pal_ps_get(EXTERN_EEPROM, PS_XTAL_TRIM, &xtal_trim_value);
#endif

    pal_gpio_set(RST_PIN, LOW);

    pal_gpio_set(SLP_TR_PIN, LOW);

     /* The transceiver reset pulse width is 6 micro seconds. */
    pal_timer_delay(RESET_PIN_SET_TIME);

    pal_gpio_set(RST_PIN, HIGH);

    /*
     * The transceiver's interrupt mask register is updated to disable the
     * the interrupts.
     */
    pal_trx_reg_write(RG_IRQ_MASK, DISABLE_TRX_IRQ_MASK);

    /*
     * The IRQ status register of the transceiver is read to clear any pending
     * interrupts.
     */
    pal_trx_reg_read(RG_IRQ_STATUS);

    /* The transceiver goes to TRX_OFF in 120 micro seconds. */
    pal_timer_delay(RESET_TO_TRX_OFF_DELAY);

    trx_state = pal_trx_reg_read(RG_TRX_STATUS);

    /* The transceiver should be in TRX OFF */
    if (PHY_TRX_OFF != trx_state)
    {
#if (DEBUG > 0)
        ASSERT(" TAL reset has failed " == 0);
#endif
        return FAILURE;
    }

    // Write 16MHz xtal trim value to trx.
    // It's only necessary if it differs from the reset value.
#ifdef EXTERN_EEPROM_AVAILABLE
    if (xtal_trim_value != 0x00)
    {
        pal_trx_bit_write(SR_XTAL_TRIM, xtal_trim_value);
    }
#endif

    return SUCCESS;
}

/* EOF */
