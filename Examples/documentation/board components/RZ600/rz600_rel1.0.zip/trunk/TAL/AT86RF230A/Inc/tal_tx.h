/**
 * @file tal_tx.h
 *
 * @brief This file contains the TAL sub-state macros and functions that
 * perform frame transmission.
 *
 * $Id: tal_tx.h 11056 2008-09-15 08:00:34Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef TAL_TX_H
#define TAL_TX_H

/* === Includes ============================================================= */


/* === Macros =============================================================== */


/* === Types ================================================================ */

/**
 * The TAL transmit sub states
 */
typedef enum tx_frame_substates_tag
{
    TAL_TX_IDLE,
    TAL_WAIT_FOR_TX_COMPLETE,
    TAL_FRAME_CREATE,
    TAL_CSMA_CA,
    TAL_SEND_FRAME,
    TAL_ACK_WAIT,
    TAL_FRAME_RETRY,
    TAL_TX_CONF
} tx_frame_substates_t;

/* === Externals ============================================================ */


/* === Prototypes =========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

void tx_state_handling(void);

bool beacon_tx_handling(void);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* TAL_TX_H */
/* EOF */
