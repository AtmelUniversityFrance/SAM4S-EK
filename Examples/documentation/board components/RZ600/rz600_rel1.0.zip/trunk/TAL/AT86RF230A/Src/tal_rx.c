/**
 * @file tal_rx.c
 *
 * @brief This file implements the frame reception functions.
 *
 * $Id: tal_rx.c 11738 2008-11-03 14:37:25Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================= */

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "platform_types.h"
#include "return_val.h"
#include "bmm.h"
#include "qmm.h"
#include "tal.h"
#include "ieee_const.h"
#ifndef RFD
#include "ffd_data_structures.h"
#endif  /* FFD */
#include "stack_config.h"
#include "pal.h"
#include "tal_constants.h"
#include "tal_pib.h"
#include "tal_irq_handler.h"
#include "tal_internal.h"
#include "tal_rf230a.h"
#include "phy230_registermap.h"
#include "tal_rx.h"

/* === Macros =============================================================== */

/* Mask used to check if frame is secured. */
#define FCF_SECURITY_ENABLED        (0x0008)

/* Generic 16 bit broadcast address. */
#define BROADCAST                   (0xFFFF)

/* Mask used, to obtain the frame type and check validity, from the FCF field */
#define VALID_FRAME_TYPE            (0x03)

/* Mask used to check if a frame pending bit is set in the FCF field. */
#define SET_FRAME_PENDING_MASK      (0x10)

/* Mask to clear frame pending bit in the FCF field. */
#define CLEAR_FRAME_PENDING_MASK    (0xEF)

/* Command Frame Identifier for Data Request. */
#define DATA_REQ_ID                 (0x04)

/* Acknowledgement frame Identifier. */
#define ACK_FRAME_ID                (0x02)

/* Length of the sequence number field. */
#define SEQ_NUM_LEN                 (0x01)

/* Length of the LQI number field. */
#define LQI_LEN                     (0x01)

/* Length (in bytes) of the PHY header. */
#define PHY_HDR_LEN                 (0x01)

/* === Globals ============================================================== */

/*
 * Acknowledgement frame contains the following fields:
 *  Frame Length,
 *  FCF,
 *  Sequence number,
 *  FCS
 */
static ack_frame_t ack_frame =
    {ACK_FRAME_LEN, {ACK_FRAME_ID, ACK_FRAME_FCF_HIGH_BYTE}, 0x00,
    {0x00, 0x00}};

/*
 * Length based delay table in Flash.
 */
FLASH_DECLARE (static uint8_t delay_table [128]) = { DELAY_TABLE };

/* === Prototypes =========================================================== */

static void send_ack(uint8_t seq_num, bool set_frame_pending);
static void init_tal_parse_buffer(frame_info_t *frame_info);
static uint8_t compute_lqi(uint8_t lqi, uint8_t frame_ed_level);

/* === Implementation ======================================================= */

/**
 * @brief Creates the frame_info_t structure for the received frame.
 *
 * This function creates the frame_info_t structure for the received frame
 *  by parsing the frame.
 *
 * @param buf Pointer to the buffer containing the received frame.
 */
void process_incoming_frame(buffer_t *buf)
{
    uint16_t src_address_mode;
    uint16_t dest_address_mode;
    frame_info_t *frame_to_mac;
    uint8_t frame_length;
    uint8_t *rx_frame;
    uint8_t frame_ed_level;
    uint8_t frame_lqi;

    /* Holds the buffer body containing the received frame. */
    uint8_t *incoming_frame = BMM_BUFFER_POINTER(buf);

    frame_to_mac = (frame_info_t *)incoming_frame;

    frame_length = \
        ((rcvd_frame_info_t *)incoming_frame)->rcvd_frame_length;

    frame_ed_level = \
        ((rcvd_frame_info_t *)incoming_frame)->rcvd_frame_ed_level;

    frame_to_mac->time_stamp = \
        ((rcvd_frame_info_t *)incoming_frame)->rcvd_frame_timestamp;

    /*
     * The frame is present towards the end of the buffer. Hence using the
     * frame length as the reference the location of the received frame within
     * the buffer is computed.
     */
    rx_frame = incoming_frame + (LARGE_BUFFER_SIZE - (frame_length + LQI_LEN));

    /* The first byte of the received frame is the frame length. */
    rx_frame++;

    /*
     * The frame_info_t section of the receive buffer is initialized.
     * The receive buffer may have data from the previous transaction,
     * this can result in erroronous interpretations, particularly when the
     * source and the destination PAN ID/addresses are not present for the
     * currently received frame.
     */
    init_tal_parse_buffer(frame_to_mac);

    frame_to_mac->frame_ctrl = convert_byte_array_to_16_bit(rx_frame);
    rx_frame++;

    /*
     * The source and the destination address mode is extracted from the
     * frame control field of the received frame.
     */
    dest_address_mode = frame_to_mac->frame_ctrl & DEST_ADDR_MODE_MASK;
    src_address_mode  = frame_to_mac->frame_ctrl & SRC_ADDR_MODE_MASK;
    rx_frame++;

    /*
     * The frame_info_t is updated with the sequence number of the received
     * frame
     */
    frame_to_mac->seq_num = *rx_frame;
    rx_frame++;

    if (dest_address_mode != 0)
    {
        frame_to_mac->dest_panid = convert_byte_array_to_16_bit(rx_frame);
        rx_frame += PAN_ID_LEN;

        /*
         * This variable holds the length of the received frame.
         * The length includes frame header length(ie: MHR),
         * payload length(ie: MPDU) and the length of the FCS field.
         * The length of the payload is extracted by gradually decrementing
         * this variable for each of the elements present within the
         * frame header(MHR) of the received frame.
         */
        frame_length -= PAN_ID_LEN;

        /*
         * The frame_info_t structure is updated with the destination address.
         */
        if (DEST_SHORT_ADDR_MODE == dest_address_mode)
        {
            frame_to_mac->dest_address = convert_byte_array_to_16_bit(rx_frame);
            rx_frame += SHORT_ADDR_LEN;

            frame_length -= SHORT_ADDR_LEN;
        }
        else if (DEST_EXT_ADDR_MODE == dest_address_mode)
        {
            frame_to_mac->dest_address = convert_byte_array_to_64_bit(rx_frame);
            rx_frame += EXT_ADDR_LEN;

            frame_length -= EXT_ADDR_LEN;
        }
    }

    if (src_address_mode != 0)
    {
        if (!(frame_to_mac->frame_ctrl & INTRA_PAN_SUBFIELD))
        {
            /*
             * The source PAN ID is present in the frame only if the intra-PAN
             * bit is zero and source address mode is non zero.
             */
            frame_to_mac->src_panid = convert_byte_array_to_16_bit(rx_frame);
            rx_frame += PAN_ID_LEN;

            frame_length -= PAN_ID_LEN;
        }
        else
        {
            /*
             * The received frame does not contain a source PAN ID, hence
             * source PAN ID of the frame_info_t is updated with the current
             * device PAN ID.
             */
            frame_to_mac->src_panid = tal_pib_PANId;
        }

        /*
         * The frame_info_t structure is updated with the source address.
         */
        if (SRC_SHORT_ADDR_MODE == src_address_mode)
        {
            frame_to_mac->src_address = convert_byte_array_to_16_bit(rx_frame);
            rx_frame += SHORT_ADDR_LEN;

            frame_length -= SHORT_ADDR_LEN;
        }
        else if (SRC_EXT_ADDR_MODE == src_address_mode)
        {
            frame_to_mac->src_address = convert_byte_array_to_64_bit(rx_frame);
            rx_frame += EXT_ADDR_LEN;

            frame_length -= EXT_ADDR_LEN;
        }
    }

    /*
     * The payload length computed as
     * frame_length -= (PHY_HDR_LEN + FCF_LEN + SEQ_NUM_LEN + FCS_LEN)
     */
    frame_length -= (PHY_HDR_LEN + FCF_LEN + SEQ_NUM_LEN + FCS_LEN);

    frame_to_mac->payload = rx_frame;
    frame_to_mac->payload_length = frame_length;

    /*
     * The LQI is stored after the FCS(2 Bytes). The LQI is accessed
     * by moving to the end of the frame.
     */
    rx_frame += frame_length;
    frame_lqi = *(rx_frame + FCS_LEN);

    /*
     * The LQI normalization is done using the ED level measured during
     * the frame reception.
     */
    frame_lqi = compute_lqi(frame_lqi, frame_ed_level);

    frame_to_mac->buffer_header = buf;

    /* The callback function implemented by MAC is invoked. */
    tal_rx_frame_cb((frame_info_t *)incoming_frame, frame_lqi);
} /* process_incoming_frame() */


/**
 * @brief Uploads and filters frames from the transceiver buffer
 *
 * This function uploads and filters frames from the transceiver buffer and
 * appends the frame in the TAL incoming frame queue and allocates a buffer for
 * next frame reception.
 * If the frame passes all the filter criteria, then it is appended to the TAL
 * incoming frame queue. If the frame is appended successfuly to the queue, then
 * a new buffer is allocated for the next frame. Thetransceiver is switched off
 * if the buffer allocation is not successful. This will prevent the TAL from
 * acknowledging a frame when a receive buffer is not available.
 *
 * @param time_stamp Timestamp of the received frame.
 */
void upload_frame_alloc_buf(uint32_t time_stamp)
{
    uint16_t frame_read_delay_val;

    uint8_t *received_frame;
    uint8_t frame_length;
    ack_frame_t received_ack;
    uint8_t frame_ed_level;

    /* A Delay in symbols is introduced to avoid frame underrun. */
    pal_timer_delay(TAL_CONVERT_SYMBOLS_TO_US(UNDERRUN_AVOID_TIME));

    /* Only the length of the received frame is read. */
    pal_trx_frame_read(&frame_length, LENGTH_FIELD_LEN);

    /* The received frame length is checked for validity. */
    if ((frame_length < ACK_FRAME_LEN) ||
        (frame_length > aMaxPHYPacketSize))
    {
        /* The frame is not of valid length. */
        return;
    }

    if (tal_ack_expected)
    {
        /*
         * The node is waiting for an acknowledgement frame, hence the
         * received frame length should match the acknowledgement frame length.
         */
        if (ACK_FRAME_LEN == frame_length)
        {
            received_frame = (uint8_t *)&received_ack;
        }
        else
        {
            /* The frame is not of valid length. */
            return;
        }
    }
    else
    {
        /*
         * The node is not waiting for an acknowledgement frame.
         * The minimum frame length of any valid frame is 8.
         */
        if (frame_length < MIN_FRAME_LENGTH)
        {
            /* The frame is not of a valid length. */
            return;
        }

        if (NULL == tal_rx_buffer)
        {
            /* There is no buffer to receive the data, hence return. */
#if (DEBUG > 1)
            ASSERT(NULL != tal_rx_buffer);
#endif
            return;
        }

        received_frame = BMM_BUFFER_POINTER(tal_rx_buffer);

        received_frame = \
            received_frame + (LARGE_BUFFER_SIZE - (frame_length + LQI_LEN + 1));
    }

    /*
     * The  ED value is read from the transceiver and is stored to be used
     * later for LQI normalization
     */
    frame_ed_level = pal_trx_reg_read(RG_PHY_ED_LEVEL);

    /*
     * The PHY header is also included in the frame, hence the frame length
     * is incremented by 1.
     */
    frame_length += 1;

    /*
     * The delay for frame uploading is retrieved from the lookup table placed
     * in FLASH memory.
     */
    frame_read_delay_val = (uint16_t)PGM_READ_BYTE(&delay_table[frame_length - 1]);

    /* A Delay timer is started before the frame is read. */
    pal_timer_delay(TAL_CONVERT_SYMBOLS_TO_US(frame_read_delay_val));

    /* The Frame is read into receive buffer with CRC check. */
     if (CRC_INCORRECT == pal_trx_frame_read_crc((frame_length - 1), \
        received_frame))
    {
        /* CRC Error. */
        return;
    }

#if (DEBUG > 0)
    if (*received_frame != (frame_length - 1) )
    {
        ASSERT("Length MisMatch RX" == 0);
    }
#endif

    /*
     * The First byte read from the transceiver is the length, hence proceed
     * further
     */
    received_frame++;

    if (tal_ack_expected)
    {
        /*
         *************************************************
         * The received frame is an acknowledgement frame.
         *************************************************
         */
        /*
         * The acknowledgement frame is processed.The received acknowledgement
         * frame sequence number is stored.This is used by the TAL state
         * machine to determine if the acknowledgement frame received is a
         * valid acknowledgement frame or not.
         */
        tal_received_ack_dsn = received_ack.seq_num;

        /*
         * A flag indicating the reception of the acknowledgement frame to
         * the frame transmission unit is updated.
         */
        tal_ack_status |= ACK;

        /*
         * The frame pending information is retrieved from the acknowledgement
         * frame. The same flag used to indicate the reception of the
         * acknowledgement frame is updated with the frame pending information.
         */
        if (SET_FRAME_PENDING_MASK & received_ack.frame_control[0])
        {
            tal_ack_status |= FRAME_PENDING;
        }

        tal_ack_expected = false;
    }
    else
    {
        uint8_t seq_number;
        uint16_t dest_address_mode;
        uint16_t src_address_mode;
        uint16_t fcf;
        uint8_t command_frame_id;

        /*
         ************************************************************
         * The received frame is a regular valid IEEE 802.15.4 frame.
         ************************************************************
         */
        /*
         * The frame control information of the received frame is stored and
         * is later used for checking the validity of the received frame.
         */
        fcf = convert_byte_array_to_16_bit(received_frame);

        /*
         * A Secured MAC frame is not supported, hence if the security is
         * enabled the frame is discarded.
         */
        if (fcf & FCF_SECURITY_ENABLED)
        {
            return;
        }

        dest_address_mode = fcf & DEST_ADDR_MODE_MASK;
        src_address_mode = fcf & SRC_ADDR_MODE_MASK;

        /*
         * The frame type subfield of the frame control field shall not contain
         * an unsupported frame type.
         */
        if ((fcf & FRAME_TYPE_MASK) > VALID_FRAME_TYPE)
        {
            /* Unsupported frame. */
            return;
        }

        /*
         * The sequence number is the next field in the frame. The pointer to
         * the received frame is incremeneted by the length of the FCS field to
         * to get the sequence number of the current frame. */
        received_frame += FCS_LEN;

        /*
         * The  sequence number of the frame is stored and it is used while
         * sending an acknowledgement frame for the received frame.
         */
        seq_number = *received_frame;

        received_frame++;

        /*
         * The destination address and the destination PAN ID are verified to
         * determine the validity of the received frame.
         */
        if (dest_address_mode)
        {
            uint16_t pan_id;
            uint16_t short_addr;
            uint64_t extended_addr;

            pan_id = convert_byte_array_to_16_bit(received_frame);

            /*
             * The destination PAN ID can be broadcast or it should match the
             * current device PAN ID.
             */
            if ((BROADCAST != pan_id) && (tal_pib_PANId != pan_id))
            {
                /* Unsupported frame. */
                return;
            }

            received_frame += PAN_ID_LEN;

            if (DEST_SHORT_ADDR_MODE == dest_address_mode)
            {
                /*
                 * The source device is using a short addressing mode.
                 */
                short_addr = convert_byte_array_to_16_bit(received_frame);

                /*
                 * The destination short addres can be broadcast or it should
                 * match the current device short address.
                 */
                if ((BROADCAST != short_addr) && \
                    (tal_pib_ShortAddress != short_addr))
                {
                    /* Unsupported frame. */
                    return;
                }
                received_frame += SHORT_ADDR_LEN;
            }
            else
            {
                /* The source device is using an extended addressing mode. */
                extended_addr = convert_byte_array_to_64_bit(received_frame);

                /*
                 * The destination address should match the current device's
                 * extended address.
                 */
                if (extended_addr != tal_pib_IeeeAddress)
                {
                    /* Unsupported frame. */
                    return;
                }
                received_frame += EXT_ADDR_LEN;
            }
        } /* if (dest_address_mode) */
        else
        {
            /*
             * The destination address is not present. The frame is accepted
             * only if the node is a PAN coordinator or if the frame is a
             * beacon frame.
             */
            if (tal_pib_PrivatePanCoordinator ||  \
               (BEACON_FRAME == (fcf & FRAME_TYPE_MASK)))
            {
                /* It is ok to continue parsing the frame. */
            }
            else
            {
                /* Unsupported frame. */
                return;
            }
        }

        if (src_address_mode != 0)
        {
            uint16_t src_pan_id;

            if (!(fcf & INTRA_PAN_SUBFIELD))
            {
                if (!dest_address_mode)
                {
                    src_pan_id = convert_byte_array_to_16_bit(received_frame);

                    if (BEACON_FRAME != (fcf & FRAME_TYPE_MASK))
                    {
                        /*
                         * The device has received a frame that does not
                         * contain the destination PAN ID, hence the frame is a
                         * valid frame only if the source PAN ID is a broadcast
                         * PAN ID or if the source PAN ID matches the current
                         * device's PAN ID.
                         */
                        if ((tal_pib_PANId != src_pan_id) &&
                            (BROADCAST != src_pan_id))
                        {
                            /* The frame is an Invalid frame. */
                            return;
                        }
                    }
                }
               received_frame += PAN_ID_LEN;
            }

            if (SRC_SHORT_ADDR_MODE == src_address_mode)
            {
              received_frame += SHORT_ADDR_LEN;
            }
            else if (SRC_EXT_ADDR_MODE == src_address_mode)
            {
              received_frame += EXT_ADDR_LEN;
            }
        }

        /*
         * The Command Frame Identifier of the received frame is stored. This
         * is used while checking for a received data request frame.
         */
        command_frame_id = *received_frame;

        if (fcf & FCF_ACK_REQ)
        {
            uint32_t turn_around_time;
            uint32_t current_time;
            bool time_compare_status;
            bool set_frame_pending = false;

            /*
             * The acknowledgement frame is sent only for those frames that
             * can be successfully appended into the TAL incoming frame queue.
             * If the TAL incoming frame queue is full the acknowledgement
             * frame transmission is aborted.
             */
            if (tal_incoming_frame_queue.size == \
                tal_incoming_frame_queue.capacity)
            {
                /*
                 * The TAL incoming frame queue is full, hence acknowledgement
                 * frame transmission is aborted.
                 */
                return;
            }

            /*
             * The turnaround time is calculated. The 2 symbols needs to be
             * subtracted from the turnaround time because:
             * The TRX_END IRQ was received one symbol later than the
             * frame on the air. The second symbol is the
             * tx setup time before the ACK frame will
             * actually start.
             */
            turn_around_time = (aTurnaroundTime - 2);
            turn_around_time = \
                TAL_CONVERT_SYMBOLS_TO_US(turn_around_time);

            /*
             * The RX_START time of the frame and the time taken by the
             * transceiver to upload a frame of particular length
             * is known, hence the time remaining for the 'turnaround time'
             * to complete is computed.
             */
            turn_around_time = (time_stamp + \
                               TIME_FOR_FRAME_UPLOAD(frame_length) + \
                               turn_around_time);

            pal_get_current_time(&current_time);

            /*
             * The turnaround time delay is started only  if the current time
             * is less than the turnaround time. The function 'pal_compare_time'
             * returns true if 'turn_around_time' is smaller than 'current_time'
             * and false otherwise.
             */
            time_compare_status = pal_compare_time(turn_around_time, \
                                                   current_time);
            if (!time_compare_status)
            {
                /*
                 * There is still some time remaining for the turnaround time
                 * to complete. A delay timer is started for this time.
                 */
                turn_around_time = pal_sub_time_us(turn_around_time, \
                                                   current_time);
                pal_timer_delay((uint16_t)turn_around_time);
            }

            if (((fcf & FRAME_TYPE_MASK) == MAC_CMD_FRAME))
            {
                /*
                 * Only for a data request frame the frame pending bit is set
                 * to true. This is done to acknowledge the data request frame
                 * without any delays.
                 */
                if (DATA_REQ_ID == command_frame_id)
                {
                    set_frame_pending = true;
                }
            }

            /*
             * The Turnaround time is already taken care of, hence the
             * acknowledgement frame is sent.
             */
            send_ack(seq_number, set_frame_pending);

            /*
             * Only if the receive buffer is available, the receiver is
             * switched on.
             */
            if (tal_rx_buf_available)
            {
                while (PHY_RX_ON != set_trx_state(PHY_RX_ON));
            }
        }
        {
            uint8_t *store_info;
            store_info = BMM_BUFFER_POINTER(tal_rx_buffer);

            ((rcvd_frame_info_t*)store_info)->rcvd_frame_length = frame_length;
            ((rcvd_frame_info_t*)store_info)->rcvd_frame_ed_level = \
                                                                frame_ed_level;
            /*
             * Timestamp is stored and will be used while creating the
             * frame_info_t structure to the MAC layer.
             */
            ((rcvd_frame_info_t*)store_info)->rcvd_frame_timestamp = \
                                                                time_stamp;
        }
        /* Add buffer to TAL Incoming frame queue */
        if (SUCCESS == \
            qmm_queue_append(&tal_incoming_frame_queue, tal_rx_buffer))
        {
            /* Allocate a new buffer to receive further incoming frames */
            tal_rx_buffer = bmm_buffer_alloc(LARGE_BUFFER_SIZE);

            if (NULL == tal_rx_buffer)
            {
                /*
                 * If buffer is not available for receiving the next frame,
                 * then the receiver is switched off. Before switching off the
                 * transceiver the current state of the receiver will be stored
                 * and will be restored whenever a free buffer is available.
                 */
                tal_rx_buf_available = false;
                tal_rx_on = true;

                /*
                 * Buffer not available to receive the incoming frames
                 * hence turn off the receiver and set the flag
                 * indicating buffer availability to false. Do not check for
                 * the return value of set_trx_state() as the transceiver will
                 * be set to TRX_OFF state.
                 */
                set_trx_state(CMD_FORCE_TRX_OFF);
            }
        }
    }
} /* upload_frame_alloc_buf() */


/*
 * @brief Sends an acknowledgement frame
 *
 * This function sends an acknowledgement frame.
 *
 * @param sequence_num Sequence number for acknowledgment frame.
 * @param set_frame_pending Specifies if the pending bit in the acknowledgement
 * frame is to be set or not.
 */
static void send_ack(uint8_t sequence_num, bool set_frame_pending)
{
    uint8_t trx_state;
    uint8_t tx_retry;

#ifdef SPECIAL_PEER
    if (0xFF == tal_pib_PrivateDisableACK)
    {
        return;
    }
    else if (tal_pib_PrivateDisableACK > 0)
    {
        tal_pib_PrivateDisableACK--;
        return;
    }
#endif /* SPECIAL_PEER */

    /*
     * Frame pending information is provided by MAC and it has to be
     * updated in the acknowledgment frame
     */

    /* Check if frame pending bit needs to be set for this ack */
    if (set_frame_pending)
    {
        /* Set the frame pending bit */
        ack_frame.frame_control[0] |= SET_FRAME_PENDING_MASK;
    }
    else
    {
        /* Clear the frame pending bit */
        ack_frame.frame_control[0] &= CLEAR_FRAME_PENDING_MASK;
    }

    /* Copy the sequence number of frame which needs to be acked */
    ack_frame.seq_num = sequence_num;

    /* Turn on the transmitter */
    while (PHY_TX_ON != set_trx_state(PHY_TX_ON));

    ENTER_CRITICAL_REGION();

    /*
     * TX fails if phy does not immediately change PHY state to TX_BUSY.
     * In this case a recovery sequence is performed and TX is retried.
     */
    for (tx_retry = 0; tx_retry < MAX_TX_RETRY; tx_retry++)
    {
        /* A TX_START command is given by toggling the SLP_TR pin */
        pal_gpio_set(SLP_TR_PIN, HIGH);
        pal_gpio_set(SLP_TR_PIN, LOW);

        /*
         * Send the ack frame to the transceiver
         */
        pal_trx_frame_write((uint8_t *)&ack_frame, (ACK_FRAME_LEN + 1));

        trx_state = pal_trx_reg_read(RG_TRX_STATUS);

        if (PHY_BUSY_TX != trx_state)
        {
            /*
             * This is a transmission failure case, hence a recovery process is
             * carried out.
             */

            /* The receiver is switched on for a moment */
            pal_trx_reg_write(RG_TRX_STATE, RX_ON);

            pal_timer_delay(PLL_BUSY_TX_RX_ON_TIMEOUT);

            /* Switch back PLL_ON to continue TX */
            pal_trx_reg_write(RG_TRX_STATE, PLL_ON);

            do
            {
                trx_state = pal_trx_reg_read(RG_TRX_STATUS);
            } while (PLL_ON != trx_state);
        }
        else
        {
            /*
             * No operation is done till the acknowledgement frame is completely
             * sent out by the transceiver
             */
            do
            {
                trx_state = pal_trx_reg_read(RG_TRX_STATUS);
            } while (BUSY_TX == trx_state);
            break;
        }
    }

    LEAVE_CRITICAL_REGION();
} /* send_ack() */


/*
 * @brief Computes LQI
 *
 * This function computes LQI by merging the RSSI (from phyRSSI) and LQI
 * values into the final ppduLinkQuality value.
 *
 * @param lqi specifies the link quality of the received frame.
 * @param frame_ed_level specifies the averaging RSSI values over eight symbols
 *
 * @return LQI_MAX if the linkquality computed is greater than the MAX_LQI
 * or ppdu linkquality computed by combining RSSI and LQI value.
 */
static uint8_t compute_lqi(uint8_t lqi, uint8_t frame_ed_level)
{
    uint8_t rssi;
    uint16_t linkquality;

    /*
     * RSSI ranges from 0 through 27 (inclusive). Two stations
     * physically located side by side yield an RSSI of 15...16
     * (i. e. ~ -40 dBm), so we can safely consider that the maximum
     * useful value.
     *
     * Rx LQI normally is close to 255 unless there is severe
     * interference on the channel (multipath propagation, other radio
     * interference). For frames with an LQI below ~ 200, the packet
     * error rate drastically increases, so we consider 192 to be the
     * smallest useful value.
     *
     * The formula chosen includes some square of the LQI value so
     * frames with a low RSSI but full LQI will still get a reasonable
     * ppduLinkQuality as they are pretty fine to be used except the
     * distance between Tx and Rx is rather close to the usable range.
     */

    /* Normalize LQI to 0..63 */
    if (lqi < SATISFACTORY_LQI_VAL)
    {
        lqi = 0;
    }
    else
    {
        lqi -= SATISFACTORY_LQI_VAL;
    }

    /* Normalize RSSI to 0..15 */
    if (frame_ed_level > SATISFACTORY_RSSI_VAL)
    {
        rssi = SATISFACTORY_RSSI_VAL;
    }
    else
    {
        rssi = frame_ed_level;
    }

    /*
     * This is the square component. It makes small RSSI values more
     * preferrable provided the LQI was still good.
     */
    rssi += (lqi & (uint8_t)LQI_MASK) >> 4;

    lqi /= 4;                   /* range 0..15 */

    linkquality = lqi * rssi;
    if (linkquality >= LQI_MAX)
    {
        return (LQI_MAX);
    }

    return (linkquality);
} /* compute_lqi() */


/*
 * @brief Initializes the frame_info_t structure.
 *
 * @param[out] frame_info Pointer to the frame_info structure to be
 * initialized.
 */
static void init_tal_parse_buffer(frame_info_t *frame_info)
{
    frame_info->msg_type = (frame_msgtype_t)0;
    frame_info->frame_ctrl = 0xFFFF;
    frame_info->seq_num = 0;
    frame_info->dest_panid = 0;
    frame_info->dest_address = 0;
    frame_info->src_panid = 0;
    frame_info->src_address = 0;
    frame_info->payload_length = 0;
    frame_info->payload = NULL;
}
/* EOF */
