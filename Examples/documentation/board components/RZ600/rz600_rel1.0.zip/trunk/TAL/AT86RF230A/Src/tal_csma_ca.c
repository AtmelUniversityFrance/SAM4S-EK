/**
 * @file tal_csma_ca.c
 *
 * @brief This file implements Slotted and Unslotted CSMA-CA functions.
 *
 * $Id: tal_csma_ca.c 11791 2008-11-04 17:49:11Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================= */

#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include "platform_types.h"
#include "phy230_registermap.h"
#include "return_val.h"
#include "bmm.h"
#include "tal.h"
#include "ieee_const.h"
#include "pal.h"
#include "tal_internal.h"
#include "tal_constants.h"
#include "tal_csma_ca.h"
#include "tal_pib.h"
#include "tal_rf230a.h"

/* === Macros =============================================================== */

/** Short address not assigned. */
#define NO_SHORT_ADDR               (0xFFFF)

/**
 * The total number of slots is 16, range of slots is 0 - 15  and the
 * final CAP slot is 15.
 */
#define FINAL_CAP_SLOT              (0x0F)

/** BO value for nonbeacon-enabled network. */
#define NON_BEACON_NWK              (0x0F)

/** Time taken by PAL to process a command issued to the transceiver for ATmega1281 */
#define PAL_FUZZ_FACTOR                 (12)

/* === Globals ============================================================== */

/*
 * Holds the current CSMA-CA state.
 */
static uint8_t current_csma_ca_state = CSMA_CA_INIT;

#ifndef NOBEACON
/*
 * Holds the length of the current transaction, only used for slotted CSMA-CA
 * operation.
 */
static uint8_t transaction_length;

/*
 * Holds the value for the contention window length, defining the number of
 * backoff periods that need to be clear of channel activity before the
 * transmission can commence.
 */
static uint8_t CW;
#endif /* NOBEACON */

/*
 * Holds the number of times the CSMA-CA algorithm was required to backoff
 * while attempting the current transmission.
 */
static uint8_t NB;

/*
 * Holds the Backoff exponent value which is related to how many backoff periods
 * a device shall wait before attempting to assess a channel.
 */
static uint8_t BE;

/* === Prototypes =========================================================== */

static uint8_t cca_request(void);
static retval_t csma_ca_cca_done(uint8_t cca_status);
static retval_t csma_ca_backoff(bool do_rand);
static retval_t csma_ca_init(uint8_t init_nb);
static void backoff_expiry_handler_cb(void *callback_parameter);

/* === Implementation ======================================================= */

/*
 * @brief Initialize CSMA-CA.
 *
 * This function initializes NB, CW and BE and initiates csma_ca_backoff.
 * The transaction length in symbols for the frame to be transmitted using
 * slotted CSMA-CA is also calcuated.
 *
 * @param init_nb Specifies if csma_ca_init() is called initially before the
 * start of frame transmission or it is called while the frame is being retried.
 *
 * @return SUCCESS if backoff timer is started is successful or FAILURE
 * otherwise.
 */
static retval_t csma_ca_init(uint8_t init_nb)
{
    retval_t status;

    if (init_nb)
    {
        NB = 0;

#ifndef NOBEACON
        if (tal_pib_BeaconOrder < NON_BEACON_NWK)
        {
            uint8_t ack_is_requested;

            /*
             * In slotted operation, the number of symbols required for the
             * current transaction to complete is computed.
             */
            transaction_length = (*tal_frame_to_tx) + PHY_OVERHEAD;
            ack_is_requested = *(tal_frame_to_tx + FCF_OFFSET) & ACK_MASK;

            if (ack_is_requested > 0)
            {
                /*
                 * The CSMA-CA module ensures that the entier frame is
                 * transmitted and the corresponding acknowledgement frame is
                 * received within a single superframe, hence the
                 * acknowledgement frame length is also included while computing
                 * the transaction length.
                 */
                transaction_length += ACK_FRAME_LEN + PHY_OVERHEAD + 1;
                transaction_length *= SYMBOLS_PER_OCTET;
                transaction_length += aUnitBackoffPeriod;
            }
            else
            {
                transaction_length *= SYMBOLS_PER_OCTET;
            }

            /*
             * The NHLE needs a finite amount of time to process data received.
             * To allow for this,transmitted frames is followed by an IFS
             * period; if the transmission requires an acknowledgment,
             * the IFS follows the acknowledgment frame. The length of the IFS
             * period is dependent on the size of the frame that has just been
             * transmitted. Frames (i.e., MPDUs) of up to aMaxSIFSFrameSize in
             * length is followed by a SIFS period of a duration of at least
             * aMinSIFSPeriod symbols. Frames (i.e., MPDUs) with lengths greater
             * than aMaxSIFSFrameSize shall be followed by a LIFS of a duration
             * of at least of MinLIFSPeriod symbols.
             */
            if ((*tal_frame_to_tx) <= aMaxSIFSFrameSize)
            {
                transaction_length += aMinSIFSPeriod;
            }
            else
            {
                transaction_length += aMinLIFSPeriod;
            }
        }
#endif /* NOBEACON */
    }

#ifndef NOBEACON
    /*
     * The contention window is initialized to 2 before each frame transmission
     */
    CW = 2;
#endif /* NOBEACON */
    BE = tal_pib_MinBE;

    if (tal_pib_BattLifeExt && (BE > 2))
    {
        BE = 2;
    }

    status = csma_ca_backoff(true);
    return (status);
} /* csma_ca_init() */


/*
 * @brief Random backoff time calculated and backoff initiated
 *
 * This function performs backoff timer calculations and start the timer for
 * the backoff duration.
 *
 * @param do_rand Specifies if random backoff is to be performed or not.
 *
 * @return SUCCESS if the backoff timer is started successfully or FAILURE
 * if backoff timer could not be started as the timer is already running or
 * the timer ID is invalid.
 */
static retval_t csma_ca_backoff(bool do_rand)
{
#ifndef NOBEACON
    uint8_t superframe_inactive_time;
    /* Holds the beacon Interval Time calculated using the Beacon Order. */
    uint32_t roll_over_time = 0;
    uint32_t symbols_elapsed_since_beacon;
    uint32_t time;
    uint32_t next_backoff_periods;
    uint32_t next_backoff_symbols;
    uint32_t cap_period;
    uint32_t now_time;
#endif /* NOBEACON */

    uint32_t backoff_time = 0;
    retval_t timer_status;

    if (do_rand)
    {
        /* The random backoff exponent is calculated. */
         backoff_time = (uint8_t)(rand() & ((1 << BE) - 1)) * \
                         aUnitBackoffPeriod;
    }

#ifndef NOBEACON
    /*
     * Slotted CSMA-CA is performed if: beaconing AND associated AND not
     * sending an Association Request frame.
     */
    if ((tal_pib_BeaconOrder < NON_BEACON_NWK) && \
        (NO_SHORT_ADDR != tal_pib_ShortAddress)&& \
        (!tal_unslotted_csma_required))
    {
        roll_over_time = TAL_GET_BEACON_INTERVAL_TIME(tal_pib_BeaconOrder);

        /*
         * The current time in microseconds is used for calculating the time
         * elapsed since the previous beacon transmission.
         */
        pal_get_current_time(&now_time);
        now_time = TAL_CONVERT_US_TO_SYMBOLS(now_time);

        while ((symbols_elapsed_since_beacon = \
                tal_sub_time_symbols(now_time, tal_pib_BeaconTxTime)) > \
                roll_over_time)
        {
            /*
             * The device has not heard the last beacon, hence the beacon
             * transmission time is adjusted accordingly.
             */
            tal_pib_BeaconTxTime = tal_add_time_symbols(tal_pib_BeaconTxTime, \
                                                   roll_over_time);
        }

        /*
         * Some fuzz factor is added to compensate for the following
         * calculations, plus the subsequent CCA.
         */
        symbols_elapsed_since_beacon = \
            tal_add_time_symbols(symbols_elapsed_since_beacon, \
                                (CCA_PERIOD + PAL_FUZZ_FACTOR));

        /* The next backoff boundary (in backoff periods) is computed. */
        next_backoff_periods = (symbols_elapsed_since_beacon / \
                               (uint32_t)aUnitBackoffPeriod) + 1;

        /* The next backoff boundary is converted to symbols. */
        next_backoff_symbols = next_backoff_periods * \
                                (uint32_t)aUnitBackoffPeriod;

        /* The random backoff time is added. */
        time = tal_add_time_symbols(backoff_time, next_backoff_symbols);

        /* The active portion is computed. */
        superframe_inactive_time = \
            TAL_GET_SUPERFRAME_DURATION_TIME(tal_pib_SuperFrameOrder);

        /* aNumSuperframeSlots == 16 */
        cap_period = (superframe_inactive_time / aNumSuperframeSlots) * \
                     (FINAL_CAP_SLOT + 1);

        if ((tal_add_time_symbols(transaction_length, time)) > \
            (tal_add_time_symbols(cap_period, tal_pib_BeaconTxTime)))
        {
            /*
             * The frame transmission cannot be complete within the current
             * superframe, hence a timer which will expire sometime shortly
             * after the next beacon is transmitted is started.The frame
             * is sent only in the next superframe.
             */
            time = tal_add_time_symbols(tal_pib_BeaconTxTime, aMinLIFSPeriod);
            time = tal_add_time_symbols(time, roll_over_time);
            time = tal_add_time_symbols(time, \
                                   (aMaxPHYPacketSize * SYMBOLS_PER_OCTET));

            do
            {
               /*
                * The CSMA-CA Backoff timer is started. If the attempt to start
                * the backoff timer failed due to INVALID_TIMEOUT, then time is
                * extrapolated till the backoff timer can be started
                * successfully.
                * If the failure is due to the timer ALREADY_RUNNING or due to
                * an INVALID_ID then a recovery is not possible CSMA-CA is
                * aborted and return FAILURE.
                */
               timer_status = pal_timer_start(CSMA_CA_BACKOFF, \
                                            TAL_CONVERT_SYMBOLS_TO_US(time), \
                                            TIMEOUT_ABSOLUTE, \
                                            (void *)backoff_expiry_handler_cb, \
                                            NULL);

                time += aUnitBackoffPeriod;

                if (INVALID_TIMEOUT != timer_status &&
                    SUCCESS != timer_status)
                {
#if (DEBUG > 0)
                    ASSERT(" CSMA-CA Start Time Failed" == 0);
#endif
                    return (FAILURE);
                }
            } while (SUCCESS != timer_status);

            /*
             * The CSMA-CA state is changed to BACKOFF. The device continue to
             * remain in this state till the backoff timer expires.
             */
            current_csma_ca_state = BACKOFF;
            return (SUCCESS);
        }

        /*
         * The frame transmission can be completed within the current
         * superframe.
         */

        time = tal_add_time_symbols(time, tal_pib_BeaconTxTime);

        do
        {
           /*
            * The CSMA-CA Backoff timer is started. If the attempt to start
            * the backoff timer failed due to INVALID_TIMEOUT, then time is
            * extrapolated till the backoff timer can be started
            * successfully.
            * If the failure is due to the timer ALREADY_RUNNING or due to
            * an INVALID_ID then a recovery is not possible CSMA-CA is
            * aborted and return FAILURE.
            */
            timer_status = pal_timer_start(CSMA_CA_BACKOFF, \
                                           TAL_CONVERT_SYMBOLS_TO_US(time), \
                                           TIMEOUT_ABSOLUTE, \
                                           (void *)backoff_expiry_handler_cb, \
                                           NULL);

            time += aUnitBackoffPeriod;

            if (INVALID_TIMEOUT != timer_status &&
                SUCCESS != timer_status)
            {
#if (DEBUG > 0)
                ASSERT(" CSMA-CA Start Time Failed" == 0);
#endif
                return (FAILURE);
            }
        } while (SUCCESS != timer_status);

        /*
         * The CSMA-CA state is changed to BACKOFF. The device continue to
         * remain in this state till the backoff timer expires.
         */
        current_csma_ca_state = BACKOFF;
    }
    else
#endif /* NOBEACON */
    {
        if (0 == backoff_time)
        {
            /* The timeout is zero -> trigger CCA in the next cycle. */
            current_csma_ca_state = PERFORM_CCA;
        }
        else
        {
            backoff_time = TAL_CONVERT_SYMBOLS_TO_US(backoff_time);

            timer_status = pal_timer_start(CSMA_CA_BACKOFF, \
                                           backoff_time, \
                                           TIMEOUT_RELATIVE, \
                                           (void *)backoff_expiry_handler_cb, \
                                           NULL);
            /*
             * The pal_timer_start returns SUCCESS if the timer is started
             * successfully, hence change the CSMA-CA state to BACK_OFF. If the
             * pal_timer_start returns INVALID_TIMEOUT, ALREADY_RUNNING or
             * INVALID_ID then immediately move to performing CCA.
             * Note: The timer is started to perform "unslotted" CSMA-CA hence
             * even if the timer start fails proceed to performing CCA.
             */
            if (SUCCESS != timer_status)
            {
#if (DEBUG > 1)
                ASSERT(INVALID_TIMEOUT != timer_status);
#endif
                current_csma_ca_state = PERFORM_CCA;
            }
            else
            {
                current_csma_ca_state = BACKOFF;
            }
        }
    }
    return (SUCCESS);
} /* csma_ca_backoff() */


/*
 * @brief CSMA_CA_BACKOFF timer callback
 *
 * This function is the callback of the CSMA_CA_BACKOFF timer.
 * On expiry csma_ca is continued.
 *
 * @param callback_parameter Callback parameter.
 */
static void backoff_expiry_handler_cb(void *callback_parameter)
{
    current_csma_ca_state = PERFORM_CCA;

    callback_parameter = callback_parameter;  /* Keep compiler happy. */
}


/*
 * @brief Performs CCA
 *
 * This function performs CCA on the current channel to find if the channel is
 * busy or idle.
 *
 * @return cca_status is PHY_BUSY if traffic is detected on the channel and
 * PHY_IDLE if the channel is free.
 */
static uint8_t cca_request(void)
{
    uint8_t trx_status;
    uint8_t cca_status;

    /*
     * The transceiver interrupts are disabled to prevent frame reception
     * while performing CCA.
     */
    pal_trx_irq_disable(TRX_MAIN_IRQ_HDLR_IDX);

    /* The transceiver is temporarily set to TX_ON before switching to RX_ON. */
    while (PHY_TX_ON != set_trx_state(PHY_TX_ON));
    while (PHY_RX_ON != set_trx_state(PHY_RX_ON));

    /* The CCA is started. */
    trx_status = pal_trx_reg_read(RG_PHY_CC_CCA);
    trx_status &= ~(CMD_CCA_REQUEST);
    trx_status |= CMD_CCA_REQUEST;

    pal_trx_reg_write(RG_PHY_CC_CCA, trx_status);
    pal_timer_delay(TAL_CONVERT_SYMBOLS_TO_US(CCA_PERIOD));

    trx_status = pal_trx_reg_read(RG_TRX_STATUS);

    if ((trx_status & CCA_STATUS_MASK) > 0)
    {
       cca_status = PHY_IDLE;
#ifdef SPECIAL_PEER
        if (1 == tal_pib_PrivateCCAFailure)
        {
            cca_status = PHY_BUSY;
        }
#endif /* SPECIAL_PEER */
    }
    else
    {
        cca_status = PHY_BUSY;
    }

    /* The transceiver interrupts are enabled. */
    pal_trx_irq_enable(TRX_MAIN_IRQ_HDLR_IDX);
    return (cca_status);
}


/*
 * @brief Returns result of CCA
 *
 * This function returns the result of the CCA assessment. This determines
 * whether to continue CSMA-CA or not.
 * The result is based on the number of remaining backoffs or the status of the
 * last CCA in case of a nonbeacon-enabled network.
 *
 * @param cca_status Specifies the result of the CCA performed on the channel
 *
 * @return SUCCESS if the CSMA-CA operation is complete, CSMA_CA_IN_PROGRESS
 * if CSMA-CA has not been completed or CHANNEL_ACCESS_FAILURE if the channel is
 * found to be busy even after the maximum CSMA-CA backoffs.
 */
static retval_t csma_ca_cca_done(uint8_t cca_status)
{
    retval_t back_off_status;

    if (PHY_IDLE == cca_status)
    {
#ifndef NOBEACON
        if ((NON_BEACON_NWK == tal_pib_BeaconOrder) || (--CW == 0))
#endif /* NOBEACON */
        {
            /*
             * Unslotted CSMA-CA, or slotted CSMA-CA and contention
             * window exhausted. The frame transmission is initiated.
             */
            return (SUCCESS);
        }
#ifndef NOBEACON
        else
        {
            /*
             * This is slotted CSMA-CA, hence next attempt is inside the
             * contention window.
             */
            current_csma_ca_state = BACKOFF;
            back_off_status = csma_ca_backoff(false);

            if (FAILURE == back_off_status)
            {
#if (DEBUG > 1)
                ASSERT("CHANNEL_ACCESS_FAILURE" == 0);
#endif
                return (CHANNEL_ACCESS_FAILURE);
            }
            else
            {
                return (CSMA_CA_IN_PROGRESS);
            }
        }
#endif /* NOBEACON */
    }
    else
    {
        /*
         * The Channel is busy, start over.
         */
        if (++NB > tal_pib_MaxCSMABackoffs)
        {
#if (DEBUG > 1)
            ASSERT("CHANNEL_ACCESS_FAILURE" == 0);
#endif
            /* CSMA-CA failed */
            return (CHANNEL_ACCESS_FAILURE);
        }
        else
        {
            if (BE != aMaxBE)
            {
                BE++;
            }

#ifndef NOBEACON
            CW = 2;
#endif /* NOBEACON */

            /*
             * The device continues to remain in BACKOFF state till the backoff
             * timer expires.
             */
            current_csma_ca_state = BACKOFF;

            /* The random backoff is initiated. */
             back_off_status = csma_ca_backoff(true);

            if (FAILURE == back_off_status)
            {
#if (DEBUG > 1)
                ASSERT("CHANNEL_ACCESS_FAILURE" == 0);
#endif
                return (CHANNEL_ACCESS_FAILURE);
            }
            else
            {
                return (CSMA_CA_IN_PROGRESS);
            }
        }
    }
} /* csma_ca_cca_done() */


/**
 * @brief CSMA-CA state machine
 *
 * This function handles the state transition that can happen while
 * performing CSMA-CA. This function should be called continuously by TAL
 * when the TAL is in TAL_CSMA_CA state.
 *
 * @param init_nb Specifies if csma_ca_init() is called initially before the
 * start of frame transmission or it is called while the frame is being retried.
 *
 * @return SUCCESS if the CSMA-CA operation is complete, CSMA_CA_IN_PROGRESS
 * if CSMA-CA has not completed or CHANNEL_ACCESS_FAILURE if the channel is
 * found to be busy even after the maximum CSMA-CA backoffs.
 */
uint8_t csma_ca_state_handling(bool init_nb)
{
    /* The Default CSMA-CA state is CSMA_CA_IN_PROGRESS. */
    uint8_t csma_ca_result = CSMA_CA_IN_PROGRESS;

    switch (current_csma_ca_state)
    {
        case CSMA_CA_INIT:
            {
                uint8_t status;

                /*
                 * This is the initial CSMA_CA state. NB, CW and BE are
                 * initialized and performs is initiated.
                 */
                status = csma_ca_init(init_nb);

                if (SUCCESS != status)
                {
                    /*
                     * The CSMA-CA backoff timer could not be started, abort
                     * CSMA-CA operation.
                     */
                    csma_ca_result = CHANNEL_ACCESS_FAILURE;

                    /* The CSMA-CA state is initialized to its default value. */
                    current_csma_ca_state = CSMA_CA_INIT;
                }
            }
            break;

        case BACKOFF:
            /*
             * No operation is performed in this state as the backofftimer is
             * running
             */
            break;

        case PERFORM_CCA:
            {
                uint8_t cca_status;

                /* To perform CCA turn ON the receiver. */
                while (PHY_RX_ON != set_trx_state(PHY_RX_ON));

                cca_status = cca_request();
                csma_ca_result = csma_ca_cca_done(cca_status);

                if (SUCCESS == csma_ca_result || \
                    CHANNEL_ACCESS_FAILURE == csma_ca_result)
                {
                    /* Initialize the CSMA-CA state. */
                    current_csma_ca_state = CSMA_CA_INIT;
                }
            }
            break;

        default:
#if (DEBUG > 0)
            ASSERT("INVALID CSMA CA status" == 0);
#endif
            break;
    }
    return (csma_ca_result);
} /* csma_ca_state_handling() */


/**
 * @brief Reset CSMA-CA state machine
 */
void init_csma_ca_state(void)
{
    current_csma_ca_state = CSMA_CA_INIT;
}


/**
 * @brief Get the current CSMA-CA state
 *
 * @return Specifies the current CSMA-CA state.
 */
uint8_t get_current_csma_ca_state(void)
{
    return (current_csma_ca_state);
}

/* EOF */
