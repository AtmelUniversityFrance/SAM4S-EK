/**
 * @file tal_rf230a.h
 *
 * @brief This file contains transceiver AT86RF230Rev.A specific register
 * addresses and different transceiver states.
 *
 * $Id: tal_rf230a.h 11056 2008-09-15 08:00:34Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef TAL_RF230A_H
#define TAL_RF230A_H

/* === Includes ============================================================= */


/* === Macros =============================================================== */

/**
 * The device part number
 *
 * @ingroup AT86RF230AReg
 */
#define AT86_RF230A_PART_NUM        (0x02)

/**
 * The device version number
 *
 * @ingroup AT86RF230AReg
 */
#define AT86_RF230A_VERSION_NUM     (0x01)

/**
 * Register value to disable all interrupts of the transceiver
 *
 * @ingroup AT86RF230AReg
 */
#define DISABLE_TRX_IRQ_MASK        (0x00)

/**
 * Register value to enable the interrupts of the transceiver
 *
 * @ingroup AT86RF230AReg
 */
#define ENABLE_TRX_IRQ_MASK         (TRX_END | RX_START)

/**
 * Bit map of the channels supported by RF230 transceiver for the band 2.4 Ghz
 * channels 11 - 26
 *
 * @ingroup AT86RF230AReg
 */
#define RF230_SUPPORTED_CHANNELS    (0x07FFF800)

/**
 * Mask to obtain the result of CCA
 *
 * @ingroup AT86RF230AReg
 */
#define CCA_STATUS_MASK             (0x40)

/**
 * Mask to obtain the status of CCA
 *
 * @ingroup AT86RF230AReg
 */
#define CCA_DONE_MASK               (0x80)

/**
 * Access parameters for sub-register TX_AUTO_CRC_ON in register
 *
 * @ingroup AT86RF230AReg
 */
#define TX_AUTO_CRC_ON              (0x80)

/**
 * Access parameters for sub-register TX_PWR in register
 *
 * @ingroup AT86RF230AReg
 */
#define TX_POWER_MASK               (0x80)

/**
 * Constant to start ed
 *
 * @ingroup AT86RF230AReg
 */
#define CMD_START_ED                (0x00)

/**
 * Constant to start a CCA check
 *
 * @ingroup AT86RF230AReg
 */
#define CMD_CCA_REQUEST             (0x80)

/**
 * Mask to select one of the CCA modes
 *
 * @ingroup AT86RF230AReg
 */
#define CCA_MASK                    (0x1F)

/**
 * Mask to select one of the available channels
 *
 * @ingroup AT86RF230AReg
 */
#define CHANNEL_MASK                (0xE0)

/**
 * Constant indicating reception of a valid SFD interrupt
 *
 * @ingroup AT86RF230AReg
 */
#define RX_START                    (0x04)

/**
 * Constant indicating frame transmission/reception end interrupt
 *
 * @ingroup AT86RF230AReg
 */
#define TRX_END                     (0x08)

/**
 * Interrupt to signal frame underrun
 *
 * @ingroup AT86RF230AReg
 */
#define TRX_UR                      (0x40)

/**
 * This macro holds the time in microseconds for transceiver to sleep from
 * trx_off state
 *
 * @ingroup AT86RF230AReg
 */
#define TRX_SLEEP_DELAY             (35)

/**
 * A time of 880 microseconds is required for the transceiver to wake-up
 * from sleep
 *
 * @ingroup AT86RF230AReg
 */
#define TRX_AWAKE_DELAY             (880)

/**
 * A delay of 100 microseconds is provided when the initial attempt to wake-up
 * the transceiver from sleep failed.
 *
 * @ingroup AT86RF230AReg
 */
#define TRX_AWAKE_RETRY_DELAY       (100)

/**
 * Time in microseconds to wait for PLL lock to take place.
 *
 * @ingroup AT86RF230AReg
 */
#define PLL_LOCK_TIMEOUT_VALUE      (192)

/**
 * 140 microseconds symbols is the time to wait, to read the
 * ED value from the transceiver
 *
 * @ingroup AT86RF230AReg
 */
#define ED_SAMPLING_TIME            (140)

/**
 * Reset pulse width is 6 microseconds
 *
 * @ingroup AT86RF230AReg
 */
#define RESET_PIN_SET_TIME          (6)

/**
 * Sleep pulse width is 6 microseconds
 *
 * @ingroup AT86RF230AReg
 */
#define SLEEP_PIN_SET_TIME          (6)

/**
 * A time of 6 microseconds is required to set the state of the transceiver to
 * TRX_OFF
 *
 * @ingroup AT86RF230AReg
 */
#define FORCE_TRX_SET_TIME          (6)

/**
 * A 12 symbol delay is required before reading the cca status from the
 * transceiver
 */
#define CCA_PERIOD                  (12)

/**
 * Time taken by the transceiver to change from P_ON state to TRX_OFF state
 * on power ON is 510 microseconds
 *
 * @ingroup AT86RF230AReg
 */
#define TRX_SETTLING_TIME           (510)

/**
 * Time in microseconds taken by the transceiver to attain the TRX_OFF state
 * after reset.
 *
 * @ingroup AT86RF230AReg
 */
#define RESET_TO_TRX_OFF_DELAY      (120)

/**
 * Maximum number of tx recovery retries in case TX fails
 */
#define MAX_TX_RETRY                (10)

/**
 * Time in microseconds to wait for PLL from BUSY_TX to RX_ON
 */
#define PLL_BUSY_TX_RX_ON_TIMEOUT   (128)

/* === Types ================================================================ */


/* === Externals ============================================================ */


/* === Prototypes ========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* TAL_RF230A_H */
/* EOF */
