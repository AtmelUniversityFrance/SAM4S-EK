/**
 * @file tal_csma_ca.h
 *
 * @brief This file provides CSMA-CA functions and contains
 * CSMA-CA states.
 *
 * $Id: tal_csma_ca.h 11056 2008-09-15 08:00:34Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef TAL_CSMA_CA_H
#define TAL_CSMA_CA_H

/* === Includes ============================================================= */


/* === Macros =============================================================== */


/* === Types ================================================================ */

/*
 * CSMA-CA states
 */
typedef enum csma_ca_state_tag
{
    CSMA_CA_INIT        = 0,
    BACKOFF             = 1,
    PERFORM_CCA         = 2
} csma_ca_state_t;

/* === Externals ============================================================ */


/* === Prototypes =========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

uint8_t csma_ca_state_handling(bool init_nb);

void init_csma_ca_state(void);

uint8_t get_current_csma_ca_state(void);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* TAL_CSMA_CA_H */
/* EOF */
