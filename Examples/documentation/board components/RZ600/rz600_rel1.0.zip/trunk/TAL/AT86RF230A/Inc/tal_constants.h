/**
 * @file tal_constants.h
 *
 * @brief This header file contains constants specific to TAL and
 * timer identifiers used by TAL.
 *
 * $Id: tal_constants.h 11056 2008-09-15 08:00:34Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef TAL_CONSTANTS_H
#define TAL_CONSTANTS_H

/* === Includes ============================================================= */

/* === Externals ============================================================ */

/* === Types ================================================================ */

/* === Macros =============================================================== */

/** Default value of current channel in TAL. */
#define CURRENT_CHANNEL_DEF                 (0x0B)

/** Default value of transmit power of transceiver. */
#define TRANSMIT_POWER_DEF                  (0x00)

/** Default value of CCA mode. */
#define CCA_MODE_DEF                        (CCA_MODE1)

/** Default value of PAN Coordiantor custom TAL PIB. */
#define PAN_COORDINATOR_DEF                 (false)

/** Default value of ack wait duration. */
#define ACK_WAIT_DURATION_DEF               (0x36)

/** Default value of BatteryLifeExtension. */
#define BATTERY_LIFE_EXTENSION_DEF          (false)

/** Default value beacon order set to 15. */
#define BEACON_ORDER_DEF                    (0x0F)

/** Default value of BeaconTxTime. */
#define BEACON_TX_TIME_DEF                  (0x00000000)

/** Default value of maximum csma ca backoffs. */
#define MAX_CSMA_BACKOFFS_DEF               (0x04)

/** Default value of backoff exponent used while performing csma ca. */
#define MINBE_DEF                           (0x03)

/** Value of a broadcast PAN ID. */
#define PANID_DEF                           (0xFFFF)

/** Default value of short address. */
#define SHORT_ADDR_DEF                      (0xFFFF)

/** Default value supeframe order set to 15. */
#define SUPERFRAME_ORDER_DEF                (0x0F)

#ifdef SPECIAL_PEER

/** Default value of Disable Ack attribute. */
#define PRIVATE_DISABLE_ACK_DEF             (0x00)

/** Default value of CCA FAILURE scenario. */
#define PRIVATE_CCA_FAILURE_DEF             (0x00)

#endif /* SPECIAL_PEER */

/* === Prototypes =========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* TAL_CONSTANTS_H */

/* EOF */
