/**
 * @file tal_tx.c
 *
 * @brief This module handles  frame creation, frame transmission and
 *        frame retries.
 *
 * $Id: tal_tx.c 11791 2008-11-04 17:49:11Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================= */

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "platform_types.h"
#include "return_val.h"
#include "bmm.h"
#include "qmm.h"
#include "tal.h"
#include "ieee_const.h"
#include "tal_pib.h"
#include "tal_irq_handler.h"
#include "tal_csma_ca.h"
#include "tal_internal.h"
#include "tal_constants.h"
#include "pal.h"
#include "tal_rf230a.h"
#include "phy230_registermap.h"
#include "tal_tx.h"
#ifndef RFD
#include "ffd_data_structures.h"
#endif  /* FFD */
#include "stack_config.h"
#include "tal_rx.h"

/* === Macros =============================================================== */

/** Mask used to check if the frame is a Data frame. */
#define DATA_FRAME                  (0x0001)

/** Mask used to check if the frame control has a Source address. */
#define SRC_ADDR_MASK               (0x0800)

/** Mask used to check if the frame control has a destination address. */
#define DEST_ADDR_MASK              (0x8000)

/** Command Frame Identifier for Association Request. */
#define ASSOC_REQ_ID                (0x01)

/* === Globals ============================================================== */

/*
 * Holds the sequence number of the frame that is being transmitted.
 */
static uint8_t expected_seq_num;

#ifndef RFD
#ifndef NOBEACON
/*
 * Holds the pointer to the beacon frame to be sent on invoking tal_tx_beacon()
 * by MAC.
 */
static uint8_t *beacon_frame;
#endif
#endif

/*
 * TAL transmission sub-state. The default transmission sub-state is
 * TAL_TX_IDLE.
 */
static uint8_t tx_sub_state = TAL_TX_IDLE;

/*
 * Holds the status of frame transmission.
 */
static retval_t tx_result;

/*
 * Keeps track of the retries performed for an issued frame
 */
static uint8_t number_of_retries;

/*
 * Set to true on expiry of ackWaitDuration timer and false otherwise
 */
static volatile bool ack_timer_expired;

/*
 * Specifies whether to perform frame retries on not
 * receiving an acknowledgement.
 */
static bool frame_retry;

/*
 * This init_nb Is set to true when csma ca is called initially and set to
 * false when csma-ca is called for a retried frames
 */
static uint8_t init_nb;

/*
 * Holds the frame pointer, received from MAC.
 */
static frame_info_t *frame_ptr;

/* === Prototypes =========================================================== */

static void ack_timer_expiry_handler_cb(void *callback_parameter);
static uint8_t *frame_create(frame_info_t *tal_frame_info);
static bool send_frame(uint8_t *frame_tx);
static void recover_failed_tx(void);

/* === Implementation ======================================================= */

/**
 * @brief Request to TAL to transmit frame
 *
 * This function is called by MAC to deliver a frame to the TAL
 * to be transmitted by the transceiver.
 *
 * @param mac_frame_info Pointer to the frame_info_t structure updated by
 * MAC layer
 * @param perform_csma_ca Indicates whether csma_ca is to be performed for
 * this frame
 * @param perform_frame_retry Indicates whether to retries are to be performed
 * for this frame
 *
 * @return SUCCESS if TAL has accepted the data from MAC for frame
 * transmission and BUSY if TAL is busy servicing the previous MAC request
 */
retval_t tal_tx_frame(frame_info_t *mac_frame_info, bool perform_csma_ca,
                     bool perform_frame_retry)
{
    if (TAL_IDLE != tal_state)
    {
#if (DEBUG > 1)
        switch (tal_state)
        {
            case TAL_TX_FRAME:
                  ASSERT("TAL state is TAL_TX_FRAME" == 0);
                  break;
#ifndef RFD
#ifndef NOBEACON
            case TAL_TX_BEACON:
                  ASSERT("TAL state is TAL_TX_BEACON" == 0);
                  break;
#endif
#endif
            case TAL_SLEEP:
                  ASSERT("TAL state is TAL_SLEEP" == 0);
                  break;
            default:
                  ASSERT("TAL state is unknown state" == 0);
        }
#endif
        return (BUSY);
    }

    frame_ptr = mac_frame_info;
    /* Proceed with the frame creation and transmission */
    tal_state = TAL_TX_FRAME;

    tx_result = SUCCESS;

    number_of_retries = 0;
    frame_retry = perform_frame_retry;
    tal_ack_expected = false;
    tal_unslotted_csma_required = false;

    /* Create the frame to be sent to the transceiver */
    tal_frame_to_tx = frame_create(mac_frame_info);

    /* Check if CSMA-CA is to be performed for the frame */
    if (perform_csma_ca)
    {
        if (MAC_CMD_FRAME == (mac_frame_info->frame_ctrl & FRAME_TYPE_MASK))
        {
            if (ASSOC_REQ_ID == mac_frame_info->payload[0])
            {
                tal_unslotted_csma_required = true;
            }
            else
            {
                tal_unslotted_csma_required = false;
            }
        }
        tx_sub_state = TAL_CSMA_CA;
        init_nb = true;
    }
    else
    {
        /* The frame is to be sent directly without performing csma_ca. */
        tx_sub_state = TAL_SEND_FRAME;
    }
    return (SUCCESS);
}


/**
 * @brief Implement TAL state machine.
 *
 * This function implements the TAL state machine that performs frame creation,
 * frame transmission and frame retry.
 */
void tx_state_handling(void)
{
    switch (tx_sub_state)
    {
         case TAL_CSMA_CA:
            {
                uint8_t csma_status;

                /*
                 * Function csma_ca() returns CSMA_CA_IN_PROGRESS for the
                 * duration of the CSMA-CA procedure. On completion of CSMA-CA
                 * this function returns either SUCCESS, if CSMA-CA found the
                 * channel to be idle, or CHANNEL_ACCESS_FAILURE if the channel
                 * is busy.
                 */
                csma_status = csma_ca_state_handling(init_nb);

                if (SUCCESS == csma_status)
                {
                    tx_sub_state = TAL_SEND_FRAME;
                }
                else if (CHANNEL_ACCESS_FAILURE == csma_status)
                {
                    tx_result = CHANNEL_ACCESS_FAILURE;
                    tx_sub_state = TAL_TX_CONF;
                }
                else
                {
                    /* Note: csma_status is CSMA_CA_IN_PROGRESS, do nothing */
                }
            }
            break;

        case TAL_SEND_FRAME:
            {
                bool send_frame_status;
                tal_tx_completed = false;

                /* Send the created frame over to the transceiver */
                send_frame_status = send_frame(tal_frame_to_tx);

                if (send_frame_status)
                {
                    /*
                     * Wait for the frame transmission to be completed before
                     * proceeding further
                     */
                    tx_sub_state = TAL_WAIT_FOR_TX_COMPLETE;
                }
                else
                {
                    tx_result = CHANNEL_ACCESS_FAILURE;
                    tx_sub_state = TAL_TX_CONF;
                }
            }
            break;

        case TAL_WAIT_FOR_TX_COMPLETE:
            /* Wait till the frame is completely sent by the transceiver */
            if (tal_tx_completed)
            {
                uint8_t ack_is_requested;

                /* Reset the flag indicating the frame transmission */
                tal_tx_completed = false;

                ack_is_requested = *(tal_frame_to_tx + FCF_OFFSET) & ACK_MASK;

                /* Check if acknowledgement is requested */
                if (ack_is_requested > 0)
                {
                    retval_t timer_status;

                    timer_status = pal_timer_start(ACK_WAIT_TIMER, \
                                    TAL_CONVERT_SYMBOLS_TO_US(ACK_WAIT_DURATION_DEF), \
                                    TIMEOUT_RELATIVE, \
                                    (void *)ack_timer_expiry_handler_cb, \
                                    NULL);

                    if (SUCCESS == timer_status)
                    {
                        /* Make sure that receiver is switched on */
                        while (PHY_RX_ON != set_trx_state(PHY_RX_ON));

                        /*
                         * Set flag to indicate that Acknowledgement
                         * is requested
                         */
                        tal_ack_expected = true;
                        tx_sub_state = TAL_ACK_WAIT;
                    }
                    else
                    {
                        /*
                         * Acknowledgement timer could not be started hence
                         * abort the frame transmission operation.
                         */
                        tx_result = NO_ACK;
                        tx_sub_state = TAL_TX_CONF;
                    }
                }
                else
                {
                    /*
                     * Only if the receive buffer is available, the receiver is
                     * switched on.
                     */
                    if (tal_rx_buf_available)
                    {
                        while (PHY_RX_ON != set_trx_state(PHY_RX_ON));
                    }

                    /* Acknowledgement is not Requested */
                    tx_sub_state = TAL_TX_CONF;
                }
            }
            break;

        case TAL_ACK_WAIT:
            if (ACK & tal_ack_status)
            {
                /*
                 * If an Acknowledgement frame is received, verify the sequence
                 * number. Only if the received frame sequence number matches
                 * with the expected sequence number, the acknowledgement is
                 * considered as received for the currently transmitted frame.
                 */
                if (tal_received_ack_dsn == expected_seq_num)
                {
                    /* Check if Ack received indicates a pending data */
                    if (FRAME_PENDING & tal_ack_status)
                    {
                        tx_result = TAL_FRAME_PENDING;
                    }
                    else
                    {
                        tx_result = SUCCESS;
                    }

                    pal_timer_stop(ACK_WAIT_TIMER);
#if (DEBUG > 1)
                    if (pal_is_timer_running(ACK_WAIT_TIMER))
                    {
                        ASSERT("Ack tmr running" == 0);
                    }
#endif
                    /*
                     * If the receive buffer is available, the state of the
                     * transceiver is not changed. Else the receiver is
                     * switched off.
                     */
                    if (!tal_rx_buf_available)
                    {
                        while (PHY_TRX_OFF != set_trx_state(PHY_TRX_OFF));
                    }

                    tx_sub_state = TAL_TX_CONF;
                }

                /* Reset tal_ack_status */
                tal_ack_status = 0;
                break;
            }
            /* Check if the ack wait timer has expired */
            if (ack_timer_expired)
            {
                /*
                 * Acknowledgement has not been received.
                 * Check if the retry is to be performed on this frame.
                 */
                if (frame_retry)
                {
                    /* Perform frame retry */
                    tx_sub_state = TAL_FRAME_RETRY;
                }
                else
                {
                    /*
                     * Do not perform frame retry. The frame transmitted is
                     * an indirect frame. Prepare to send a confirmation of
                     * NO_ACK to MAC.
                     */
                    tx_result = NO_ACK;

                    /*
                     * If the receive buffer is available, the state of the
                     * transceiver is not changed. Else the receiver is
                     * switched off.
                     */
                    if (!tal_rx_buf_available)
                    {
                        while (PHY_TRX_OFF != set_trx_state(PHY_TRX_OFF));
                    }

                    tx_sub_state = TAL_TX_CONF;
                }

                /* Initialize ack_timer_expired to its default value */
                ack_timer_expired = false;
            }
            break;

        case TAL_FRAME_RETRY:
            if (number_of_retries < aMaxFrameRetries)
            {
                /* Initiate frame retry */
                tx_sub_state = TAL_CSMA_CA;
                init_nb = false;
                number_of_retries++;
            }
            else
            {
                tx_result = NO_ACK;
                tx_sub_state = TAL_TX_CONF;
            }
            break;

        case TAL_TX_CONF:
            {
                retval_t status;

                /* Initialize TAL states */
                tal_state = TAL_IDLE;
                tx_sub_state = TAL_TX_IDLE;

                /*
                 * Store the transmission results into a temporary variable as
                 * tx_result will be overwritten with the beacon
                 * transmission status information in a beacon enabled network.
                 */
                status = tx_result;

                /*
                 * Invoke the callback to report the result of frame
                 * transmission.
                 */
                tal_tx_frame_done_cb(status, frame_ptr);

                /*
                 * Transmission is complete hence initialize tal_ack_expected,
                 * ack_timer_expired tx_result and init_nb to their default
                 * values.
                 */
                tal_ack_expected = false;
                ack_timer_expired = false;
                init_nb = true;
                tx_result = SUCCESS;
            }
            break;

        default:
#if (DEBUG > 0)
            ASSERT("Unexpected state" == 0);
#endif
            break;
    }
} /* tx_state_handling() */



#ifndef RFD
#ifndef NOBEACON
/**
 * @brief Triggers transmission of beacon frame
 *
 * This function is called by MAC to trigger beacon transmission.
 */
void tal_tx_beacon(void)
{
    bool send_frame_status;

    if (TAL_TX_BEACON == tal_state)
    {
        return;
    }

    tal_tx_completed = false;

    /* Send the precreated beacon frame to the transceiver */
    send_frame_status = send_frame(beacon_frame);

    if (send_frame_status)
    {
        /* Backup the current state */
        tal_previous_state = tal_state;

        tal_state = TAL_TX_BEACON;
    }
    else
    {
        /*
         * The Beacon transmission failed, hence force the transmission flag to
         * true so that the state machine will move ahead.
         */
        tal_tx_completed = true;
    }
}
#endif  /* FFD */
#endif  /* BEACON */



#ifndef RFD
#ifndef NOBEACON
/**
 * @brief Checks for Beacon transmission
 *
 * This function check for the beacon frame transmission and invokes the
 * callback.
 *
 * @return true if the beacon frame transmission is complete and false
 * otherwise.
 */
bool beacon_tx_handling(void)
{
    /*
     * Check if the beacon frame is completely sent by the
     * transceiver.
     */
    if (tal_tx_completed)
    {
        /* Reset the tx_complete flag */
        tal_tx_completed = false;

        /*
         * After the beacon is transmitted, the receiver has to be
         * switched ON as it is the start of the Super frame.
         * Only if the receive buffer is available, the receiver is
         * switched on.
         */
        if (tal_rx_buf_available)
        {
            while (PHY_RX_ON != set_trx_state(PHY_RX_ON));
        }

        return (true);
    }
    return (false);
}
#endif  /* FFD */
#endif  /* BEACON */



/*
 * @brief Create MAC frame.
 *
 * This function is called to create a MAC frame using the information
 * passed to tal_tx_frame().
 *
 * @param tal_frame_info Pointer to the frame_info_t structure updated by
 * MAC layer.
 *
 * @return pointer to the created frame header.
 */
static uint8_t *frame_create(frame_info_t *tal_frame_info)
{
    uint8_t frame_length;
    uint16_t address_mode_info;
    uint8_t *frame_header;

    /*
     * Start creating the frame header backwards starting from payload.
     * Note: This approach does not require copying the payload again
     * into the frame buffer.
     */
    frame_header = tal_frame_info->payload;

    /* Start with the frame length set to the payload length */
    frame_length = tal_frame_info->payload_length;

    /* Get the source addressing information */
    address_mode_info = tal_frame_info->frame_ctrl & SRC_ADDR_MODE_MASK;

    /*
     * As the frame creation is done backwards the Source address field
     * of the frame header is updated with the source address
     */
    if (SRC_EXT_ADDR_MODE == address_mode_info)
    {
        frame_header -= EXT_ADDR_LEN;

        convert_64_bit_to_byte_array(tal_frame_info->src_address, \
                                     frame_header);

        frame_length += EXT_ADDR_LEN;
    }
    else if (SRC_SHORT_ADDR_MODE == address_mode_info)
    {
        frame_header -= SHORT_ADDR_LEN;

        convert_16_bit_to_byte_array(tal_frame_info->src_address, \
                                     frame_header);

        frame_length += SHORT_ADDR_LEN;
    }

    /* Check if the frame to be created is a data frame */
    if (DATA_FRAME == (tal_frame_info->frame_ctrl & FRAME_TYPE_MASK))
    {
        if (tal_frame_info->frame_ctrl & INTRA_PAN_SUBFIELD)
        {
            /*
             * Check for source address and destination address.If the
             * intra-PAN bit is set to 1 and both the destination and
             * source addresses are present then do not include the
             * source PAN ID.
             */
            if ((tal_frame_info->frame_ctrl & SRC_ADDR_MASK) &&
                (tal_frame_info->frame_ctrl & DEST_ADDR_MASK))
            {
              /* Do not add source PAN ID */
            }
            else
            {
                /* Add the source PAN ID */
                frame_header -= PAN_ID_LEN;

                convert_16_bit_to_byte_array(tal_frame_info->src_panid, \
                                             frame_header);

                frame_length += PAN_ID_LEN;
            }
        }
        else
        {   /*
             * Source PAN ID shall be included in the MAC frame only if the
             * source addressing mode and intra-PAN subfields of the frame
             * control field are nonzero and equal to zero, respectively.
             */
            if (tal_frame_info->frame_ctrl & SRC_ADDR_MODE_MASK)
            {
                frame_header -= PAN_ID_LEN;

                convert_16_bit_to_byte_array(tal_frame_info->src_panid, \
                                             frame_header);

                frame_length += PAN_ID_LEN;
            }
            else
            {
                /* Do not add source PAN ID */
            }
        }
    }
    else
    {
        /*
         * Frame to be created is a Beacon frame or a MAC command frame include
         * source PAN ID only if the source adress is present.
         */
        if (tal_frame_info->frame_ctrl & SRC_ADDR_MODE_MASK)
        {
            frame_header -= PAN_ID_LEN;

            convert_16_bit_to_byte_array(tal_frame_info->src_panid, \
                                         frame_header);

            frame_length += PAN_ID_LEN;
        }
    }

    address_mode_info = tal_frame_info->frame_ctrl & DEST_ADDR_MODE_MASK;

    /*
     * Destination Address shall be included in the MAC frame only if the
     * destination addressing mode subfield of the frame control field is
     * nonzero.
     */
    if (DEST_EXT_ADDR_MODE == address_mode_info)
    {
        frame_header -= EXT_ADDR_LEN;

        convert_64_bit_to_byte_array(tal_frame_info->dest_address, \
                                     frame_header);

        frame_length += EXT_ADDR_LEN;
    }
    else if (DEST_SHORT_ADDR_MODE == address_mode_info)
    {
        frame_header -= SHORT_ADDR_LEN;

        convert_16_bit_to_byte_array(tal_frame_info->dest_address, \
                                     frame_header);

        frame_length += SHORT_ADDR_LEN;
    }

    if (BEACON_FRAME != (tal_frame_info->frame_ctrl & FRAME_TYPE_MASK))
    {
        /*
         * Destination PAN ID shall be included in the MAC frame only if the
         * destination addressing mode subfield of the frame control field is
         * nonzero.
         */
        if (tal_frame_info->frame_ctrl & DEST_ADDR_MODE_MASK)
        {
            frame_header -= PAN_ID_LEN;

            convert_16_bit_to_byte_array(tal_frame_info->dest_panid, \
                                         frame_header);

            frame_length += PAN_ID_LEN;
        }
    }

    /*
     * As the frame header creation is backwards and the next field to be
     * updated is the sequence number, update the sequence number into the
     * frame header by decrement frame_header by one.
     */
    frame_header--;

    *frame_header = tal_frame_info->seq_num;

    /*
     * Update the expected sequence number only for frames that
     * require acknowledgement
     */
    if (tal_frame_info->frame_ctrl & FCF_ACK_REQ)
    {
        /*
         * Update the expected sequence number as it will be used by the frame
         * transmission unit to verify if the acknowledgement received is for
         * the transmitted frame.
         */
        expected_seq_num  = tal_frame_info->seq_num;
    }

    /*
     * Frame length is incremented to included the length of the sequence
     * number
     */
    frame_length++;

    /*
     * Next field to be updated is the frame control field of the frame header
     */
    frame_header -= FCF_LEN;

    convert_16_bit_to_byte_array(tal_frame_info->frame_ctrl, \
                                 frame_header);

    /* Include space for FCS and FCF field */
    frame_length += FCF_LEN + FCS_LEN;

    /*
     * PHY header contains the length of the frame to be transmitted
     * This is appended to the created frame.
     */
    frame_header--;

    *frame_header = frame_length;

    return (frame_header);
 }/* frame_create() */


/*
 * @brief Sends frame to transceiver
 *
 * This function is called by TAL to turn on the transmitter
 * and transmit the frame. If the transceiver does not go into BUSY_TX
 * state after writing the bytes to the transceiver buffer, then this
 * is considered as the temporary transmission failure and a recovery
 * mechanism is carried to retry the transmission. If even after the maximum
 * transmission retries the transceiver does not go in BUSY_TX state, the
 * state of the transceiver is changed, based on the reception buffer
 * availability and the previous state of the transceiver.
 *
 * @param frame_tx Pointer to the frame to be transmitted
 *
 * @return true if the transceiver goes into BUSY_TX state, indicating
 * that the transceiver is busy in transmitting the bytes, false
 * otherwise.
 */
static bool send_frame(uint8_t *frame_tx)
{
    uint8_t trx_state;
    bool tx_done = false;
    uint8_t tx_retry;

    /* Make sure that transmitter is switched on */
    while (PHY_TX_ON != set_trx_state(PHY_TX_ON));

    /*
     * TX fails if phy does not immediately change PHY state to TX_BUSY.
     * In this case a recovery sequence is performed and TX is rtired.
     */
    for (tx_retry = 0; tx_retry < MAX_TX_RETRY; tx_retry++)
    {
        ENTER_CRITICAL_REGION();

        pal_gpio_set(SLP_TR_PIN, HIGH);
        pal_gpio_set(SLP_TR_PIN, LOW);

        /*
         * Send the frame to the transceiver. The first byte of the frame is
         * is the frame length.
         */
        pal_trx_frame_write(frame_tx, *frame_tx);

        LEAVE_CRITICAL_REGION();

        trx_state = pal_trx_reg_read(RG_TRX_STATUS);

        if (PHY_BUSY_TX != trx_state)
        {
#if (DEBUG > 1)
            /*
             * Start of TX failed, call subroutine to recover from this to
             * retry transmission.
             */
            ASSERT("TX failed, going for recovery" == 0);
#endif
            recover_failed_tx();
        }
        else
        {
            tx_done = true;
            break;
        }
    }

    if (!tx_done)
    {
#if (DEBUG > 0)
        ASSERT("TX Recovery Fail" == 0);
#endif
        if ((tal_rx_buf_available) && (tal_rx_on))
        {
            /*
             * The frame transmission has failed, the receiver is switched on
             * as buffer for reception is available and the previous state
             * of the transceiver was RX_ON.
             */
            while (PHY_RX_ON != set_trx_state(PHY_RX_ON));
        }
        else
        {
            /*
             * Either the buffer for reception is unavailable or the previous
             * state of the transceiver was TRX_OFF, hence the transceiver is
             * put to TRX_OFF state.
             */
            while (PHY_TRX_OFF != set_trx_state(PHY_TRX_OFF));
        }
    }

    return tx_done;
}


/*
 * @brief Procedure to recover from transmission failure
 *
 * This function follows a procedure by which a transmission
 * failure is recovered.
 */
static void recover_failed_tx(void)
{
    uint8_t trx_state;

    /* The receiver is switched on for a moment */
    pal_trx_reg_write(RG_TRX_STATE, RX_ON);

    pal_timer_delay(PLL_BUSY_TX_RX_ON_TIMEOUT);

    trx_state = pal_trx_reg_read(RG_TRX_STATUS);

#if (DEBUG > 1)
    if (RX_ON != trx_state)
    {
        ASSERT("TRX failed to do RX_ON" == 0);
    }
#endif

    /* Switch back PLL_ON to continue TX */
    pal_trx_reg_write(RG_TRX_STATE, PLL_ON);

    do
    {
        trx_state = pal_trx_reg_read(RG_TRX_STATUS);
    } while (PLL_ON != trx_state);
}


/*
 * @brief Indicates the expiry of ackWaitDuration timer
 *
 * This function sets a flag to indicate expiry of ackWaitDuration timer.
 *
 * @param callback_parameter Callback parameter.
 */
static void ack_timer_expiry_handler_cb(void *callback_parameter)
{
    /*
     * Indicate acknowledgement has not been received for the transmitted
     * frame.
     */
    ack_timer_expired = true;

    /* Reset ack expected flag */
    tal_ack_expected = false;

    callback_parameter = callback_parameter;  /* Keep compiler happy. */
}



#ifndef RFD
#ifndef NOBEACON
/**
 * @brief Prepares the beacon frame to be sent at the start of superframe
 *
 * This function Prepares the beacon frame to be sent at the start of
 * superframe
 *
 * @param mac_frame_info Pointer to the frame_info_t structure prepared by
 * MAC layer
 */
void tal_prepare_beacon(frame_info_t *mac_frame_info)
{
    /*
     * Create beacon frame and buffer the beacon frame to be sent on
     * tal_tx_beacon() function call.
     */
    beacon_frame = frame_create(mac_frame_info);
}
#endif
#endif

/* EOF */
