/**
 * @file tal_tx_frame_done_cb.c
 *
 * @brief This file contains user call back function for
 * tal_tx_frame_done_cb.
 *
 * $Id: tal_tx_frame_done_cb.c 11070 2008-09-17 07:04:25Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================= */

#include <stdint.h>
#include <stdbool.h>
#include "tal.h"

/* === Macros ============================================================== */

/* === Globals ============================================================= */

/* === Prototypes ========================================================== */

/* === Implementation ====================================================== */

void tal_tx_frame_done_cb(retval_t status, frame_info_t *frame)
{
}

/* EOF */
