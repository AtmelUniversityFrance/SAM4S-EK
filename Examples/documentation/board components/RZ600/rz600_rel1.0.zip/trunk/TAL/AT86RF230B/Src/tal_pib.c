/**
 * @file tal_pib.c
 *
 * @brief This file handles the TAL PIB attributes, set/get and initialization
 *
 * $Id: tal_pib.c 12126 2008-11-20 13:00:38Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === INCLUDES ============================================================ */

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "platform_types.h"
#include "return_val.h"
#include "tal.h"
#include "ieee_const.h"
#include "tal_constants.h"
#include "tal_pib.h"
#include "at86rf230b.h"
#include "pal.h"
#include "tal_internal.h"
#ifdef SPECIAL_PEER
#include "private_const.h"
#endif /* SPECIAL_PEER */

/* === TYPES =============================================================== */


/* === MACROS ============================================================== */

/*
 * Translation table converting register values to power levels (dBm).
 */
FLASH_DECLARE(static int8_t tx_pwr_table[16]) =
{
    3, /* 3.2 */
    2, /* 2.6 */
    2, /* 2.1 */
    1, /* 1.6 */
    1, /* 1.1 */
    0, /* 0.5 */
    0, /* -0.2 */
    -1, /* -1.2 */
    -2, /* -2.2 */
    -3, /* -3.2 */
    -4, /* -4.2 */
    -5, /* -5.2 */
    -7, /* -7.2 */
    -9, /* -9.2 */
    -12, /* -12.2 */
    -17, /* -17.2 */
};

/* === GLOBALS ============================================================= */


/* === PROTOTYPES ========================================================== */

static uint8_t limit_tx_pwr(uint8_t tal_pib_TransmitPower);
static uint8_t convert_phyTransmitPower_to_reg_value(uint8_t phyTransmitPower_value);

/* === IMPLEMENTATION ====================================================== */

/**
 * @brief Initialize the TAL PIB
 *
 * This function initializes the TAL information base attributes
 * to their default values.
 */
void init_tal_pib(void)
{
    tal_pib_MaxCSMABackoffs = TAL_MAX_CSMA_BACKOFFS_DEFAULT;
    tal_pib_MinBE = TAL_MINBE_DEFAULT;
    tal_pib_PANId = TAL_PANID_BC_DEFAULT;
    tal_pib_ShortAddress = TAL_SHORT_ADDRESS_DEFAULT;
    tal_pib_CurrentChannel = TAL_CURRENT_CHANNEL_DEFAULT;
    tal_pib_SupportedChannels = TRX_SUPPORTED_CHANNELS;
    tal_pib_TransmitPower = limit_tx_pwr(TAL_TRANSMIT_POWER_DEFAULT);
    tal_pib_CCAMode = TAL_CCA_MODE_DEFAULT;
    tal_pib_BattLifeExt = TAL_BATTERY_LIFE_EXTENSION_DEFAULT;
    tal_pib_PrivatePanCoordinator = TAL_PAN_COORDINATOR_DEFAULT;
    tal_pib_PrivateAssociated = TAL_PRIVATE_ASSOCIATED_DEFAULT;
    tal_pib_BeaconOrder = TAL_BEACON_ORDER_DEFAULT;
    tal_pib_SuperFrameOrder = TAL_SUPERFRAME_ORDER_DEFAULT;
    tal_pib_BeaconTxTime = TAL_BEACON_TX_TIME_DEFAULT;
    tal_pib_ACKWaitDuration = macAckWaitDuration_def;

    tal_pib_PrivateAssociated = false;

#ifdef SPECIAL_PEER
    tal_pib_PrivateCCAFailure = TAL_PRIVATE_CCA_FAILURE_DEFAULT;
    tal_pib_PrivateDisableACK = TAL_PRIVATE_DISABLE_ACK_DEFAULT;
#endif /* SPECIAL_PEER */
}


/**
 * @brief Write all shadow PIB variables to the transcei er
 *
 * This function writes all shadow PIB variables to the transceiver.
 * It is assumed that the radio does not sleep.
 */
void write_all_tal_pib_to_trx(void)
{
    /* configure RX_AACK */
    pal_trx_reg_write(RG_PAN_ID_0, (uint8_t)tal_pib_PANId);
    pal_trx_reg_write(RG_PAN_ID_1, (uint8_t)(tal_pib_PANId >> 8));
    pal_trx_reg_write(RG_IEEE_ADDR_0, (uint8_t)tal_pib_IeeeAddress);
    pal_trx_reg_write(RG_IEEE_ADDR_1, (uint8_t)(tal_pib_IeeeAddress >> 8));
    pal_trx_reg_write(RG_IEEE_ADDR_2, (uint8_t)(tal_pib_IeeeAddress >> 16));
    pal_trx_reg_write(RG_IEEE_ADDR_3, (uint8_t)(tal_pib_IeeeAddress >> 24));
    pal_trx_reg_write(RG_IEEE_ADDR_4, (uint8_t)(tal_pib_IeeeAddress >> 32));
    pal_trx_reg_write(RG_IEEE_ADDR_5, (uint8_t)(tal_pib_IeeeAddress >> 40));
    pal_trx_reg_write(RG_IEEE_ADDR_6, (uint8_t)(tal_pib_IeeeAddress >> 48));
    pal_trx_reg_write(RG_IEEE_ADDR_7, (uint8_t)(tal_pib_IeeeAddress >> 56));
    pal_trx_reg_write(RG_SHORT_ADDR_0, (uint8_t)tal_pib_ShortAddress);
    pal_trx_reg_write(RG_SHORT_ADDR_1, (uint8_t)(tal_pib_ShortAddress >> 8));

    /* configure TX_ARET; CSMA and CCA */
    {
        uint8_t reg_value;

        reg_value = convert_phyTransmitPower_to_reg_value(tal_pib_TransmitPower);
        pal_trx_bit_write(SR_TX_PWR, reg_value);
    }
    pal_trx_bit_write(SR_CCA_MODE, tal_pib_CCAMode);
    pal_trx_bit_write(SR_CHANNEL, tal_pib_CurrentChannel);
    pal_trx_bit_write(SR_MIN_BE, tal_pib_MinBE);

    pal_trx_bit_write(SR_I_AM_COORD, tal_pib_PrivatePanCoordinator);
}


/**
 * @brief Gets a TAL PIB attribute
 *
 * This function is called to retrieve the transceiver information base
 * attributes.
 *
 * @param[in] attribute TAL infobase attribute ID
 * @param[out] value TAL infobase attribute value
 *
 * @return UNSUPPORTED_ATTRIBUTE if the TAL infobase attribute is not found
 *         SUCCESS otherwise
 */
#if (HIGHEST_STACK_LAYER != MAC)
retval_t tal_pib_get(uint8_t attribute, void *value)
{
    switch (attribute)
    {
        case macMaxCSMABackoffs:
            *(uint8_t *)value = tal_pib_MaxCSMABackoffs;
            break;

        case macMinBE:
            *(uint8_t *)value = tal_pib_MinBE;
            break;

        case macPANId:
            *(uint16_t *)value = tal_pib_PANId;
            break;

        case macShortAddress:
            *(uint16_t *)value = tal_pib_ShortAddress;
            break;

        case phyCurrentChannel:
            *(uint8_t *)value = tal_pib_CurrentChannel;
            break;

        case phyChannelsSupported:
            *(uint32_t *)value = tal_pib_SupportedChannels;
            break;

        case phyTransmitPower:
            *(uint8_t *)value = tal_pib_TransmitPower;
            break;

        case phyCCAMode:
            *(uint8_t *)value = tal_pib_CCAMode;
            break;

        case macIeeeAddress:
            *(uint64_t *)value = tal_pib_IeeeAddress;
            break;
#ifdef SPECIAL_PEER
        case macPrivateCCAFailure:
            *(uint8_t *)value = tal_pib_PrivateCCAFailure;
            break;

        case macPrivateDisableACK:
            *(uint8_t *)value = tal_pib_PrivateDisableACK;
            return UNSUPPORTED_ATTRIBUTE;
            break;
#endif
        case macBattLifeExt:
            *(bool *)value = tal_pib_BattLifeExt;
            break;

        case macBeaconOrder:
            *(uint8_t *)value = tal_pib_BeaconOrder;
            break;

        case macSuperframeOrder:
            *(uint8_t *)value = tal_pib_SuperFrameOrder;
            break;

        case macBeaconTxTime:
            *(uint32_t *)value = tal_pib_BeaconTxTime;
            break;

        case mac_i_pan_coordinator:
            *(bool *)value = tal_pib_PrivatePanCoordinator;
            break;

        case macPrivateAssociated:
            *(bool *)value = tal_pib_PrivateAssociated;
            break;

        case macAckWaitDuration:
            /* Rev.B does not support changing this value */
            return UNSUPPORTED_ATTRIBUTE;

        default:
            /* Invalid attribute id */
            ASSERT("unsupported attribute" == 0);
            return UNSUPPORTED_ATTRIBUTE;
    }

    return SUCCESS;
} /* tal_pib_get() */
#endif  /* (HIGHEST_STACK_LAYER != MAC) */


/**
 * @brief Sets a TAL PIB attribute
 *
 * This function is called to set the transceiver information base
 * attributes.
 *
 * @param attribute TAL infobase attribute ID
 * @param value TAL infobase attribute value to be set
 *
 * @return UNSUPPORTED_ATTRIBUTE if the TAL info base attribute is not found
 *         BUSY if the TAL is not in TAL_IDLE state. An exception is
 *         macBeaconTxTime which can be accepted by TAL even if TAL is not
 *         in TAL_IDLE state.
 *         SUCCESS if the attempt to set the PIB attribute was successful
 *         TRX_ASLEEP if trx is in SLEEP mode and access to trx is required
 */
retval_t tal_pib_set(uint8_t attribute, void *value)
{
    /*
     * Do not allow any changes while ED or TX is done.
     * We allow changes during RX, but it's on the user's own risk.
     */
#ifndef RFD
    if (tal_state == TAL_ED)
    {
        ASSERT("TAL is busy" == 0);
        return BUSY;
    }
#endif

    /*
     * Distinguish between PIBs that need to be changed in trx directly
     * and those that are simple variable udpates.
     * Ensure that the transceiver is not in SLEEP.
     * If it is in SLEEP, change it to TRX_OFF.
     * For all other state force TRX_OFF.
     * Abort any BUSY state, because the change might have an impact to
     * ongoing transactions.
     */

    switch (attribute)
    {
        case macBattLifeExt:
            tal_pib_BattLifeExt = *((bool *)value);
            break;

        case macBeaconOrder:
            tal_pib_BeaconOrder = *((uint8_t *)value);
            break;

        case macSuperframeOrder:
            tal_pib_SuperFrameOrder = *((uint8_t *)value);
            break;

        case macBeaconTxTime:
            tal_pib_BeaconTxTime = *((uint32_t *)value);
            break;

#ifdef SPECIAL_PEER
        case macPrivateCCAFailure:
            tal_pib_PrivateCCAFailure = *((uint8_t *)value);
            break;
#endif

        case macPrivateAssociated:
            tal_pib_PrivateAssociated = *((bool *)value);
            break;

        default:
            /*
             * Following PIBs require access to trx.
             * Therefore trx must be at least in TRX_OFF.
             */

            if (tal_trx_status == TRX_SLEEP)
            {
                /* While trx is in SLEEP, register cannot be accessed. */
                return TRX_ASLEEP;
            }

            switch (attribute)
            {
                case macMaxCSMABackoffs:
                    tal_pib_MaxCSMABackoffs = *((uint8_t *)value);
                    pal_trx_bit_write(SR_MAX_CSMA_RETRIES, tal_pib_MaxCSMABackoffs);
                    break;

                case macMinBE:
                    tal_pib_MinBE = *((uint8_t *)value);
                    pal_trx_bit_write(SR_MIN_BE, tal_pib_MinBE);
                    break;

                case macPANId:
                    tal_pib_PANId = *((uint16_t *)value);
#if (PAL_GENERIC_TYPE==AVR32)
                    pal_trx_reg_write(RG_PAN_ID_1, (uint8_t)tal_pib_PANId);
                    pal_trx_reg_write(RG_PAN_ID_0, (uint8_t)(tal_pib_PANId >> 8));
#else
                    pal_trx_reg_write(RG_PAN_ID_0, (uint8_t)tal_pib_PANId);
                    pal_trx_reg_write(RG_PAN_ID_1, (uint8_t)(tal_pib_PANId >> 8));
#endif
                    break;

                case macShortAddress:
                    tal_pib_ShortAddress = *((uint16_t *)value);
#if (PAL_GENERIC_TYPE==AVR32)
                    pal_trx_reg_write(RG_SHORT_ADDR_1, (uint8_t)tal_pib_ShortAddress);
                    pal_trx_reg_write(RG_SHORT_ADDR_0, (uint8_t)(tal_pib_ShortAddress >> 8));
#else
                    pal_trx_reg_write(RG_SHORT_ADDR_0, (uint8_t)tal_pib_ShortAddress);
                    pal_trx_reg_write(RG_SHORT_ADDR_1, (uint8_t)(tal_pib_ShortAddress >> 8));
#endif
                    break;

                case phyCurrentChannel:
                    if (tal_state != TAL_IDLE)
                    {
                        return BUSY;
                    }
                    if ((uint32_t)TRX_SUPPORTED_CHANNELS & ((uint32_t)0x01 << *((uint8_t *)value)))
                    {
                        tal_pib_CurrentChannel = *((uint8_t *)value);
                        pal_trx_bit_write(SR_CHANNEL, tal_pib_CurrentChannel);
                    }
                    else
                    {
                        ASSERT("unsupported channel" == 0);
                        return INVALID_PARAMETER;
                    }
                    break;

                case phyTransmitPower:
                    {
                        uint8_t reg_value;

                        tal_pib_TransmitPower = *((uint8_t *)value);

                        /* Limit tal_pib_TransmitPower to max/min trx values */
                        tal_pib_TransmitPower = limit_tx_pwr(tal_pib_TransmitPower);
                        reg_value = convert_phyTransmitPower_to_reg_value(tal_pib_TransmitPower);
                        pal_trx_bit_write(SR_TX_PWR, reg_value);
                    }
                    break;

                case phyCCAMode:
                    tal_pib_CCAMode = *((uint8_t *)value);
                    pal_trx_bit_write(SR_CCA_MODE, tal_pib_CCAMode);
                    break;

                case macIeeeAddress:
                    tal_pib_IeeeAddress = *((uint64_t *)value);
#if (PAL_GENERIC_TYPE==AVR32)
                    pal_trx_reg_write(RG_IEEE_ADDR_7, (uint8_t)tal_pib_IeeeAddress);
                    pal_trx_reg_write(RG_IEEE_ADDR_6, (uint8_t)(tal_pib_IeeeAddress >> 8));
                    pal_trx_reg_write(RG_IEEE_ADDR_5, (uint8_t)(tal_pib_IeeeAddress >> 16));
                    pal_trx_reg_write(RG_IEEE_ADDR_4, (uint8_t)(tal_pib_IeeeAddress >> 24));
                    pal_trx_reg_write(RG_IEEE_ADDR_3, (uint8_t)(tal_pib_IeeeAddress >> 32));
                    pal_trx_reg_write(RG_IEEE_ADDR_2, (uint8_t)(tal_pib_IeeeAddress >> 40));
                    pal_trx_reg_write(RG_IEEE_ADDR_1, (uint8_t)(tal_pib_IeeeAddress >> 48));
                    pal_trx_reg_write(RG_IEEE_ADDR_0, (uint8_t)(tal_pib_IeeeAddress >> 56));
#else
                    pal_trx_reg_write(RG_IEEE_ADDR_0, (uint8_t)tal_pib_IeeeAddress);
                    pal_trx_reg_write(RG_IEEE_ADDR_1, (uint8_t)(tal_pib_IeeeAddress >> 8));
                    pal_trx_reg_write(RG_IEEE_ADDR_2, (uint8_t)(tal_pib_IeeeAddress >> 16));
                    pal_trx_reg_write(RG_IEEE_ADDR_3, (uint8_t)(tal_pib_IeeeAddress >> 24));
                    pal_trx_reg_write(RG_IEEE_ADDR_4, (uint8_t)(tal_pib_IeeeAddress >> 32));
                    pal_trx_reg_write(RG_IEEE_ADDR_5, (uint8_t)(tal_pib_IeeeAddress >> 40));
                    pal_trx_reg_write(RG_IEEE_ADDR_6, (uint8_t)(tal_pib_IeeeAddress >> 48));
                    pal_trx_reg_write(RG_IEEE_ADDR_7, (uint8_t)(tal_pib_IeeeAddress >> 56));
#endif
                    break;

#ifdef SPECIAL_PEER
                case macPrivateDisableACK:
                    tal_pib_PrivateDisableACK = *((uint8_t *)value);
                    // @TODO implement tal_pib_PrivateDisableACK handling for AT86RF230B
                    return UNSUPPORTED_ATTRIBUTE;
#endif

                case mac_i_pan_coordinator:
                    tal_pib_PrivatePanCoordinator = *((bool *)value);
                    pal_trx_bit_write(SR_I_AM_COORD, tal_pib_PrivatePanCoordinator);
                    break;

                case macAckWaitDuration:
                    /* AT86RF230B does not support changing this value */
                    return UNSUPPORTED_ATTRIBUTE;

                default:
                    ASSERT("unsupported attribute" == 0);
                    return UNSUPPORTED_ATTRIBUTE;
            }

            break; /* end of 'default' from 'switch (attribute)' */
    }
    return SUCCESS;
} /* tal_pib_set() */


/**
 * @brief Limit the phyTransmitPower to the trx limits
 *
 * @param phyTransmitPower phyTransmitPower value
 *
 * @return limited tal_pib_TransmitPower
 */
static uint8_t limit_tx_pwr(uint8_t tal_pib_TransmitPower)
{
    uint8_t ret_val = tal_pib_TransmitPower;
    int8_t dbm_value;

    dbm_value = CONV_phyTransmitPower_TO_DBM(tal_pib_TransmitPower);
    if (dbm_value > PGM_READ_BYTE(&tx_pwr_table[0]))
    {
        dbm_value = PGM_READ_BYTE(&tx_pwr_table[0]);
        ret_val = CONV_DBM_TO_phyTransmitPower(dbm_value);

    }
    else if (dbm_value < PGM_READ_BYTE(&tx_pwr_table[sizeof(tx_pwr_table)-1]))
    {
        dbm_value = PGM_READ_BYTE(&tx_pwr_table[sizeof(tx_pwr_table)-1]);
        ret_val = CONV_DBM_TO_phyTransmitPower(dbm_value);
    }

    return (ret_val | TX_PWR_TOLERANCE);
}


/**
 * @brief Converts a phyTransmitPower value to a register value
 *
 * @param phyTransmitPower_value phyTransmitPower value
 *
 * @return register value
 */
static uint8_t convert_phyTransmitPower_to_reg_value(uint8_t phyTransmitPower_value)
{
    int8_t dbm_value;
    uint8_t i;
    int8_t trx_tx_level;

    dbm_value = CONV_phyTransmitPower_TO_DBM(phyTransmitPower_value);

    /* Compare to the register value to identify the value that matches. */
    for (i = 0; i < sizeof(tx_pwr_table); i++)
    {
        trx_tx_level = PGM_READ_BYTE(&tx_pwr_table[i]);
        if (trx_tx_level <= dbm_value)
        {
            if (trx_tx_level < dbm_value)
            {
                return (i - 1);
            }
            return i;
        }
    }

    /* This code should never be reached. */
    return 0;
}


/* EOF */
