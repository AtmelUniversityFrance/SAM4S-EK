/**
 * @file tal_config.h
 *
 * @brief File contains TAL configuration parameters.
 *
 * $Id: tal_config.h 12195 2008-11-24 15:31:34Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef TAL_CONFIG_H
#define TAL_CONFIG_H

/* === INCLUDES ============================================================ */

#include "at86rf230b.h"

/* === EXTERNALS =========================================================== */

/* === MACROS ============================================================== */

#define TAL_RADIO_WAKEUP_TIME_SYM       (TAL_CONVERT_US_TO_SYMBOLS(SLEEP_TO_TRX_OFF_US))
#define TAL_FIRST_TIMER_ID              (0)


/* === TYPES =============================================================== */

/* Timer ID's used by TAL */
// FFD beacon
#if ((!defined RFD) && (!defined NOBEACON))
    typedef enum tal_timer_id_tag
    {
        TAL_ACK_WAIT_TIMER              = (TAL_FIRST_TIMER_ID),
        TAL_ED_SCAN_DURATION_TIMER      = (TAL_FIRST_TIMER_ID + 1),
        TAL_ED_SAMPLE_TIMER             = (TAL_FIRST_TIMER_ID + 2),
        TAL_CSMA_CCA                    = (TAL_FIRST_TIMER_ID + 3),
        TAL_CSMA_BEACON_LOSS_TIMER      = (TAL_FIRST_TIMER_ID + 4)
    } tal_timer_id_t;

    #define NUMBER_OF_TAL_TIMERS        (5)
#endif

// FFD no beacon
#if ((!defined RFD) && (defined NOBEACON))
    typedef enum tal_timer_id_tag
    {
        TAL_ED_SCAN_DURATION_TIMER      = (TAL_FIRST_TIMER_ID),
        TAL_ED_SAMPLE_TIMER             = (TAL_FIRST_TIMER_ID + 1)
    } tal_timer_id_t;

    #define NUMBER_OF_TAL_TIMERS        (2)
#endif

// RFD beacon
#if ((defined RFD) && (!defined NOBEACON))
    typedef enum tal_timer_id_tag
    {
        TAL_ACK_WAIT_TIMER              = (TAL_FIRST_TIMER_ID),
        TAL_CSMA_CCA                    = (TAL_FIRST_TIMER_ID + 1),
        TAL_CSMA_BEACON_LOSS_TIMER      = (TAL_FIRST_TIMER_ID + 2)
    } tal_timer_id_t;

    #define NUMBER_OF_TAL_TIMERS        (3)
#endif

// RFD no beacon
#if ((defined RFD) && (defined NOBEACON))
    #define NUMBER_OF_TAL_TIMERS        (0)
#endif

#if (NUMBER_OF_TAL_TIMERS > 0)
#define TAL_LAST_TIMER_ID    (TAL_FIRST_TIMER_ID + NUMBER_OF_TAL_TIMERS - 1) // -1: timer id starts with 0
#else
#define TAL_LAST_TIMER_ID    (TAL_FIRST_TIMER_ID)
#endif

#define TAL_INCOMING_FRAME_QUEUE_CAPACITY   (5)

/* === PROTOTYPES ========================================================== */


#endif /* TAL_CONFIG_H */
