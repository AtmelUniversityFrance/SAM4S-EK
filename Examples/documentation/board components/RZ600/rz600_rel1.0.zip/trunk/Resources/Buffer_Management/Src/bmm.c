/**
 * @file bmm.c
 *
 * @brief This file implements the functions for initializing buffer module,
 *  allocating and freeing up buffers.
 *
 * $Id: bmm.c 11799 2008-11-05 10:43:16Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */
/* === Includes ============================================================ */

#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include "platform_types.h"
#include "return_val.h"
#include "bmm.h"
#include "qmm.h"
#include "tal.h"
#include "ieee_const.h"
#ifndef RFD
#include "ffd_data_structures.h"
#endif  /* FFD */
#include "app_config.h"

/* === Types =============================================================== */


/* === Macros ============================================================== */


/* === Globals ============================================================= */

/**
 * Common Buffer pool holding the buffer user area
 */
static uint8_t buf_pool[(TOTAL_NUMBER_OF_LARGE_BUFS * LARGE_BUFFER_SIZE) +
                        (TOTAL_NUMBER_OF_SMALL_BUFS * SMALL_BUFFER_SIZE)];
/*
 * Array of buffer headers
 */
static buffer_t buf_header[TOTAL_NUMBER_OF_LARGE_BUFS + TOTAL_NUMBER_OF_SMALL_BUFS];

/*
 * Queue of free large buffers
 */
#if (TOTAL_NUMBER_OF_LARGE_BUFS > 0)
static queue_t free_large_buffer_q;
#endif

/*
 * Queue of free small buffers
 */
#if (TOTAL_NUMBER_OF_SMALL_BUFS > 0)
static queue_t free_small_buffer_q;
#endif

/* === Prototypes ========================================================== */


/* === Implementation ====================================================== */

/**
 * @brief Initializes the buffer module.
 *
 * This function initializes the buffer module.
 * This function should be called before using any other functionality
 * of buffer module.
 *
 * @ingroup bmm
 */
void bmm_buffer_init(void)
{
    uint8_t index;

    /* Initialize free buffer queue for large buffers */
#if (TOTAL_NUMBER_OF_LARGE_BUFS > 0)
    qmm_queue_init(&free_large_buffer_q, TOTAL_NUMBER_OF_LARGE_BUFS);
#endif

    /* Initialize free buffer queue for small buffers */
#if (TOTAL_NUMBER_OF_SMALL_BUFS > 0)
    qmm_queue_init(&free_small_buffer_q, TOTAL_NUMBER_OF_SMALL_BUFS);
#endif

#if (TOTAL_NUMBER_OF_LARGE_BUFS > 0)
    for (index = 0; index < TOTAL_NUMBER_OF_LARGE_BUFS; index++)
    {
        /*
         * Initialize the buffer body pointer with address of the
         * buffer body
         */
        buf_header[index].body = buf_pool + (index * LARGE_BUFFER_SIZE);

        /* Append the buffer to free large buffer queue */
        qmm_queue_append(&free_large_buffer_q, &buf_header[index]);
    }
#endif

#if (TOTAL_NUMBER_OF_SMALL_BUFS > 0)
    for (index = 0; index < TOTAL_NUMBER_OF_SMALL_BUFS; index++)
    {
        /*
         * Initialize the buffer body pointer with address of the
         * buffer body
         */
        buf_header[index + TOTAL_NUMBER_OF_LARGE_BUFS].body = \
            buf_pool + (TOTAL_NUMBER_OF_LARGE_BUFS * LARGE_BUFFER_SIZE) + \
            (index * SMALL_BUFFER_SIZE);

        /* Append the buffer to free small buffer queue */
        qmm_queue_append(&free_small_buffer_q, &buf_header[index + \
            TOTAL_NUMBER_OF_LARGE_BUFS]);
    }
#endif
}


/**
 * @brief Allocates a buffer
 *
 * This function allocates a buffer and returns a pointer to the buffer.
 * The same pointer should be used while freeing the buffer.User should
 * call BMM_BUFFER_POINTER(buf) to get the pointer to buffer user area.
 *
 * @param size size of buffer to be allocated.
 *
 * @return pointer to the buffer allocated,
 *  NULL if buffer not available.
 *
 * @ingroup bmm
 */
buffer_t *bmm_buffer_alloc(uint8_t size)
{
    buffer_t *pfree_buffer = NULL;

#if (TOTAL_NUMBER_OF_SMALL_BUFS > 0)
    /*
     * Allocate buffer only if size requested is less than or equal to  maximum
     * size that can be allocated.
     */
    if (size <= LARGE_BUFFER_SIZE)
    {
        /*
         * Allocate small buffer if size is less than small buffer size and if
         * small buffer is available allocate from small buffer pool.
         */
        if ((size <= SMALL_BUFFER_SIZE))
        {
            /* Allocate buffer from free small buffer queue */
            pfree_buffer = qmm_queue_remove(&free_small_buffer_q, NULL);
        }

        /*
         * If size is greater than small buffer size or no free small buffer is
         * available, allocate a buffer from large buffer pool if avialable
         */
        if (NULL == pfree_buffer)
        {
            /* Allocate buffer from free large buffer queue */
            pfree_buffer = qmm_queue_remove(&free_large_buffer_q, NULL);
        }
    }
#else /* no small buffers available at all */
    /* Allocate buffer from free large buffer queue */
    pfree_buffer = qmm_queue_remove(&free_large_buffer_q, NULL);

    size = size;    /* Keep compiler happy. */
#endif

    return pfree_buffer;
}


/**
 * @brief Frees up a buffer.
 *
 * This function frees up a buffer. The pointer passed to this function
 * should be the pointer returned during buffer allocation. The result is
 * unpredictable if an incorrect pointer is passed.
 *
 * @param pbuffer Pointer to buffer that has to be freed.
 *
 * @ingroup bmm
 */
void bmm_buffer_free(buffer_t *pbuffer)
{
    if (NULL == pbuffer)
    {
        /* If the buffer pointer is NULL abort free operation */
        return;
    }

#if (TOTAL_NUMBER_OF_SMALL_BUFS > 0)
    if (IS_SMALL_BUF(pbuffer))
    {
        /* Append the buffer into free small buffer queue */
        qmm_queue_append(&free_small_buffer_q, pbuffer);
    }
    else
    {
        /* Append the buffer into free large buffer queue */
        qmm_queue_append(&free_large_buffer_q, pbuffer);
    }
#else /* no small buffers available at all */
    /* Append the buffer into free large buffer queue */
    qmm_queue_append(&free_large_buffer_q, pbuffer);
#endif

}


#ifdef SPECIAL_PEER
/**
 * @brief Returns number of free buffers.
 *
 * This function returns the number of free large buffers
 * or number of free small buffers depending on parameter passed.
 *
 * @param buffer_size Type of buffer(Large or Small buffer)
 *
 * @return Number of free buffers
 *
 * @ingroup bmm
 */
uint8_t bmm_get_number_of_free_buffers(uint8_t buffer_size)
{
    uint8_t free_buffers;

#if (TOTAL_NUMBER_OF_SMALL_BUFS > 0)
    if (buffer_size <= SMALL_BUFFER_SIZE)
    {
        free_buffers = free_small_buffer_q.size;
    }
    else
    {
        free_buffers = free_large_buffer_q.size;
    }
#else   /* no small buffers available at all */
    free_buffers = free_small_buffer_q.size;
#endif

    return free_buffers;
}
#endif /* SPECIAL_PEER */

/* EOF */
