/**
 * @file bmm.h
 *
 * @brief This file contains the Buffer Management Module definitions.
 *
 * $Id: bmm.h 11218 2008-10-02 10:12:03Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef BMM_INTERFACE_H
#define BMM_INTERFACE_H

/* === Includes ============================================================ */

/* === Macros ============================================================== */

/**
 * Checks whether the buffer pointer provided is of small buffer or of a large
 * buffer
 */
#define IS_SMALL_BUF(p) ((p)->body >= (buf_pool +  \
        LARGE_BUFFER_SIZE * TOTAL_NUMBER_OF_LARGE_BUFS))

/**
 * This macro gives the body of the buffer header supplied
 */
#define BMM_BUFFER_POINTER(buf) ((buf)->body)

/* === Types =============================================================== */

/**
 * This structure holds the information of each buffer like
 * pointer to buffer and link to next free buffer
 */
typedef struct buffer_tag
{
    uint8_t *body;              /* Pointer to the buffer body */
    struct buffer_tag *next;    /* Pointer to next free buffer */
} buffer_t;
/* === Externals =========================================================== */


/* === Prototypes ========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

void bmm_buffer_init(void);

buffer_t *bmm_buffer_alloc(uint8_t size);

void bmm_buffer_free(buffer_t *pbuffer);

#ifdef SPECIAL_PEER

uint8_t bmm_get_number_of_free_buffers(uint8_t buffer_size);

#endif /* SPECIAL_PEER */

#endif /* BMM_INTERFACE_H */

/* EOF */
