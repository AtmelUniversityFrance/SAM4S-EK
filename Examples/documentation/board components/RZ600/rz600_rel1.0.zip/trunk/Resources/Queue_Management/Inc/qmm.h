/**
 * @file qmm.h
 *
 * @brief This file contains the Queue Management Module definitions.
 *
 * $Id: qmm.h 11218 2008-10-02 10:12:03Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef QMM_INTERFACE_H
#define QMM_INTERFACE_H

/* === Includes ============================================================ */

#include "bmm.h"

/* === Macros ============================================================== */


/* === Types =============================================================== */

/**
 * Used to search for the buffer that is to be removed from the queue
 */
typedef struct search_tag
{
    uint8_t (*criteria_func)(void *buf, void *handle);
    void *handle;
} search_t;

/**
 * Queue structure. The application should declare the queue of type queue_t
 * and call qmm_queue_init before invoking any other functionality of qmm
 */
typedef struct queue_tag
{
    buffer_t *head;
    buffer_t *tail;

    /* Maximum number of buffers that can be accomodated in the current queue */
    uint8_t capacity;

    /* Number of buffers present in the current queue */
    uint8_t size;
} queue_t;

/* === Externals =========================================================== */


/* === Prototypes ========================================================== */

#ifdef __cplusplus
extern "C"
{
#endif

void qmm_queue_init(queue_t *q, uint8_t capacity);

retval_t qmm_queue_append(queue_t *q, buffer_t *buf);

buffer_t *qmm_queue_remove(queue_t *q, search_t *search);

buffer_t *qmm_queue_read(queue_t *q, search_t *search);

void qmm_queue_flush(queue_t *q);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* QMM_INTERFACE_H */

 /* EOF */
