/**
 * @file pal.h
 *
 * @brief PAL related APIs
 *
 * This header file declares prototypes of PAL APIs, enumerations
 * used by TAL and MAC.
 *
 * $Id: pal.h 12192 2008-11-24 12:58:27Z sschneid $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef PAL_H
#define PAL_H

/*
 * NOTE:- Include 'return_val.h' before this file, as return_val.h has the
 *        all return value enums.
 */

/* === Includes ============================================================ */

#include <stdbool.h>
#include <stdint.h>
#include "pal_config.h"
#include "pal_types.h"

/** @cond COMPLETE_PAL */

/* === Macros =============================================================== */

/**
 * Mask to obtain the most significant bit of a 32 bit variable
 */
#define MSB_MASK                                    (0x80000000)

/**
 * Mask to clear the least significant bits of a 32 bit variable
 */
#define LSB_MASK                                    (0x7FFFFFFF)

#if (PAL_GENERIC_TYPE != ARM7) && (PAL_GENERIC_TYPE != AVR32)
#ifndef SPECIAL_PEER
    #if defined(__GNUC__)
        #define PUTS(s) \
            { static const char c[] PROGMEM = s; printf_P(c); }
        #define PRINTF(fmt, ...) \
            { static const char c[] PROGMEM = fmt; printf_P(c, __VA_ARGS__); }
    #elif defined(__ICCAVR__)
        #define PUTS(s) \
            { static const char __flash c[] = s; printf_P(c); }
        #define PRINTF(fmt, ...) \
            { static const char __flash c[] = fmt; printf_P(c, __VA_ARGS__); }
    #else
        #error "Unknown compiler."
    #endif
#endif  /* SPECIAL_PEER */
#endif

/* === Types =============================================================== */

/*
 * Transceiver interrupt handler index
 */
typedef enum trx_irq_hdlr_idx_tag
{
    TRX_MAIN_IRQ_HDLR_IDX = 0,
    TRX_TSTAMP_IRQ_HDLR_IDX
} trx_irq_hdlr_idx_t;

/*
 * Pin State (please dont change this type)
 */
typedef enum pin_state_tag
{
    LOW,
    HIGH
} pin_state_t;

/*
 * Pin direction
 */
typedef enum port_pin_direction_tag
{
    INPUT,
    OUTPUT
} port_pin_direction_t;

/**
 * GPIO pins
 */
typedef enum gpio_pin_type_tag
{
    RST_PIN,
    SLP_TR_PIN
} gpio_pin_type_t;


#ifdef SIO_HUB
/*
 * Stream I/O to serial mapping enumeration
 */
typedef enum sio_serial_tag
{
    /* Serial unit used by user */
    SIO_0,      /* UART 0 */
    SIO_1,      /* UART 1 */
    SIO_2       /* USB 0 */
} sio_serial_t;
#endif

/** @endcond */
/**
 * Timeout type
 */
typedef enum
#if !defined(DOXYGEN)
timeout_type_tag
#endif
{
    /** The timeout is relative to the current time. */
    TIMEOUT_RELATIVE,
    /** The timeout is an absolute value. */
    TIMEOUT_ABSOLUTE
} timeout_type_t;
/** @cond COMPLETE_PAL */


/*
 * Timer clock source type
 */
typedef enum source_type_tag
{
    TMR_CLK_SRC_DURING_TRX_SLEEP,
    TMR_CLK_SRC_DURING_TRX_AWAKE
} source_type_t;


#if (DEBUG > 0)
/**
 * @brief Assert Octet string, the 0th element gives the length of data
 */
typedef uint8_t assert_octetstr_t;

/**
 * @brief This is the CMDIF-ECHO.indication message structure.
 */
typedef struct assert_tag
{
    /**< The total length of this message. */
    uint8_t size            ALIGN8BIT;
    /**< This identifies the message as \ref CMDIF_ECHO_INDICATION */
    uint8_t assert_cmdcode        ALIGN8BIT;
    /**< Bytes to read to frame, data[0] gives the length */
    assert_octetstr_t data[1]      ALIGN8BIT;
} assert_t;
#endif  /* (DEBUG > 0) */


/**
 * @brief IDs for persistence storage access
 */
typedef enum ps_id_tag
{
    PS_IEEE_ADDR,
    PS_XTAL_TRIM
} ps_id_t;


/**
 * @brief IDs for persistence storage type
 */
typedef enum ps_type_tag
{
    INTERN_EEPROM,
    EXTERN_EEPROM
} ps_type_t;


/**
 * @brief LED action
 */
typedef enum led_action_tag
{
    LED_ON,
    LED_OFF,
    LED_TOGGLE
} led_action_t;


/**
 * @brief Button action
 */
typedef enum button_state_tag
{
    BUTTON_PRESSED,
    BUTTON_OFF
} button_state_t;


/* === Externals ============================================================ */


/* === Prototypes =========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

        
        
        
/*
 * @brief Converts a 2 Byte array into a 16-Bit value
 *
 * @param data Specifies the pointer to the 2 Byte array
 *
 * @return 16-Bit value
 */
static inline uint16_t convert_byte_array_to_16_bit(uint8_t *data)
{
    return (data[0] | ((uint16_t)data[1] << 8));
}


/*
 * @brief Converts a 4 Byte array into a 32-Bit value
 *
 * @param data Specifies the pointer to the 4 Byte array
 *
 * @return 32-Bit value
 */
static inline uint32_t convert_byte_array_to_32_bit(uint8_t *data)
{
    union
    {
        uint32_t u32;
        uint8_t u8[4];
    }long_addr;

    uint8_t index;

    for (index = 0; index < 4; index++)
    {
        long_addr.u8[index] = *data++;
    }

    return long_addr.u32;
}


/*
 * @brief Converts a 8 Byte array into a 64-Bit value
 *
 * @param data Specifies the pointer to the 8 Byte array
 *
 * @return 64-Bit value
 */
static inline uint64_t convert_byte_array_to_64_bit(uint8_t *data)
{
    union
    {
        uint64_t u64;
        uint8_t u8[8];
    }long_addr;

    uint8_t index;

    for (index = 0; index < 8; index++)
    {
        long_addr.u8[7 - index] = *data++;
    }

    return long_addr.u64;
}


/*
 * @brief Converts a 16-Bit value into  a 2 Byte array
 *
 * @param[in] value 16-Bit value
 * @param[out] data Pointer to the 2 Byte array to be updated with 16-Bit value
 */
static inline void convert_16_bit_to_byte_array(uint16_t value, uint8_t *data)
{
    data[0] = value & 0xFF;
    data[1] = (value >> 8) & 0xFF;
}


/*
 * @brief Converts a 32-Bit value into  a 4 Byte array
 *
 * @param[in] value 32-Bit value
 * @param[out] data Pointer to the 4 Byte array to be updated with 32-Bit value
 */
static inline void convert_32_bit_to_byte_array(uint32_t value, uint8_t *data)
{
    uint8_t index = 0;

    while (index < 4)
    {
        data[index++] = value & 0xFF;
        value = value >> 8;
    }
}


/*
 * @brief Converts a 64-Bit value into  a 8 Byte array
 *
 * @param[in] value 64-Bit value
 * @param[out] data Pointer to the 8 Byte array to be updated with 64-Bit value
 */
static inline void convert_64_bit_to_byte_array(uint64_t value, uint8_t *data)
{
    uint8_t index = 0;

    while (index < 8)
    {
        data[index++] = value & 0xFF;
        value = value >> 8;
    }
}


/*
 * This function initializes the PAL. The RC Oscillator is calibrated.
 */
retval_t pal_init(void);


/*
 * This function handles the Stream I/O and timer
 */
void pal_task(void);


/*
 * Prototypes for different gpio operations
 */
void pal_gpio_set(gpio_pin_type_t gpio_pin, pin_state_t state);
pin_state_t pal_gpio_get(gpio_pin_type_t gpio_pin);


/*
 * Prototypes for different interrupt related operations
 */
void pal_trx_irq_init(trx_irq_hdlr_idx_t trx_irq_num, void *trx_irq_cb);

/**
 * @brief Enables the transceiver interrupt
 *
 * @param trx_irq_num One of several interrupt lines provided by the transceiver
 */
static inline void pal_trx_irq_enable(trx_irq_hdlr_idx_t trx_irq_num)
{
    ENABLE_TRX_IRQ(trx_irq_num);
}



/**
 * @brief Disables the transceiver interrupt
 *
 * @param trx_irq_num One of several interrupt lines provided by the transceiver
 */
static inline void pal_trx_irq_disable(trx_irq_hdlr_idx_t trx_irq_num)
{
    DISABLE_TRX_IRQ(trx_irq_num);
}



/**
 * @brief Clears the transceiver interrupt
 *
 * @param trx_irq_num One of several interrupt lines provided by the transceiver
 */
static inline void pal_trx_irq_flag_clr(trx_irq_hdlr_idx_t trx_irq_num)
{
    CLEAR_TRX_IRQ(trx_irq_num);
}



/**
 * @brief Enables the global interrupt
 */
static inline void pal_global_irq_enable(void)
{
    ENABLE_GLOBAL_IRQ();
}


/**
 * @brief Disables the global interrupt
 */
static inline void pal_global_irq_disable(void)
{
    DISABLE_GLOBAL_IRQ();
}



/*
 * Internal prototypes for pal_timer module
 */
retval_t pal_start_high_priority_timer(uint8_t timer_id,
                                       uint16_t timer_count,
                                       void *timer_cb,
                                       void *param_cb);
retval_t pal_stop_high_priority_timer(uint8_t timer_id);
void pal_timer_delay(uint16_t delay);
void pal_timer_source_select(source_type_t source);
bool pal_is_timer_running(uint8_t timer_id);
#if (DEBUG > 0)
bool pal_are_all_timers_stopped(void);
#endif  /* (DEBUG > 0) */


/*
 * @brief Adds two time values
 *
 * @param a Time value 1
 * @param b Time value 2
 *
 * @return Addition of a and b
 */
static inline uint32_t pal_add_time_us(uint32_t a, uint32_t b)
{
    return (ADD_TIME(a, b));
}


/*
 * @brief Subtracts two time values
 *
 * @param a Time value 1
 * @param b Time value 2
 *
 * @return Difference between a and b
 */
static inline uint32_t pal_sub_time_us(uint32_t a, uint32_t b)
{
    return (SUB_TIME(a, b));
}


/*
 * @brief Compares two time values
 *
 * This function compares two time values t1 and t2 and returns true if t1 is
 * less than t2. The rollover case is also taken care of.
 *
 * @param t1 Time
 * @param t2 Time
 *
 * @return true If t1 is less than t2 when MSBs are same, false otherwise. If
 * MSBs are not equal it returns true if t1 is greater than t2, flase otherwise
 */
static inline bool pal_compare_time(uint32_t t1, uint32_t t2)
{
    bool comparison_status = false;
    if ((t1 & MSB_MASK) == (t2 & MSB_MASK))
    {
        if (t1 < t2)
        {
            comparison_status = true;
        }
    }
    else
    {
        /* This is a timer roll case in which t2 is ahead of t1. */
        if ((t1 & LSB_MASK) > (t2 & LSB_MASK))
        {
            comparison_status = true;
        }
    }
    return comparison_status;
}


/*
 * Prototypes for transceiver access
 */
void pal_trx_frame_read(uint8_t* data, uint8_t length);
void pal_trx_frame_write(uint8_t* data, uint8_t length);
void pal_trx_read_timestamp(uint32_t *timestamp);
uint8_t pal_trx_reg_read(uint8_t addr);
void pal_trx_reg_write(uint8_t addr, uint8_t data);
uint8_t pal_trx_bit_read(uint8_t addr, uint8_t mask, uint8_t pos);
void pal_trx_bit_write(uint8_t reg_addr, uint8_t mask, uint8_t pos, uint8_t new_value);
#ifdef ENABLE_TRX_SRAM
void pal_trx_sram_read(uint8_t addr, uint8_t *data, uint8_t length);
void pal_trx_sram_write(uint8_t addr, uint8_t *data, uint8_t length);
void pal_trx_aes_wrrd(uint8_t addr, uint8_t *idata, uint8_t length);
#endif  /* #ifdef ENABLE_TRX_SRAM */


#ifdef SIO_HUB
/*
 * Prototypes for Stream I/O interface
 */
retval_t pal_sio_init(uint8_t unit);
uint8_t pal_sio_tx(uint8_t unit, uint8_t *data, uint8_t length);
uint8_t pal_sio_rx(uint8_t unit, uint8_t *data, uint8_t max_length);

#endif  /* SIO_HUB */


/*
 * Prototypes for RC Osc Calibration
 */
bool pal_calibrate_rc_osc(void);


/*
 * Prototypes for persistence storage
 */
retval_t pal_ps_get(ps_type_t ps_type, ps_id_t attribute, void *value);


/*
 * Prototypes for alert indication
 */
void pal_alert(void);


#if (DEBUG > 0)
void pal_assert(bool expression,
                FLASH_STRING_T message,
                int8_t *file,
                uint16_t line);

/* DEBUG only: Test for an assertion, similar to Std-C assert() */
#define ASSERT(expr)    pal_assert(expr, FLASH_STRING( #expr ), (int8_t*)__FILE__, __LINE__)
#else
#define ASSERT(expr)
#endif /* (DEBUG > 0) */

/** @endcond */

/*
 * Public prototypes for pal_timer module
 */

/**
 * @brief Start regular timer
 *
 * This function starts a regular timer and installs the corresponding
 * callback function handle the timeout event.
 *
 * @param timer_id Timer identifier
 * @param timer_count Timeout in microseconds
 * @param timeout_type @ref TIMEOUT_RELATIVE or @ref TIMEOUT_ABSOLUTE
 * @param timer_cb Callback handler invoked upon timer expiry
 * @param param_cb Argument for the callback handler
 *
 * @return
 *          - @ref INVALID_ID  if the timer identifier is undefined,
 *          - @ref INVALID_PARAMETER if the callback function for this timer
 *                 is NULL,
 *          - @ref ALREADY_RUNNING if the timer is already running.
 *          - @ref SUCCESS if timer is started or
 *          - @ref INVALID_TIMEOUT if timeout is not within timeout range.
 * @ingroup apiGrp
 */
retval_t pal_timer_start(uint8_t timer_id,
                         uint32_t timer_count,
                         timeout_type_t timeout_type,
                         void *timer_cb,
                         void *param_cb);

/**
 * @brief Stops a running timer
 *
 * This function stops a running timer with specified timer_id
 *
 * @param timer_id Timer identifier
 *
 * @return
 *          - @ref SUCCESS if timer stopped successfully,
 *          - @ref NOT_RUNNING if specified timer is not running,
 *          - @ref INVALID_ID if the specifed timer id is undefined.
 * @ingroup apiGrp
 */
retval_t pal_timer_stop(uint8_t timer_id);

/**
 * @brief Gets current time
 *
 * This function returns the current time.
 *
 * @param[out] current_time Returns current system time
 * @ingroup apiGrp
 */
void pal_get_current_time(uint32_t *current_time);


/**
 * @brief LED initialization
 */
void pal_led_init(void);
/**
 * @brief LED handling
 *
 * @param led_no LED id
 * @param led_setting LED action
 */
void pal_led(led_id_t led_no, led_action_t led_setting);



/**
 * @brief Button initialization
 */
void pal_button_init(void);
/**
 * @brief Button handling
 *
 * @param button_no Button id
 */
button_state_t pal_button_read(button_id_t button_no);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif  /* PAL_H */
/* EOF */
