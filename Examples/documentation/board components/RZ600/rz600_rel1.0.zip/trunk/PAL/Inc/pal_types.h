/**
 * @file pal_types.h
 *
 * @brief Definition of supported PAL types
 *
 * This header file contains the supported PAL types.
 *
 * $Id: pal_types.h 11733 2008-11-03 14:19:38Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef PAL_TYPES_H
#define PAL_TYPES_H

/* PAL_GENERIC_TYPE */
#define AVR                             (0x01)
#define XMEGA                           (0x02)
#define AVR32                           (0x03)
#define ARM7                            (0x04)

#if (PAL_GENERIC_TYPE == AVR)
    /* PAL_TYPE for AVR 8-bit MCUs */
    #define AT90USB1287                 (0x01)
    #define ATMEGA1281                  (0x02)
    #define ATMEGA1284P                 (0x03)
    #define ATMEGA2561                  (0x04)
    #define ATMEGA644P                  (0x05)

#elif (PAL_GENERIC_TYPE == XMEGA)
    /* PAL_TYPE for XMEGA MCUs */
    #define ATXMEGA128A1                (0x01)

#elif (PAL_GENERIC_TYPE == AVR32)
    /* PAL_TYPE for AVR 32-bit MCUs */
    #define AVR32UC3L064T               (0x01)
    #define AVR32UC3A0512               (0x02)

#elif (PAL_GENERIC_TYPE == ARM7)
    /* PAL_TYPE for ARM7 MCUs */
    #define AT91SAM7X256                (0x01)

#else
    #error "Undefined PAL_GENERIC_TYPE"
#endif

#endif  /* PAL_TYPES_H */
/* EOF */
