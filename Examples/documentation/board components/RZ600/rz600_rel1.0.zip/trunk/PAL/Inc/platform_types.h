/**
 * @file platform_types.h
 *
 * @brief Platform-dependend types (IAR, GCC)
 *
 * $Id: platform_types.h 11739 2008-11-03 15:00:50Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef PLATFORM_TYPES_H
#define PLATFORM_TYPES_H

/* === Includes ============================================================= */

#include "pal_types.h"

#if ((PAL_GENERIC_TYPE == AVR) || (PAL_GENERIC_TYPE == XMEGA))
#include "avrtypes.h"
#elif (PAL_GENERIC_TYPE == ARM7)
#include "armtypes.h"
#elif (PAL_GENERIC_TYPE == AVR32)
#include "avr32types.h"
#else
#error "Unknown PAL_GENERIC_TYPE"
#endif


/* === Externals ============================================================ */


/* === Macros =============================================================== */


/* === Types ================================================================ */


/* === Prototypes =========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

#ifdef cplusplus
} /* extern "C" */
#endif

#endif /* PLATFORM_TYPES_H */
/* EOF */
