/**
 * @file pal_boardtypes.h
 *
 * @brief PAL board types for ATxmega128A1
 *
 * This header file contains board types based on ATxmega128A1.
 *
 * $Id: pal_boardtypes.h 12000 2008-11-13 09:16:34Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef PAL_BOARDTYPES_H
#define PAL_BOARDTYPES_H

/* Boards for AT86RF230A */
#define REB_2_2_230A            (0x02)

/* Boards for AT86RF230B */
#define REB_2_3_230B            (0x12)

/* Boards for AT86RF231 */
#define REB_4_0_231             (0x22)
#define REB_4_1_231             (0x24)

/* Boards for AT86RF212 */
#define REB_5_0_212             (0x32)

#endif  /* PAL_BOARDTYPES_H */
/* EOF */
