/**
 * @file pal_timer.h
 *
 * @brief PAL timer internal functions prototypes for AVR ATxmega MCUs
 *
 * This header has the timer specific stuctures, macros and
 * internal functions for AVR ATxmega MCUs.
 *
 * $Id: pal_timer.h 11968 2008-11-12 16:34:23Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */


/* Prevent double inclusion */
#ifndef PAL_TIMER_H
#define PAL_TIMER_H

/* === Includes ============================================================= */


/* === Types ================================================================ */

/*
 * This defines the structure of the time type.
 */
typedef struct timer_info_tag
{
    /* Timeout in microseconds */
    uint32_t abs_exp_timer;

    /* Callback function to be executed on expiry of the timer */
    void *timer_cb;

    /* Parameter to be passed to the callback function of the expired timer */
    void *param_cb;

    /* Next timer which was started or has expired */
    uint8_t next_timer_in_queue;
} timer_info_t;

/*
 * Callback for timer functions
 */
typedef void (*timer_expiry_cb_t)(void *);

/* === Externals ============================================================ */

extern volatile uint16_t sys_time;

extern timer_info_t timer_array[];

/* === Macros ================================================================ */

/*
 * The index to indicate end of timer in the array
 */
#define NO_TIMER                (0xFF)

/*
 * The timeout indicating that timer is not running
 */
#define TIMER_NOT_RUNNING       (0)

/*
 * Shift mask to obtain the 16-bit system time out of a 32-bit timeout
 */
#define SYS_TIME_SHIFT_MASK     (16)

/*
 * Mask to obtain the 16-bit H/W time out of a 32-bit timeout
 */
#define HW_TIME_MASK            (0xFFFF)

/* === Prototypes =========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

void timer_init(void);
void timer_init_non_generic(void);
void internal_timer_handler(void);
bool stop_timer(uint8_t timer_id);
void timer_service(void);

/**
 * @brief Checks if timer can be started with specified timeout
 *
 * This function checks whether a timer can be started with the specified
 * timeout.
 *
 * @param timeout Time in microseconds
 *
 * @return true if the timeout is in a range to start timer
 */
static inline bool check_timeout_range(uint32_t timeout)
{
    bool ret = false;

    if ((timeout < MAX_TIMEOUT) && (timeout > MIN_TIMEOUT))
    {
        ret = true;
    }
    return ret;
}

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif  /* PAL_TIMER_H */
/* EOF */
