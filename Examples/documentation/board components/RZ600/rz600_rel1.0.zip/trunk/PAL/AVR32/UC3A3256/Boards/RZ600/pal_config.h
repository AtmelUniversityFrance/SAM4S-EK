/**
 * @file pal_config.h
 *
 * @brief PAL configuration for ATAVR32UC30512
 *
 * This header file contains configuration parameters for ATxmega128a1.
 *
 * $Id: pal_config.h 12337 2008-11-28 11:59:05Z sschneid $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef PAL_CONFIG_H
#define PAL_CONFIG_H

/* === Includes =============================================================*/
#include "avr32types.h"
#include "pal_boardtypes.h"

#if (BOARD_TYPE == RZ600)

/*
 * This header file is required since a function with
 * return type retval_t is declared
 */
#include "return_val.h"

/* === Types ================================================================*/

/* Enumerations used to idenfify LEDs */
typedef enum led_id_tag
{
    LED_0,
    LED_1,
} led_id_t;

/* Enumerations used to idenfify buttons */
typedef enum button_id_tag
{
    BUTTON_0
} button_id_t;

/* === Externals ============================================================*/


/* === Macros ===============================================================*/
#define F_CPU           (60000000UL) //!< CPU clock frequency.

#define FOSC0           (12000000)                              //!< Osc0 frequency: Hz.
#define OSC0_STARTUP    AVR32_PM_OSCCTRL0_STARTUP_2048_RCOSC  //!< Osc0 startup time: RCOsc periods.


/*
 * GPIO macros for ATAVR32UC3A3512
 */

/*
 * LEDs
 */
#define LED0_PIN                        (AVR32_PIN_PX22)
#define LED1_PIN                        (AVR32_PIN_PX41)


/*
 * RESET pin of transceiver
 */
#define TRX_RST                         (AVR32_PIN_PA17)


/*
 * Reset pin low
 */
#define RST_LOW()                       do {                                        \
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[TRX_RST >> 5];     \
        gpio_port->ovrc  = 1 << (TRX_RST & 0x1F);                                   \
        gpio_port->oders = 1 << (TRX_RST & 0x1F);                                   \
        gpio_port->gpers = 1 << (TRX_RST & 0x1F);                                   \
} while (0);

/*
 * Reset pin high
 */
#define RST_HIGH()                      do {                                        \
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[TRX_RST >> 5];     \
        gpio_port->ovrs  = 1 << (TRX_RST & 0x1F);                                   \
        gpio_port->oders = 1 << (TRX_RST & 0x1F);                                   \
        gpio_port->gpers = 1 << (TRX_RST & 0x1F);                                   \
} while (0);


/*
 * Sleep Transceiver pin
 */
#define SLP_TR                          (AVR32_PIN_PA19)

/*
 * SPI Pins
 */
#define RF_SPI_DIV                      (8)
#define RF_SPI                          (AVR32_SPI0)
#define RF_SPI_CS_REG                   (AVR32_SPI0.csr0)
#define RF_SPI_NPCS                     (0)
#define RF_SPI_NCPS_MASK                (0xE << 16)
#define SEL                             (AVR32_PIN_PA09)
#define MOSI                            (AVR32_SPI0_MOSI_0_0_PIN)
#define MOSI_FUNCTION                   (AVR32_SPI0_MOSI_0_0_FUNCTION)
#define MISO                            (AVR32_SPI0_MISO_0_0_PIN)
#define MISO_FUNCTION                   (AVR32_SPI0_MISO_0_0_FUNCTION)
#define SCK                             (AVR32_SPI0_SCK_0_0_PIN)
#define SCK_FUNCTION                    (AVR32_SPI0_SCK_0_0_FUNCTION)


/*
 * Slave select made low
 */
#define SS_LOW()                        do {                                    \
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[SEL >> 5];     \
        gpio_port->ovrc  = 1 << (SEL & 0x1F);                                   \
        gpio_port->oders = 1 << (SEL & 0x1F);                                   \
        gpio_port->gpers = 1 << (SEL & 0x1F);                                   \
} while (0);

/*
 * Slave select made high
 */
#define SS_HIGH()                       do {                                    \
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[SEL >> 5];     \
        gpio_port->ovrs  = 1 << (SEL & 0x1F);                                   \
        gpio_port->oders = 1 << (SEL & 0x1F);                                   \
        gpio_port->gpers = 1 << (SEL & 0x1F);                                   \
} while (0);


/*
 * UART
 */
#define SYS_F_UART                           (12000000UL)
#define USART0_BR                            (0x0D)
#define USART0_ISR_GROUP                     (6)
#define USART0_ISR_PRIORITY                  (1)
#define USART0                               (AVR32_USART1)
#define USART1                               (AVR32_USART0)
#define UART0_RX                             (AVR32_USART1_RXD_0_0_PIN)
#define UART0_RX_FUNCTION                    (AVR32_USART1_RXD_0_0_FUNCTION)
#define UART0_TX                             (AVR32_USART1_TXD_0_0_PIN)
#define UART0_TX_FUNCTION                    (AVR32_USART1_TXD_0_0_FUNCTION)


/*
 * Timer related settings for ATAVR32UC3A0512
 */
#define TC_CH1_ISR_GROUP        (14)
#define TC_CH1_ISR_PRIORITY     (1)
#define TC                      (AVR32_TC0)
#define TC_CH0                  (AVR32_TC0.channel[0])
#define TC_CH1                  (AVR32_TC0.channel[1])


/*
 * IRQ macros for ATAVR32UC3A3512
 */

/*
 * AT86RF231:
 *
 * TRX_MAIN_IRQ_HDLR_IDX        TRX interrupt (PORTC Pin2)
 * TRX_TSTAMP_IRQ_HDLR_IDX      Time stamping interrupt (PORTC Pin1,
 *                              only if Antenna Diversity is not used)
 */

/* Number of used TRX IRQs in this implementaton */
#define NO_OF_TRX_IRQS                  (1)


/*
 * Timer related settings for ATAVR32UC3A0512
 */
#define EXT_INT_ISR_GROUP               (2)
#define EXT_INT_ISR_PRIORITY            (1)
#define EXT_INT                         (AVR32_PIN_PA20)



/* Enables the transceiver interrupts */
#define ENABLE_TRX_IRQ(trx_irq_num)     do {                                    \
    if (trx_irq_num == TRX_MAIN_IRQ_HDLR_IDX)                                   \
    {                                                                           \
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[EXT_INT >> 5]; \
        gpio_port->iers = 1 << (EXT_INT & 0x1F);                                \
    }                                                                           \
} while (0)


/* Disables the transceiver interrupts */
#define DISABLE_TRX_IRQ(trx_irq_num)    do {                                    \
    if (trx_irq_num == TRX_MAIN_IRQ_HDLR_IDX)                                   \
    {                                                                           \
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[EXT_INT >> 5]; \
        gpio_port->ierc = 1 << (EXT_INT & 0x1F);                                \
    }                                                                           \
} while (0)


/* Clears the transceiver interrupts */
#define CLEAR_TRX_IRQ(trx_irq_num)     do {                                     \
    if (trx_irq_num == TRX_MAIN_IRQ_HDLR_IDX)                                   \
    {                                                                           \
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[EXT_INT >> 5]; \
        gpio_port->ifrc = 1 << (EXT_INT & 0x1F);                                \
    }                                                                           \
} while (0)


/* Enables the global interrupt */
#define ENABLE_GLOBAL_IRQ()             sei()

/* Disables the global interrupt */
#define DISABLE_GLOBAL_IRQ()            cli()

/*
 * This macro saves the global interrupt status
 */
#define ENTER_CRITICAL_REGION()         {__istate_t sreg = __get_interrupt_state(); cli()

/*
 *  This macro restores the global interrupt status
 */
#define LEAVE_CRITICAL_REGION()         __set_interrupt_state(sreg);}

/*
 * Mask used to obtain the gloabl interrupt status bit in the status register
 * of the ATxmega128A1
 */
#ifndef __ICCAVR__
#define GLOBAL_IRQ_MASK                 (CPU_I_bm)
#else
#define GLOBAL_IRQ_MASK                 (I_bm)
#endif


/*
 * Value of an external PA gain
 * If no external PA is available, value is 0.
 */
#define EXTERN_PA_GAIN                  (0)

/*
 * Timer macros for ATAVR32UC3A0512
 */

/*
 * These macros are placeholders for delay functions for high speed processors.
 *
 * The following delay are not reasonbly implemented via delay functions,
 * but rather via a certain number of NOP operations.
 * The actual number of NOPs for each delay is fully MCU and frequency
 * dependent, so it needs to be updated for each board configuration.
 *
 * ATxmega128a1 @ 16MHz
 */
/* Wait for 500 ns. */
#define PAL_WAIT_500_NS()               do {            \
        uint32_t ticks = ((F_CPU / 1000000U) / 2);      \
        ticks += get_sys_reg(AVR32_COUNT);              \
        while (get_sys_reg(AVR32_COUNT) < ticks) {;}    \
} while (0)

/* Wait for 1 us. */
#define PAL_WAIT_1_US()               do {              \
        uint32_t ticks = ((F_CPU / 1000000U));          \
        ticks += get_sys_reg(AVR32_COUNT);              \
        while (get_sys_reg(AVR32_COUNT) < ticks) {;}    \
} while (0)


/*
 * The smallest timeout in microseconds
 */
#define MIN_TIMEOUT                     (0x80)

/*
 * The largest timeout in microseconds
 */
#define MAX_TIMEOUT                     (0x7FFFFFFF)

/**
 * Minimum time in microseconds, accepted as a delay request
 */
#define MIN_DELAY_VAL                   (5)


/*
 * Maximum numbers of software timers running at a time
 */
#define MAX_NO_OF_TIMERS                (25)

/*
 * The maximum time count in microseconds for a 32 bit timer
 */
#define TIMER_MAX_COUNT_IN_US           (0xFFFFFFFF)

/*
 * Adds two values
 */
#define ADD_TIME(a, b)                  (a + b)

/*
 * Subtracts two time values taking care of roll over
 */
#define SUB_TIME(a, b) \
        ((a) > (b) ? (a - b) : ((TIMER_MAX_COUNT_IN_US - b) + a))

#ifndef ANTENNA_DIVERSITY
/*
 * Hardware register that holds Rx timestamp
 */
#define TIME_STAMP_REGISTER             (TCC1_CCA)
#endif  /* #ifndef ANTENNA_DIVERSITY */


/*
 * Dummy value written in SPDR to retrieve data form it
 */
#define SPI_DUMMY_VALUE                 (0x00)


/*
 * IEEE address of board in EEPROM
 */
#define EE_IEEE_ADDR                    (0)


/*
 * Alert initialization
 */
#define ALERT_INIT()                    do {    \
} while (0)

/*
 * Alert indication
 */
#define ALERT_INDICATE() 


/* === Prototypes ===========================================================*/
#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* RZ600 */

#endif  /* PAL_CONFIG_H */
/* EOF */
