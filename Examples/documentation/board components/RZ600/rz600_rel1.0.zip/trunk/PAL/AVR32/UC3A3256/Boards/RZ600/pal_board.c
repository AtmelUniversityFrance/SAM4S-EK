/**
 * @file pal_board.c
 *
 * @brief PAL board specific functionality
 *
 * This file implements PAL board specific functionality.
 *
 * $Id: pal_board.c 12330 2008-11-28 10:00:27Z sschneid $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================ */

#include <stdbool.h>
#include <stdlib.h>
#include "platform_types.h"
#include "pal.h"
#include "pal_boardtypes.h"
//#include "pal_config.h"
#include "pal_internal.h"
#include "pal_gpio.h"
/*
 * 'sys_time' is a entity of timer module which is given to other modules
 * through the interface file below. 'sys_time' is required to obtain the
 * frame timestamp
 */
#include "pal_timer.h"

#if (BOARD_TYPE == RZ600)

/* === Macros ============================================================== */
/* === Types =============================================================== */

/**
 * Encoding of the board family in the board_family configuration
 * record member.
 */
enum boardfamilycode
{
    CFG_BFAMILY_RADIO_EXTENDER, /**< Radio Extender boards */
    CFG_BFAMILY_RCB             /**< Radio Controller boards */
} SHORTENUM;

/**
 * Structure of the configuration record EEPROM data.  These data
 * reside at offset CFG_BASE_ADDR, and allocate the upper address
 * space of the EEPROM.  The lower address space is available for
 * further extensions, and/or customer use (the upper part can be
 * software write-protected on demand).
 *
 * The record is divided into 32 bytes of structured binary
 * configuration data, followed by up to 30 bytes of textual
 * configuration data (terminated with \0), and terminated by a CRC-16
 * checksum.  The CRC algorithm used is the same CCITT algorithm that
 * is also used to protect IEEE 802.15.4 frames.
 *
 * All multibyte integer values are stored in little-endia byte order.
 */
struct cfg_eeprom_data
{
#if 0
    union
    {
        /** Raw access to binary configuration data. */
        uint8_t raw_binary[CFG_BINARYLEN];

        /* Structured access to binary configuration data. */
        struct
        {
            /** factory-supplied EUI-64 address */
            uint64_t mac_address;

            /** factory-supplied board serial number */
            uint64_t serial_number;

            /** board ID: family */
            enum boardfamilycode board_family;

            /** board ID: major, minor, revision */
            uint8_t board_id[3];

            /** feature byte 1: RF frontend features */
            uint8_t feature1;

            /** 16 MHz crystal oscillator calibration value */
            uint8_t cal_16mhz;

            /** RC oscillator calibration value, Vcc = 3.6 V */
            uint8_t cal_rc_36;

            /** RC oscillator calibration value, Vcc = 2.0 V */
            uint8_t cal_rc_20;

            /** antenna gain, 1/10 dB */
            int8_t antenna_gain;

            /* 7 bytes reserved, leave as 0xFF */
        }
        struct_binary;
    }
    binary_data;

    /** Textual board name, ASCIZ string */
    char board_name[CFG_NAMELEN];
#endif
    /** CRC-16 over binary_data and board_name[] */
    uint16_t crc;
};

/* === Globals ============================================================= */


/* === Prototypes ========================================================== */

#ifdef EXTERN_EEPROM_AVAILABLE
static uint8_t at25010_read_byte(uint8_t addr);
#endif

/* === Implementation ======================================================= */

/**
 * @brief Provides timestamp of the last received frame
 *
 * This function provides the timestamp (in microseconds)
 * of the last received frame.
 *
 * @param[out] Timestamp in microseconds
 */
void pal_trx_read_timestamp(uint32_t *timestamp)
{
#ifndef ANTENNA_DIVERSITY
    /*
     * Everytime a transceiver interrupt is triggred, input capture register of
     * the AVR is latched. The 'sys_time' is concatenated to the ICR to
     * generate the time stamp of the received frame.
     * 'sys_time'   'ICR'
     *  ---------|--------- => 32 bit timestamp
     *   16 bits   16 bits
     */
    *timestamp = (uint32_t)sys_time << (uint32_t)16;
    
    
    
    //*timestamp |= (uint32_t)TIME_STAMP_REGISTER;



#else
    timestamp = timestamp;  /* Keep compiler happy. */
#endif  /* ANTENNA_DIVERSITY */
}



/**
 * @brief Calibrates the internal RC oscillator
 *
 * This function calibrates the internal RC oscillator.
 *
 * @return True since the RC oscillator is always calibrated
 *         automatically at startup by hardware itself
 */
bool pal_calibrate_rc_osc(void)
{
    return (true);
}


/**
 * @brief Initialize the interrupt system of the ATxmega
 */
void interrupt_system_init(void)
{
    /* Enable high priority interrupts */
    
}



/**
 * @brief Initialize the clock of the ATxmega
 */
void clock_init(void)
{
        /* Set oscillator mode and start up time and wait for it to become ready. */
        AVR32_PM.OSCCTRL0.mode = AVR32_PM_OSCCTRL0_MODE_CRYSTAL_G3;
        AVR32_PM.OSCCTRL0.startup = OSC0_STARTUP;        

        AVR32_PM.mcctrl |= AVR32_PM_MCCTRL_OSC0EN_MASK;
        
        while (!(AVR32_PM.poscsr & AVR32_PM_POSCSR_OSC0RDY_MASK));
        
        /* Switch main clock to Osc0. */
        AVR32_PM.MCCTRL.mcsel = AVR32_PM_MCSEL_OSC0;
        
        /* Set-up the PLL, enable it and wait for lock. */
        avr32_pm_pll_t pll_conf = {
                .pllmul = 9,
                .plldiv = 1,
                .pllosc = 0,
                .pllopt = 3,
                .pllcount = 16,
                .pllen = 1,
        };
        AVR32_PM.PLL[0] = pll_conf;
        
        while (!(AVR32_PM.poscsr & AVR32_PM_POSCSR_LOCK0_MASK));
       
        /* Set-up the bus speed: 12MHz with the HSB at 48MHz. */
        avr32_pm_cksel_t bus_conf;
        bus_conf.hsbsel = 0;
        bus_conf.hsbdiv = 0;
        bus_conf.pbasel = 0;
        bus_conf.pbadiv = 0;
        bus_conf.pbbsel = 0;
        bus_conf.pbbdiv = 0;
        
        AVR32_PM.CKSEL = bus_conf;
        while (!(AVR32_PM.poscsr & AVR32_PM_POSCSR_CKRDY_MASK));
        
        /* Set one wait state. */
        AVR32_FLASHC.FCR.fws = 1;
        
        /* Enable clock. */
        AVR32_PM.MCCTRL.mcsel = AVR32_PM_MCCTRL_MCSEL_PLL0;
        
        /* Set up GCLK for USB. */
        avr32_pm_gcctrl_t gc_conf;
        gc_conf.cen = 1;
        
        AVR32_PM.GCCTRL[AVR32_PM_GCLK_USBB] = gc_conf;
}



/*
 * This function is called by timer_init() to perform the non-generic portion
 * of the initialization of the timer module.
 *
 * sys_clk = 16MHz -> Will be used as source for Event Channel 0 with Prescaler 16
 *
 * Timer usage
 * TCC0_CCA: Systime (software timer based on compare match)
 * TCC1_CCA: Input capture for time stamping (only if Antenna diversity is not used)
 */
void timer_init_non_generic(void)
{
        /* Chain timer channel0 and channel1 together. */
        
        /*
        We only have the PBA clock to run from, however it might be difficult
        to get the correct divide - so we let one channel clock the other to
        form a chained design with 1us tick.
        */
        
        /* Set up the timer channel0 to make a 1MHz clock for channel 1. */  
        avr32_tc_cmr_t cmr_conf = {.waveform = {
                .acpc = AVR32_TC_CMR0_ACPC_CLEAR,
                .acpa = AVR32_TC_CMR0_ACPA_SET,
                .wave = 1,
                .wavsel = AVR32_TC_CMR0_WAVSEL_UP_AUTO,
                .tcclks = AVR32_TC_CMR0_TCCLKS_TIMER_CLOCK2,
        }};
        
        TC_CH0.CMR = cmr_conf;
        TC_CH0.idr = 0xFF;
        TC_CH0.ra = 15;
        TC_CH0.rc = 30;
        
        TC_CH0.CCR.clken = 1;
        
        /* Set up next channel to be clocked from channel 0. */
        avr32_tc_cmr_t cmr_conf1 = {.waveform = {
                .wave = 1,
                .wavsel = AVR32_TC_CMR0_WAVSEL_UP_AUTO,
                .tcclks = AVR32_TC_CMR1_TCCLKS_XC1,
        }};
        
        TC_CH1.CMR = cmr_conf1;
        TC_CH1.idr = 0xFF;
        TC_CH1.ier = AVR32_TC_IER1_COVFS_MASK;
        TC_CH1.CCR.clken = 1;
        
        /* Chain the two timers and synch them. */
        TC.BMR.tc1xc1s = AVR32_TC_BMR_TC1XC1S_TIOA0;
        TC.BCR.sync = 1;
}



/**
 * @brief Read one byte from an AT25010 EEPROM.
 *
 * Due to the connection between MCU, TRX and EEPROM, an EEPROM access
 * causes a transceiver reset. Therefore an entire transceiver configuration
 * is necessary after EEPROM access.
 *
 * @param addr Byte address to read from
 *
 * @return Data read from EEPROM
 */
#ifdef EXTERN_EEPROM_AVAILABLE
static uint8_t at25010_read_byte(uint8_t addr)
{

    uint8_t read_value;
#if 0
    RST_LOW();
    ENTER_CRITICAL_REGION();

    SS_LOW();

    PAL_WAIT_1_US();

    SPI_DATA_REG = AT25010_CMD_READ;
    SPI_WAIT();
    SPI_DATA_REG = addr & 0x7F; // mask out Bit 7 for 128x8 EEPROM
    SPI_WAIT();

    SPI_DATA_REG = 0;   // dummy value to start SPI transfer
    SPI_WAIT();
    read_value = SPI_DATA_REG;

    SS_HIGH();
    LEAVE_CRITICAL_REGION();
    RST_HIGH();
#endif
    return read_value;
}
#endif



/**
 * @brief Get data from external EEPROM
 *
 * @param[out] *value storage location for result
 *
 * @return SUCCESS if external EERPOM is available and contains valid contents
 *         FAILURE else
 */
#ifdef EXTERN_EEPROM_AVAILABLE
retval_t extern_eeprom_get(ps_id_t attribute, void *value)
{
#if 0
    uint8_t i;
    struct cfg_eeprom_data cfg;
    uint8_t *up;
    uint16_t crc;

    // Read data from external EEPROM.
    for (i = 0, up = (uint8_t *)&cfg; i < sizeof(cfg); i++, up++)
    {
        *up = at25010_read_byte(i);
    }

    // Calcute CRC to validate data correctness
    for (i = 0, crc = 0, up = (uint8_t *)&cfg; i < sizeof(cfg); i++, up++)
    {
        crc = CRC_CCITT_UPDATE(crc, *up);
    }
    if (crc != 0)
    {
        return FAILURE;
    }

    // Get the requested value out of the EEPROM data structure
    switch (attribute)
    {
        case PS_IEEE_ADDR:
            *(uint64_t *)value = cfg.binary_data.struct_binary.mac_address;
            break;

        case PS_XTAL_TRIM:
            *(uint8_t *)value = cfg.binary_data.struct_binary.cal_16mhz;
            break;

        default:
            return UNSUPPORTED_ATTRIBUTE;
    }
#endif
    return SUCCESS;
}
#endif


#if defined(__ICCAVR__) || defined(DOXYGEN)
/* This function is available in WINAVR library */
/**
 * @brief Computes the CCITT-CRC16 on a byte by byte basis
 *
 * This function computes the CCITT-CRC16 on a byte by byte basis.
 * It updates the CRC for transmitted and received data using the CCITT 16bit
 * algorithm (X^16 + X^12 + X^5 + 1).
 *
 * @param crc Current crc value
 * @param data Next byte that should be included into the CRC16
 *
 * @return updated CRC16
 */
#ifdef EXTERN_EEPROM_AVAILABLE
uint16_t crc_ccitt_update(uint16_t crc, uint8_t data)
{
    data ^= crc & 0xFF;
    data ^= data << 4;

    return ((((uint16_t)data << 8) | ((crc & 0xFF00) >> 8)) ^ \
            (uint8_t)(data >> 4) ^ \
            ((uint16_t)data << 3));
}
#endif /* EXTERN_EEPROM_AVAILABLE */
#endif /* __ICCAVR__ || defined(DOXYGEN) */


/**
 * @brief Initialize LEDs
 */
void pal_led_init(void)
{
        gpio_enable_output(LED0_PIN);
        gpio_enable_output(LED1_PIN);
}


/**
 * @brief Control LED status
 *
 * param[in]  led_no LED ID
 * param[in]  led_setting LED_ON, LED_OFF, LED_TOGGLE
 */
void pal_led(led_id_t led_no, led_action_t led_setting)
{
    uint8_t pin;

    switch (led_no)
    {
        case LED_0: pin = LED0_PIN; break;
        default: pin = LED1_PIN; break;
    }

    switch (led_setting)
    {
        case LED_ON: gpio_clr_gpio_pin(pin); break;

        case LED_OFF: gpio_set_gpio_pin(pin); break;

        case LED_TOGGLE: gpio_tgl_gpio_pin(pin); break;
        default: /* do nothing */ break;
    }
}
#endif /* REB_4_1_231 */

/* EOF */
