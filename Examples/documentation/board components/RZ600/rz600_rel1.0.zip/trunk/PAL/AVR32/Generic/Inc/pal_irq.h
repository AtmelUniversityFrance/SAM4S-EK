/**
 * @file pal_irq.h
 *
 * @brief PAL IRQ header file for AVR ATxmega MCUs
 *
 * This a header file used by the IRQ module for AVR ATxmega MCUs.
 *
 * $Id: pal_irq.h 11208 2008-10-01 16:46:04Z sschneid $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef PAL_IRQ_H
#define PAL_IRQ_H

/* === Includes =============================================================*/


/* === Types ================================================================*/

/**
 * This is a typedef of the function which is called from the transceiver ISR
 */
typedef void (*irq_handler_t)(void);

/* === Externals ============================================================*/


/* === Macros ===============================================================*/


/* === Prototypes ===========================================================*/
#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif  /*PAL_IRQ_H*/
/* EOF */
