 /**
 * @file pal_gpio.c
 *
 * @brief PAL GPIO API functions
 *
 * This file implements the PAL API functions for GPIO
 *
 * $Id: pal_gpio.c 11738 2008-11-03 14:37:25Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================ */

#include <stdint.h>
#include "platform_types.h"
#include "return_val.h"
#include "pal.h"
#include "pal_gpio.h"

/* === Globals ============================================================= */


/* === Prototypes ========================================================== */

void gpio_pin_init(uint32_t pin, port_pin_direction_t pin_direction);
pin_state_t gpio_get(uint32_t pin);


/* === Implementation ====================================================== */
static void gpio_enable_module_pin(unsigned int pin, unsigned int function)
{
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[pin >> 5];

        // Enable the correct function.
        switch (function)
        {
        case 0: // A function.
        gpio_port->pmr0c = 1 << (pin & 0x1F);
        gpio_port->pmr1c = 1 << (pin & 0x1F);
        break;

        case 1: // B function.
        gpio_port->pmr0s = 1 << (pin & 0x1F);
        gpio_port->pmr1c = 1 << (pin & 0x1F);
        break;

        case 2: // C function.
        gpio_port->pmr0c = 1 << (pin & 0x1F);
        gpio_port->pmr1s = 1 << (pin & 0x1F);
        break;
        
        case 3: // D function.
        gpio_port->pmr0s = 1 << (pin & 0x1F);
        gpio_port->pmr1s = 1 << (pin & 0x1F);
        break;

        default: return;
        }
        
        // Disable GPIO control.
        gpio_port->gperc = 1 << (pin & 0x1F);
}


void gpio_enable_output(unsigned int pin)
{
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[pin >> 5];
        gpio_port->oderc = 1 << (pin & 0x1F);
        gpio_port->gpers = 1 << (pin & 0x1F);
        gpio_port->oders = 1 << (pin & 0x1F); // The GPIO output driver is enabled for that pin.
}


void gpio_enable_input(unsigned int pin)
{
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[pin >> 5];
        gpio_port->oderc = 1 << (pin & 0x1F);
        gpio_port->gpers = 1 << (pin & 0x1F);
        gpio_port->oderc = 1 << (pin & 0x1F); // The GPIO output driver is disabled for that pin.
}


void gpio_set_gpio_pin(unsigned int pin)
{
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[pin >> 5];

        gpio_port->ovrs  = 1 << (pin & 0x1F); // Value to be driven on the I/O line: 1.
}


void gpio_clr_gpio_pin(unsigned int pin)
{
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[pin >> 5];

        gpio_port->ovrc  = 1 << (pin & 0x1F); // Value to be driven on the I/O line: 0.
}


void gpio_tgl_gpio_pin(unsigned int pin)
{
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[pin >> 5];

        gpio_port->ovrt  = 1 << (pin & 0x1F); // Value to be driven on the I/O line: tgl.
}


static pin_state_t gpio_get(uint32_t pin)
{
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[pin >> 5];
        
        /* Check whether the pin is HIGH */
        if ((gpio_port->pvr >> (pin & 0x1F)) & HIGH)
        {
                return(HIGH);
        }
        else
        {
                return(LOW);
        }
}


/**
 * @brief Initializes the GPIO pins
 *
 * This function is used to initialize the port pins used to connect
 * the microcontroller to transceiver.
 */
void gpio_init(void)
{
        /* Set-up the UART0 pins to function A. */
        gpio_enable_module_pin(UART0_RX, UART0_RX_FUNCTION);
        gpio_enable_module_pin(UART0_TX, UART0_TX_FUNCTION);
        
        /* Initialize peripheral interrupt pin. */
        gpio_enable_input(EXT_INT);
        
        /* Initialize SLP_TR, RST and SS as GPIO. */
        gpio_enable_output(TRX_RST);
        gpio_enable_output(SLP_TR);
        gpio_set_gpio_pin(SLP_TR);
        
        gpio_enable_output(SEL);
        gpio_set_gpio_pin(SEL);
        
        /* Initialize pins for SPI0 (11 - 13) to function A. */
        gpio_enable_module_pin(MOSI, MOSI_FUNCTION);
        gpio_enable_module_pin(MISO, MISO_FUNCTION);
        gpio_enable_module_pin(SCK, SCK_FUNCTION);
}


/**
 * @brief Sets the GPIO pin state
 *
 * This functions sets the state of a GPIO pin.
 *
 * @param gpio_pin GPIO pin to be made HIGH or LOW
 * @param state New pin state
 */
void pal_gpio_set(gpio_pin_type_t gpio_pin, pin_state_t state)
{
        if (SLP_TR_PIN == gpio_pin)
        {
                if (HIGH == state)
                {
                        gpio_set_gpio_pin(SLP_TR);
                }
                else
                {
                        gpio_clr_gpio_pin(SLP_TR);
                }
        }
        else if (RST_PIN == gpio_pin)
        {
                if (HIGH == state)
                {
                        gpio_set_gpio_pin(TRX_RST);
                }
                else
                {
                        gpio_clr_gpio_pin(TRX_RST);
                }
        }
}


/**
 * @brief Gets the current GPIO pin state
 *
 * This function gets the current state of a GPIO pin.
 *
 * @param gpio_pin GPIO pin to be read
 *
 * @return Current GPIO pin state
 */
pin_state_t pal_gpio_get(gpio_pin_type_t gpio_pin)
{
    pin_state_t pin_state = LOW;

    if (RST_PIN == gpio_pin)
    {
        pin_state = gpio_get(TRX_RST);
    }
    else if (SLP_TR_PIN == gpio_pin)
    {
        pin_state = gpio_get(SLP_TR);
    }

    return pin_state;
}
/* EOF */
