/**
 * @file pal_gpio.h
 *
 * @brief PAL GPIO internal functions prototypes for AVR32 MCUs
 *
 * This is the header file for the GPIOs for AVR32 MCUs.
 *
 * $Id: pal_gpio.h 11263 2008-10-07 15:55:35Z sschneid $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */


/* Prevent double inclusion */
#ifndef PAL_GPIO_H
#define PAL_GPIO_H

/* === Includes ============================================================= */


/* === Types ================================================================ */


/* === Externals ============================================================ */


/* === Macros ================================================================ */


/* === Prototypes =========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

void gpio_init(void);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif  /* PAL_GPIO_H */
/* EOF */
