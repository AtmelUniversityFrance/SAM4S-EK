/**
 * @file pal_general.c
 *
 * @brief General file for PAL for AVR ATxmega MCUs
 *
 * This file implements generic PAL function and performs
 * USB related handling if required for AVR ATxmega MCUs.
 *
 * $Id: pal.c 12184 2008-11-24 10:54:21Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */
/* === Includes ============================================================ */
#include <stdint.h>
#include <stdbool.h>
#include "platform_types.h"
#include "pal_config.h"
#include "pal_gpio.h"
#include "pal_timer.h"
#include "pal_internal.h"
#include "pal_trx_access.h"
#include "pal.h"

#ifdef USB0
#include "pal_usb.h"
#endif /* USB0 */

/* === Globals ============================================================= */

/*
 * This section defines all global variables for the PAL
 */

/*
 * This is the most significant part of the system time. The least one is
 * timer1 (TCNT1) itself.  Exported since input capture units might want
 * to know about this value as well.
 */
volatile uint16_t sys_time;

/* === Prototypes ========================================================== */
/* === Implementation ====================================================== */

/**
 * @brief Initialization of PAL
 *
 * This function initializes the PAL.
 *
 * @return SUCCESS if PAL initialization is successful, FAILURE otherwise
  */
retval_t pal_init(void)
{
    clock_init();
    gpio_init();
    trx_interface_init();
    timer_init();
    interrupt_system_init();

    return SUCCESS;
}



/**
 * @brief Services timer and sio handler
 *
 * This function calls sio & timer handling functions.
 */
void pal_task(void)
{
    timer_service();
    /*
     * If the serial communication is done using USB, only then the 'usb_handler'
     * needs to be called. For UART, the data handling is done in the UART ISR.
     */
#ifdef USB0
    usb_handler();
#endif /* USB0 */
}

/**
 * @brief Get data from persistence storage
 *
 * param[in]  ps_type Persistence storage type
 * param[in]  attribute ID which data to get
 * param[out] value Data from persistence storage
 *
 * @return SUCCESS if everything went OK else FAILURE
 */
retval_t pal_ps_get(ps_type_t ps_type, ps_id_t attribute, void *value)
{
#ifdef EXTERN_EEPROM_AVAILABLE
    if (ps_type == EXTERN_EEPROM)
    {


        return extern_eeprom_get(attribute, value);
    }
    else
#endif

    if (ps_type == INTERN_EEPROM)
    {
        switch (attribute)
        {
            case PS_IEEE_ADDR:
                    *(uint64_t *)value = IEEE_ADDRESS;
                break;

            case PS_XTAL_TRIM:
                /* Currently there is no xtal trim value stored to the internal EEPROM. */
                *(uint8_t *)value = 0;  // default value
                break;

            default:
                return UNSUPPORTED_ATTRIBUTE;
        }
    }
    else    // no internal eeprom and no external eeprom available
    {
        return INVALID_PARAMETER;
    }

    return SUCCESS;
}



/*
 * @brief Alert indication
 *
 * This Funciton can be used by any application to indicate an error condition.
 * The function is blocking and does never return.
 */
void pal_alert(void)
{
#if (DEBUG > 0)
    bool debug_flag = false;
#endif
    ALERT_INIT();

    while (1)
    {
        pal_timer_delay(0xFFFF);
        ALERT_INDICATE();

#if (DEBUG > 0)
        /* Used for debugging purposes only */
        if (debug_flag == true)
        {
            break;
        }
#endif
    }
}


/* EOF */
