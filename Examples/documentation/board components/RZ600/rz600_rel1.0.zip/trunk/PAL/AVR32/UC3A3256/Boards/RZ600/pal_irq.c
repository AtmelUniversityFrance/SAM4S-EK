/**
 * @file pal_irq.c
 *
 * @brief PAL IRQ functionality
 *
 * This file contains functions to initialize, enable, disable and install
 * handler for the transceiver interrupts. It also contains functions to enable,
 * disable and get the status of global interrupt
 *
 * $Id: pal_irq.c 11738 2008-11-03 14:37:25Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === Includes ============================================================ */

#include <stdint.h>
#include "platform_types.h"
#include "return_val.h"
#include "pal.h"
#include "pal_irq.h"
#include "pal_boardtypes.h"

#if (BOARD_TYPE == RZ600)

/* === Globals ============================================================= */

/*
 * Function pointers to store the callback function of
 * the transceiver interrupt
 */
static irq_handler_t irq_handler[NO_OF_TRX_IRQS];

/* === Prototypes ========================================================== */

/* === Implementation ====================================================== */

/**
 * @brief Initializes the transceiver interrupts
 *
 * This function sets the microcontroller specific registers
 * responsible for handling the transceiver interrupts
 *
 * @param trx_irq_num Transceiver interrupt line to be initialized
 * @param trx_irq_cb Callback function for the given transceiver
 * interrupt
 */
void pal_trx_irq_init(trx_irq_hdlr_idx_t trx_irq_num, void *trx_irq_cb)
{
    /*
     * Set the handler function.
     * The handler is set before enabling the interrupt to prepare for spurious
     * interrupts, that can pop up the moment they are enabled
     */
    irq_handler[trx_irq_num] = (irq_handler_t)trx_irq_cb;

    if (trx_irq_num == TRX_MAIN_IRQ_HDLR_IDX)
    {
        volatile avr32_gpio_port_t *gpio_port = &AVR32_GPIO.port[EXT_INT >> 5];
        uint32_t mask = 1 << (EXT_INT & 0x1F);
        gpio_port->gfers = mask;
        gpio_port->imr0s = mask;
        gpio_port->imr1c = mask;
        gpio_port->ifrc = mask;
    }
}


/**
 * @brief ISR for transceiver's main interrupt
 */
#pragma handler=EXT_INT_ISR_GROUP,EXT_INT_ISR_PRIORITY
__interrupt void ext_int_isr(void)
{
    CLEAR_TRX_IRQ(TRX_MAIN_IRQ_HDLR_IDX);
    irq_handler[TRX_MAIN_IRQ_HDLR_IDX]();
}


#if 0
/**
 * @brief ISR for transceiver's RX TIME STAMP interrupt
 */
#ifndef ANTENNA_DIVERSITY
ISR(TRX_TSTAMP_ISR_VECTOR)
{
    /* Clear capture interrupt. */
    TCC1_INTFLAGS |= TC1_CCAIF_bm;

    irq_handler[TRX_TSTAMP_IRQ_HDLR_IDX]();
}
#endif
#endif

#endif /* RZ600 */

/* EOF */
