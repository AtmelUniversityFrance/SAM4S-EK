/**
 * @file pal_internal.h
 *
 * @brief PAL  internal functions prototypes for AVR ATxmega MCUs
 *
 * $Id: pal_internal.h 11056 2008-09-15 08:00:34Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */


/* Prevent double inclusion */
#ifndef PAL_INTERNAL_H
#define PAL_INTERNAL_H

/* === Includes ============================================================= */

#include "pal.h"

/* === Types ================================================================ */


/* === Externals ============================================================ */


/* === Macros ================================================================ */


/* === Prototypes =========================================================== */

#ifdef __cplusplus
extern "C" {
#endif


void gpio_enable_output(unsigned int pin);
void gpio_enable_input(unsigned int pin);
void gpio_set_gpio_pin(unsigned int pin);
void gpio_clr_gpio_pin(unsigned int pin);
void gpio_tgl_gpio_pin(unsigned int pin);

void clock_init(void);
void interrupt_system_init(void);

#ifdef EXTERN_EEPROM_AVAILABLE
retval_t extern_eeprom_get(ps_id_t attribute, void *value);
#endif

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif  /* PAL_INTERNAL_H */
/* EOF */
