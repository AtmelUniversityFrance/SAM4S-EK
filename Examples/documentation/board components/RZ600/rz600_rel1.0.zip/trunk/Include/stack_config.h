/**
 * @file stack_config.h
 *
 * @brief Stack configuration parameters
 *
 * $Id: stack_config.h 12196 2008-11-24 15:35:53Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef STACK_CONFIG_H
#define STACK_CONFIG_H

/* === Includes ============================================================= */


/* === Macros =============================================================== */

/**
 * The following macro holds the size of a large buffer.
 */
#ifdef RFD
#define LARGE_BUFFER_SIZE                   ((sizeof(frame_info_t) + \
                                             aMaxPHYPacketSize + 1) * 2 / 2)
#else   /* FFD */
#define LARGE_BUFFER_SIZE                   ((sizeof(indirect_data_t) + \
                                             sizeof(frame_info_t) + \
                                             aMaxPHYPacketSize + 1) * 2 / 2)
#endif  /* RFD/FFD */

/**
 * The following macro holds the size of a small buffer.
 */
#ifdef RFD
#define SMALL_BUFFER_SIZE                   ((sizeof(frame_info_t) + \
                                             MAX_MGMT_FRAME_LENGTH + 1) * 2 / 2)
#else   /* FFD */
#define SMALL_BUFFER_SIZE                   ((sizeof(indirect_data_t) + \
                                             sizeof(frame_info_t) + \
                                             MAX_MGMT_FRAME_LENGTH + 1) * 2 / 2)
#endif  /* RFD/FFD */

/* Highest stack layer definitions */
#define PAL                                 (1)
#define TAL                                 (2)
#define MAC                                 (3)
#define NWK                                 (4)

/* Configuration if PAL is the highest stack layer */
#if (HIGHEST_STACK_LAYER == PAL)
#define NUMBER_OF_TOTAL_STACK_TIMERS        (0)
#define LAST_STACK_TIMER_ID                 (0)
#define NUMBER_OF_LARGE_STACK_BUFS          (0)
#define NUMBER_OF_SMALL_STACK_BUFS          (0)
#endif  /* (HIGHEST_STACK_LAYER == PAL) */

/* Configuration if TAL is the highest stack layer */
#if (HIGHEST_STACK_LAYER == TAL)
#include "tal_config.h"
#define NUMBER_OF_TOTAL_STACK_TIMERS        (NUMBER_OF_TAL_TIMERS)
#if (NUMBER_OF_TAL_TIMERS != 0)
#define LAST_STACK_TIMER_ID                 (NUMBER_OF_TAL_TIMERS - 1)
#else
#define LAST_STACK_TIMER_ID                 (0)
#endif
#define NUMBER_OF_LARGE_STACK_BUFS          (4)
#define NUMBER_OF_SMALL_STACK_BUFS          (0)
#endif  /* (HIGHEST_STACK_LAYER == TAL) */

/* Configuration if MAC is the highest stack layer */
#if (HIGHEST_STACK_LAYER == MAC)
#include "mac_config.h"
#define NUMBER_OF_TOTAL_STACK_TIMERS        (NUMBER_OF_TAL_TIMERS + NUMBER_OF_MAC_TIMERS)
#define LAST_STACK_TIMER_ID                 (NUMBER_OF_TAL_TIMERS + NUMBER_OF_MAC_TIMERS - 1)
#define NUMBER_OF_LARGE_STACK_BUFS          (6)
#define NUMBER_OF_SMALL_STACK_BUFS          (2)
#endif  /* (HIGHEST_STACK_LAYER == MAC) */

/* === Types ================================================================ */


/* === Externals ============================================================ */


/* === Prototypes =========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* STACK_CONFIG_H */
/* EOF */
