/**
 * @file ffd_data_structures.h
 *
 * @brief This module contains structures used internally
 *
 * $Id: ffd_data_structures.h 11056 2008-09-15 08:00:34Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* Prevent double inclusion */
#ifndef FFD_DATA_STRUCTURES_H
#define FFD_DATA_STRUCTURES_H

/* === Includes ============================================================= */


/* === Macros =============================================================== */


/* === Types ================================================================ */

/**
 * @brief This is the Indirect data message structure.
 */
BEGIN_PACK
typedef struct PACK indirect_data_tag
{
    frame_info_t *data;
    uint8_t msduHandle;
    bool in_transit;
} indirect_data_t;
END_PACK


BEGIN_PACK
typedef struct PACK indirect_data_pers_timer_tag
{
    uint8_t *buf_ptr;
    uint16_t persistence_time;
    bool active;
} indirect_data_pers_timer_t;
END_PACK
/* === Externals ============================================================ */


/* === Prototypes =========================================================== */

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* FFD_DATA_STRUCTURES_H */
/* EOF */
