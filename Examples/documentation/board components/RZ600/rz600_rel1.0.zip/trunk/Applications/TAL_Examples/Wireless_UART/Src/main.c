/**
 * @file main.c
 *
 * @brief  Main of TAL Example - Wireless_UART
 *
 * $Id: main.c 11791 2008-11-04 17:49:11Z uwalter $
 *
 * @author    Atmel Corporation: http://www.atmel.com
 * @author    Support email: avr@atmel.com
 */
/*
 * Copyright (c) 2008, Atmel Corporation All rights reserved.
 *
 * Licensed under Atmel's Limited License Agreement --> LICENSE.txt
 */

/* === INCLUDES ============================================================ */

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "platform_types.h"
#include "pal.h"
#include "tal.h"
#include "app_config.h"
#include "ieee_const.h"
#include "bmm.h"
#include "ffd_data_structures.h"


/* === TYPES =============================================================== */

/* === MACROS ============================================================== */

#if (TAL_TYPE == AT86RF212)
#define DEFAULT_CHANNEL         (1)
#else
#define DEFAULT_CHANNEL         (20)
#endif
#define DEFAULT_PAN_ID          (0xCAFE)
#define DST_PAN_ID              (DEFAULT_PAN_ID)
#define SRC_PAN_ID              (DEFAULT_PAN_ID)
#define OWN_SHORT_ADDR          (0x0001)
#define DST_SHORT_ADDR          (0x0001)
#define MAX_APP_DATA_LENGTH     (10)
#if ((MAX_APP_DATA_LENGTH > USB_TX_BUF_SIZE) || (MAX_APP_DATA_LENGTH > USB_RX_BUF_SIZE))
#error MAX_DATA_LENGTH too large
#endif
#ifdef UART0
#define SIO_CHANNEL     SIO_0
#endif
#ifdef UART1
#define SIO_CHANNEL     SIO_1
#endif
#ifdef USB0
#define SIO_CHANNEL     SIO_2
#endif


/* === GLOBALS ============================================================= */

bool transmitting = false;
bool in_cmd_mode = false;
uint8_t *cmd;
uint8_t storage_buffer[LARGE_BUFFER_SIZE];  // Much more room is allocated than actually used.
static uint8_t sio_rx_data[MAX_APP_DATA_LENGTH];
frame_info_t *tx_frame_info;


/* === PROTOTYPES ========================================================== */

static void app_task(void);
static void configure_frame_sending(void);

/* === IMPLEMENTATION ====================================================== */


/**
 * @brief Main function of the Wireless UART application
 */
int main(void)
{
    /* Initialize the TAL layer */
    if (tal_init() != SUCCESS)
    {
        // something went wrong during initialization
        pal_alert();
    }

    /* Calibrate MCU's RC oscillator */
    pal_calibrate_rc_osc();

    /* Initialize LEDs */
    pal_led_init();
    pal_led(LED_0, LED_OFF);    // indicating application is started
    pal_led(LED_1, LED_ON);     // indicating data reception

    /*
     * The stack is initialized above, hence the global interrupts are enabled
     * here.
     */
    pal_global_irq_enable();

    /* Initialize the serial interface used for communication with terminal program */
    if (pal_sio_init(SIO_CHANNEL) != SUCCESS)
    {
        // something went wrong during initialization
        pal_alert();
    }

    /* Configure the frame sending; e.g. set short address */
    configure_frame_sending();

    /* Switch receiver on */
    tal_rx_enable(PHY_RX_ON);
    
    /* Endless while loop */
    while (1)
    {  
        pal_task(); /* Handle platform specific tasks, like serial interface */
        tal_task(); /* Handle transceiver specific tasks */
        app_task(); /* Application task */
    }
}


/**
 * @brief Application task
 */
static void app_task(void)
{
    uint8_t number_of_bytes_to_be_transmitted;
    uint8_t i;

    if (transmitting == false)
    {
        number_of_bytes_to_be_transmitted = pal_sio_rx(SIO_CHANNEL, sio_rx_data, MAX_APP_DATA_LENGTH);
        
        // If bytes are received via UART/USB, transmit the bytes.
        if (number_of_bytes_to_be_transmitted > 0)
        {    
                transmitting = true;
                tx_frame_info->seq_num++;

                /* Check for maximum allowed IEEE 802.15.4 frame length. */
                if (number_of_bytes_to_be_transmitted > aMaxMACFrameSize)
                {
                    number_of_bytes_to_be_transmitted = aMaxMACFrameSize;
                }

                tx_frame_info->payload_length = number_of_bytes_to_be_transmitted;
                // Copy data that is required to be transmitted from the end of the storage_buffer
                tx_frame_info->payload = &storage_buffer[LARGE_BUFFER_SIZE - 1];

                for (i = 0; i < number_of_bytes_to_be_transmitted; i++)
                {
                    *(tx_frame_info->payload) = sio_rx_data[number_of_bytes_to_be_transmitted - 1 - i];
                    if ((i + 1) != number_of_bytes_to_be_transmitted)
                    {
                        tx_frame_info->payload--;
                    }
                }

                tal_tx_frame(tx_frame_info, true, true);
        }
    }
}


/**
 * @brief Callback that is called if data has been received by trx.
 *
 * @param mac_frame_info    Pointer to received data structure
 * @param lqi               LQI value of the received frame
 */
void tal_rx_frame_cb(frame_info_t *mac_frame_info, uint8_t lqi)
{
    // print received data to terminal program using UART/USB
    pal_sio_tx(SIO_CHANNEL, mac_frame_info->payload, mac_frame_info->payload_length);

    pal_led(LED_0, LED_TOGGLE);    // indicating data recption

    /* free buffer that was used for frame reception */
    bmm_buffer_free((buffer_t *)(mac_frame_info->buffer_header));

    lqi = lqi;  /* Keep compiler happy. */
}


/**
 * @brief Callback that is called once tx is done.
 *
 * @param status    Status of the transmission procedure
 * @param frame     Pointer to the transmitted frame structure
 */
void tal_tx_frame_done_cb(retval_t status, frame_info_t *frame)
{
    if (status == SUCCESS)
    {
        // print transmitted bytes to terminal program
        pal_sio_tx(SIO_CHANNEL, frame->payload, frame->payload_length);
        pal_led(LED_0, LED_TOGGLE);    // indicating successfull data transmission
    }
    // After transmission is completed, allow next transmission.
    transmitting = false;
}


/**
 * @brief Configure the frame sending
 */
static void configure_frame_sending(void)
{
    uint8_t temp_value[2];

    /*
     * Set TAL PIBs
     * Use: retval_t tal_pib_set(uint8_t attribute, void *value);
     */
    temp_value[0] = (uint8_t)DEFAULT_PAN_ID;
    temp_value[1] =  (uint8_t)(DEFAULT_PAN_ID >> 8);
    tal_pib_set(macPANId, temp_value);

    temp_value[0] = (uint8_t)OWN_SHORT_ADDR;
    temp_value[1] =  (uint8_t)(OWN_SHORT_ADDR >> 8);
    tal_pib_set(macShortAddress, temp_value);

    temp_value[0] = (uint8_t)DEFAULT_CHANNEL;
    tal_pib_set(phyCurrentChannel, temp_value);

    /* Init tx frame info structure value that do not change during program execution */
    tx_frame_info = (frame_info_t *)storage_buffer;
    tx_frame_info->msg_type = MCPS_MESSAGE;  // use data frame type for Wireless_UART example
    tx_frame_info->frame_ctrl = FCF_FRAMETYPE_DATA | FCF_ACK_REQUEST |
                                ((uint16_t)FCF_SHORT_ADDR << 10) | ((uint16_t)FCF_SHORT_ADDR << 14);
#if (DST_PAN_ID == SRC_PAN_ID)
    tx_frame_info->frame_ctrl |= FCF_INTRA_PAN;
#endif
    tx_frame_info->seq_num = (uint8_t)rand();
    tx_frame_info->dest_panid = DST_PAN_ID;
    tx_frame_info->dest_address = DST_SHORT_ADDR;
    tx_frame_info->src_panid = SRC_PAN_ID;
    tx_frame_info->src_address = OWN_SHORT_ADDR;
}

/* EOF */
