Hi and thank you for downloading the RZ600 source code.

Read through the items below before you start using the kit.


CHOOSE A RADIO PAIR:

-The radio transceivers in the kit come in pairs and two radios
 of the same kind should be connected to the two USB boards.

-The top marking of the radio transceiver package must be read
 to determine what type of radio it is.

-Make sure that you now have two USB boards with a radio attached
 where the top marking read: AT86RF230, AT86RF231 or AT86RF212 on
 both.


JTAG CONNECTOR:

-To program the boards with new code, the 50mil connector that comes
 in the bag with the kit needs to be soldered to the USB board.

-A 50 to 100mil JTAG adapter needs to be used between the newly
 soldered connector and the Atmel JTAG unit itself.


COMPILATION:

-Make sure to have IAR Embedded Workbench for AVR32 installed.
 If not already installed, a demo version can be downloaded form
 IAR: www.iar.se

-Open the project file for the radio transceiver pair that you have
 selected.

-Project files are found in: \Applications\TAL_Examples\Wireless_UART

-Build the code and load it to the microcontroller.

-Hit RUN


USB DRIVER;

-When attaching the board to your computer please use the 
 "at32uc3xxx_cdc.inf" file found on the same level as this reame file.


LIMITATIONS:

-Will only support IAR Embedded Workbench in current release.


-Atmel